-- ============================================================
-- .phf — realtime, extra columns, communities, comment votes
-- Run this in Supabase → SQL Editor → New query → Run.
-- Safe to re-run (every statement is idempotent).
-- ============================================================

-- ------------------------------------------------------------
-- profiles: stats shown on profile + thread screens
-- ------------------------------------------------------------
alter table public.phf_profiles add column if not exists location  text;
alter table public.phf_profiles add column if not exists karma     integer not null default 0;
alter table public.phf_profiles add column if not exists followers integer not null default 0;
alter table public.phf_profiles add column if not exists following integer not null default 0;

-- ------------------------------------------------------------
-- categories: rules + founding line
-- ------------------------------------------------------------
alter table public.phf_categories add column if not exists rules    text[] not null default '{}';
alter table public.phf_categories add column if not exists created  text;
alter table public.phf_categories add column if not exists position integer not null default 0;

update public.phf_categories as c
set position = v.position
from (values
  ('announcements', 0), ('general', 1), ('culture', 2), ('ofw', 3),
  ('work', 4), ('marketplace', 5), ('support', 6)
) as v(id, position)
where c.id = v.id;

update public.phf_categories as c
set rules = v.rules, created = v.created
from (values
  ('announcements', array['Read before posting','Introduce yourself once','Feedback with a suggestion'], 'Founded Jan 2026'),
  ('general',       array['No flooding','Tag spoilers','Argue the point'],                                'Founded Jan 2026'),
  ('culture',       array['Credit the source','No gatekeeping','Photos welcome'],                          'Founded Jan 2026'),
  ('ofw',           array['No recruitment posts','Blur personal documents','Country tags required'],       'Founded Jan 2026'),
  ('work',          array['Numbers over vibes','No MLMs','Share the offer letter shape'],                  'Founded Jan 2026'),
  ('marketplace',   array['Meet in public','Price in the title','One bump per day'],                      'Founded Jan 2026'),
  ('support',       array['Not a substitute for a professional','Be kind first','No diagnoses'],           'Founded Jan 2026')
) as v(id, rules, created)
where c.id = v.id;

-- ------------------------------------------------------------
-- comments: score updates when someone votes
-- ------------------------------------------------------------
drop policy if exists "phf_comments_update_all" on public.phf_comments;
create policy "phf_comments_update_all" on public.phf_comments
  for update using (true) with check (true);

-- ------------------------------------------------------------
-- comment votes (one like per member per comment)
-- ------------------------------------------------------------
create table if not exists public.phf_comment_votes (
  comment_id uuid not null references public.phf_comments (id) on delete cascade,
  user_id    uuid not null references public.phf_profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (comment_id, user_id)
);

alter table public.phf_comment_votes enable row level security;

drop policy if exists "phf_comment_votes_select" on public.phf_comment_votes;
create policy "phf_comment_votes_select" on public.phf_comment_votes
  for select using (true);
drop policy if exists "phf_comment_votes_insert_own" on public.phf_comment_votes;
create policy "phf_comment_votes_insert_own" on public.phf_comment_votes
  for insert with check (auth.uid() = user_id);
drop policy if exists "phf_comment_votes_delete_own" on public.phf_comment_votes;
create policy "phf_comment_votes_delete_own" on public.phf_comment_votes
  for delete using (auth.uid() = user_id);

-- atomic score change when a comment vote lands
create or replace function public.phf_comment_vote(target uuid, delta integer)
returns void
language sql
security invoker
set search_path = public
as $$
  update public.phf_comments
  set score = greatest(0, score + delta)
  where id = target;
$$;

grant execute on function public.phf_comment_vote(uuid, integer) to authenticated;

-- ------------------------------------------------------------
-- communities (sidebar + explore)
-- ------------------------------------------------------------
create table if not exists public.phf_communities (
  id          text primary key,
  name        text not null,
  icon        text not null default 'Messages2',
  members     integer not null default 0,
  online      integer not null default 0,
  description text,
  rules       text[] not null default '{}',
  created     text,
  created_at  timestamptz not null default now()
);

insert into public.phf_communities (id, name, icon, members, online, description, rules, created) values
  ('design',      'Design Systems',  'Colorfilter', 48200, 412, 'Tokens, components, and the politics of the spacing scale. A quiet room for people who argue about 1px.', array['Show your work','No tool evangelism','Critique the artifact, not the person'], 'Founded Mar 2023'),
  ('engineering', 'Engineering',     'Code',       132400,1893, 'Systems, tradeoffs, and post-mortems. If it shipped, we want to know what it cost you.',             array['Include numbers','Link the source','No résumé padding'], 'Founded Jan 2023'),
  ('ai',          'Machine Learning','CpuChip',     96400,1420, 'Models, evals, and the unglamorous work of shipping inference to real users.',                       array['Cite the paper','Show the eval','Hype gets removed'], 'Founded Feb 2023'),
  ('product',     'Product Craft',   'Layer',       27800, 236, 'Decisions, sequencing, and saying no politely but firmly.',                                          array['Context over opinion','No vanity metrics'], 'Founded May 2023'),
  ('data',        'Data & Charts',   'Chart21',     19300, 148, 'Visualisation, analysis, and the occasional chart crime confession.',                                array['Label your axes','Share the dataset'], 'Founded Jul 2023'),
  ('reading',     'Long Reads',      'BookOpen',    12100,  97, 'Essays, books, and writing that earns its length.',                                                 array['One link per thread','Add a summary'], 'Founded Aug 2023'),
  ('photography', 'Monochrome Photo','Camera',      34600, 301, 'Black, white, and every honest grey in between. Grain encouraged.',                                 array['OC only','Gear talk in weekly thread'], 'Founded Apr 2023'),
  ('offbeat',     'Off Topic',       'Coffee',      61200, 744, 'Keyboards, coffee, commutes, and everything that keeps the work bearable.',                          array['Be decent','No politics'], 'Founded Jan 2023'),
  ('protocols',   'Protocols',       'Cube',        44900, 612, 'Rollups, fee markets, and the plumbing nobody sees until it clogs.',                                 array['No price talk','Explain the mechanism'], 'Founded Mar 2023'),
  ('travel',      'Slow Travel',     'PaperPlane',  23400, 188, 'Trains, ferries, and the places you only find by getting lost.',                                    array['Detail beats hype','Credit photographers'], 'Founded Oct 2023')
on conflict (id) do nothing;

alter table public.phf_communities enable row level security;

drop policy if exists "phf_communities_select" on public.phf_communities;
create policy "phf_communities_select" on public.phf_communities
  for select using (true);

-- ------------------------------------------------------------
-- grants (SQL-editor tables do not always inherit them)
-- ------------------------------------------------------------
grant select on public.phf_communities    to anon, authenticated;
grant select on public.phf_comment_votes  to anon, authenticated;
grant insert, delete on public.phf_comment_votes to authenticated;
grant update on public.phf_comments       to authenticated;

-- ------------------------------------------------------------
-- realtime: every phf_ table streams to subscribed clients
-- ------------------------------------------------------------
do $$
declare t text;
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array[
      'phf_profiles', 'phf_categories', 'phf_posts', 'phf_comments',
      'phf_reactions', 'phf_saves', 'phf_follows', 'phf_room_members',
      'phf_notifications', 'phf_comment_votes', 'phf_communities'
    ] loop
      begin
        execute format('alter publication supabase_realtime add table public.%I', t);
      exception when duplicate_object then
        null;
      end;
    end loop;
  end if;
end $$;
