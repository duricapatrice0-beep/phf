-- ============================================================
-- .phf — points (karma) engine, follow counters, edit tracking
-- Run this in Supabase → SQL Editor → New query → Run.
--
-- IMPORTANT: run the WHOLE file as one query. It opens a single
-- transaction guarded by an advisory lock, so a second run (or a
-- double-click) simply waits instead of deadlocking, and a failure
-- rolls everything back cleanly. Safe to re-run.
--
-- Points rules (fractional + spam-guarded):
--   you:  +3    start a thread
--         +1    post a reply
--         +0.5  post a comment
--         +1    react to someone else's post
--         +1    upvote someone else's comment
--   back: +1    someone reacts to your post            (all reaction kinds)
--         +0.5  someone comments on your post          (not your own)
--         +2    someone upvotes your comment           (not your own)
--
-- Spam guard (mirrors src/lib/store.jsx):
--   * the 6th+ comment/reply by the same author inside a rolling
--     10-minute window scores 0 for the author AND the thread owner
--   * repeated comment text (normalized) scores 0 after the first time
--   * the 4th thread by the same author inside 10 minutes scores 0
--
-- NOTE: the app derives points client-side from the base tables —
-- that derivation is authoritative. This file keeps the
-- phf_profiles.karma column in sync so the DB agrees with the UI,
-- plus edited_at columns and tighter RLS.
-- ============================================================

begin;
select pg_advisory_xact_lock(8152026);

-- ------------------------------------------------------------
-- edited_at: client stamps this when you edit a post/comment
-- ------------------------------------------------------------
alter table public.phf_posts    add column if not exists edited_at timestamptz;
alter table public.phf_comments add column if not exists edited_at timestamptz;

-- ------------------------------------------------------------
-- karma column: fractional points now (0.5 steps)
-- ------------------------------------------------------------
alter table public.phf_profiles alter column karma type numeric using coalesce(karma, 0)::numeric;
alter table public.phf_profiles alter column karma set default 0;
update public.phf_profiles set karma = coalesce(karma, 0);

-- ------------------------------------------------------------
-- RLS: your own comment body, and reaction kind switching
-- ------------------------------------------------------------
drop policy if exists "phf_comments_update_all" on public.phf_comments;
drop policy if exists "phf_comments_update_own" on public.phf_comments;
create policy "phf_comments_update_own" on public.phf_comments
  for update using (auth.uid() = author_id) with check (auth.uid() = author_id);

drop policy if exists "phf_reactions_update_own" on public.phf_reactions;
create policy "phf_reactions_update_own" on public.phf_reactions
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- the vote RPC updates score on other people's comments, so it must
-- run as the function owner — otherwise the tighter policy blocks votes
create or replace function public.phf_comment_vote(target uuid, delta integer)
returns void
language sql
security definer
set search_path = public
as $$
  update public.phf_comments
  set score = greatest(0, score + least(1, greatest(-1, delta)))
  where id = target;
$$;

grant execute on function public.phf_comment_vote(uuid, integer) to authenticated;

-- ------------------------------------------------------------
-- karma: starting a thread (+3, spam-guarded)
-- ------------------------------------------------------------
create or replace function public.phf_karma_posts()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  in_window integer;
  norm_new text;
  spam boolean;
begin
  if tg_op = 'INSERT' then
    select count(*) + 1 into in_window
    from public.phf_posts c
    where c.author_id = new.author_id
      and c.created_at > new.created_at - interval '10 minutes'
      and c.created_at <= new.created_at;

    norm_new := btrim(lower(regexp_replace(coalesce(new.title, ''), '[^\w]+', ' ', 'g')));
    spam := in_window > 3 or exists (
      select 1 from public.phf_posts c2
      where c2.author_id = new.author_id
        and c2.id <> new.id
        and btrim(lower(regexp_replace(coalesce(c2.title, ''), '[^\w]+', ' ', 'g'))) = norm_new
    );

    if not spam then
      update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) + 3) where id = new.author_id;
    end if;
    return new;
  end if;

  -- DELETE: recompute the same guard to decide what to subtract
  select count(*) + 1 into in_window
  from public.phf_posts c
  where c.author_id = old.author_id
    and c.created_at > old.created_at - interval '10 minutes'
    and c.created_at <= old.created_at;

  norm_new := btrim(lower(regexp_replace(coalesce(old.title, ''), '[^\w]+', ' ', 'g')));
  spam := in_window > 3 or exists (
    select 1 from public.phf_posts c2
    where c2.author_id = old.author_id
      and c2.id <> old.id
      and btrim(lower(regexp_replace(coalesce(c2.title, ''), '[^\w]+', ' ', 'g'))) = norm_new
  );

  if not spam then
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) - 3) where id = old.author_id;
  end if;
  return old;
end;
$$;

drop trigger if exists phf_karma_posts on public.phf_posts;
create trigger phf_karma_posts
  after insert or delete on public.phf_posts
  for each row execute function public.phf_karma_posts();

-- ------------------------------------------------------------
-- karma: reactions — reactor +1 (others' posts), author +1 (received)
-- ------------------------------------------------------------
create or replace function public.phf_karma_reactions()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  post_author uuid;
  actor uuid;
begin
  if tg_op = 'INSERT' then
    select po.author_id into post_author from public.phf_posts po where po.id = new.post_id;
    actor := new.user_id;
  else
    select po.author_id into post_author from public.phf_posts po where po.id = old.post_id;
    actor := old.user_id;
  end if;

  if post_author is null or post_author = actor then
    return coalesce(new, old);
  end if;

  if tg_op = 'INSERT' then
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) + 1) where id = actor;
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) + 1) where id = post_author;
  else
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) - 1) where id = actor;
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) - 1) where id = post_author;
  end if;
  return coalesce(new, old);
end;
$$;

drop trigger if exists phf_karma_reactions on public.phf_reactions;
create trigger phf_karma_reactions
  after insert or delete on public.phf_reactions
  for each row execute function public.phf_karma_reactions();

-- ------------------------------------------------------------
-- karma: upvotes — voter +1 (others' comments), author +2 (received)
-- ------------------------------------------------------------
create or replace function public.phf_karma_comment_votes()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  comment_author uuid;
  actor uuid;
begin
  if tg_op = 'INSERT' then
    select c.author_id into comment_author from public.phf_comments c where c.id = new.comment_id;
    actor := new.user_id;
  else
    select c.author_id into comment_author from public.phf_comments c where c.id = old.comment_id;
    actor := old.user_id;
  end if;

  if comment_author is null or comment_author = actor then
    return coalesce(new, old);
  end if;

  if tg_op = 'INSERT' then
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) + 1) where id = actor;
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) + 2) where id = comment_author;
  else
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) - 1) where id = actor;
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) - 2) where id = comment_author;
  end if;
  return coalesce(new, old);
end;
$$;

drop trigger if exists phf_karma_comment_votes on public.phf_comment_votes;
create trigger phf_karma_comment_votes
  after insert or delete on public.phf_comment_votes
  for each row execute function public.phf_karma_comment_votes();

-- ------------------------------------------------------------
-- karma: commenting (+0.5 top-level / +1 reply to author,
--                  +0.5 received to the thread's OP) — spam-guarded
--                  + comment_count
-- ------------------------------------------------------------
create or replace function public.phf_karma_comments()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  post_author uuid;
  author_pts numeric;
  in_window integer;
  norm_new text;
  spam boolean;
begin
  if tg_op = 'INSERT' then
    select count(*) + 1 into in_window
    from public.phf_comments c
    where c.author_id = new.author_id
      and c.created_at > new.created_at - interval '10 minutes'
      and c.created_at <= new.created_at;

    norm_new := btrim(lower(regexp_replace(coalesce(new.body, ''), '[^\w]+', ' ', 'g')));
    spam := in_window > 5 or exists (
      select 1 from public.phf_comments c2
      where c2.author_id = new.author_id
        and c2.id <> new.id
        and btrim(lower(regexp_replace(coalesce(c2.body, ''), '[^\w]+', ' ', 'g'))) = norm_new
    );

    if not spam then
      if new.parent_id is null then author_pts := 0.5; else author_pts := 1; end if;
      update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) + author_pts) where id = new.author_id;

      select po.author_id into post_author from public.phf_posts po where po.id = new.post_id;
      if post_author is not null and post_author <> new.author_id then
        update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) + 0.5) where id = post_author;
      end if;
    end if;

    update public.phf_posts set comment_count = comment_count + 1 where id = new.post_id;
    return new;
  end if;

  -- DELETE: mirror the same guard to decide what to subtract
  select count(*) + 1 into in_window
  from public.phf_comments c
  where c.author_id = old.author_id
    and c.created_at > old.created_at - interval '10 minutes'
    and c.created_at <= old.created_at;

  norm_new := btrim(lower(regexp_replace(coalesce(old.body, ''), '[^\w]+', ' ', 'g')));
  spam := in_window > 5 or exists (
    select 1 from public.phf_comments c2
    where c2.author_id = old.author_id
      and c2.id <> old.id
      and btrim(lower(regexp_replace(coalesce(c2.body, ''), '[^\w]+', ' ', 'g'))) = norm_new
  );

  if not spam then
    if old.parent_id is null then author_pts := 0.5; else author_pts := 1; end if;
    update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) - author_pts) where id = old.author_id;

    select po.author_id into post_author from public.phf_posts po where po.id = old.post_id;
    if post_author is not null and post_author <> old.author_id then
      update public.phf_profiles set karma = greatest(0, coalesce(karma, 0) - 0.5) where id = post_author;
    end if;
  end if;

  update public.phf_posts set comment_count = greatest(0, comment_count - 1) where id = old.post_id;
  return old;
end;
$$;

drop trigger if exists phf_karma_comments on public.phf_comments;
create trigger phf_karma_comments
  after insert or delete on public.phf_comments
  for each row execute function public.phf_karma_comments();

-- ------------------------------------------------------------
-- followers / following counters
-- ------------------------------------------------------------
create or replace function public.phf_follow_counts()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    update public.phf_profiles set followers = coalesce(followers, 0) + 1 where id = new.target_id;
    update public.phf_profiles set following = coalesce(following, 0) + 1 where id = new.follower_id;
    return new;
  end if;
  update public.phf_profiles set followers = greatest(0, coalesce(followers, 0) - 1) where id = old.target_id;
  update public.phf_profiles set following = greatest(0, coalesce(following, 0) - 1) where id = old.follower_id;
  return old;
end;
$$;

drop trigger if exists phf_follow_counts_insert on public.phf_follows;
create trigger phf_follow_counts_insert
  after insert on public.phf_follows
  for each row execute function public.phf_follow_counts();

drop trigger if exists phf_follow_counts_delete on public.phf_follows;
create trigger phf_follow_counts_delete
  after delete on public.phf_follows
  for each row execute function public.phf_follow_counts();

-- ------------------------------------------------------------
-- backfill: recompute every counter from existing rows
-- (mirrors the trigger rules exactly — safe to re-run)
-- ------------------------------------------------------------
update public.phf_posts p
set comment_count = coalesce(
  (select count(*) from public.phf_comments c where c.post_id = p.id), 0);

update public.phf_profiles p
set followers = coalesce(
    (select count(*) from public.phf_follows f where f.target_id = p.id), 0),
    following = coalesce(
    (select count(*) from public.phf_follows f where f.follower_id = p.id), 0);

with norm_comments as (
  select c.id, c.author_id, c.parent_id, c.post_id, c.created_at,
         btrim(lower(regexp_replace(coalesce(c.body, ''), '[^\w]+', ' ', 'g'))) as norm
  from public.phf_comments c
),
comment_flags as (
  select nc.*,
         (select count(*) from public.phf_comments x
            where x.author_id = nc.author_id
              and x.created_at > nc.created_at - interval '10 minutes'
              and x.created_at <= nc.created_at) as in_window,
         row_number() over (
           partition by nc.author_id, nc.norm order by nc.created_at, nc.id) as dup_rank
  from norm_comments nc
),
scored_comments as (
  select fc.*,
         case when fc.in_window > 5 or fc.dup_rank > 1 then 0
              when fc.parent_id is null then 0.5
              else 1 end as my_pts,
         case when fc.in_window > 5 or fc.dup_rank > 1 then 0 else 0.5 end as received_pts
  from comment_flags fc
),
norm_posts as (
  select po.id, po.author_id, po.created_at,
         btrim(lower(regexp_replace(coalesce(po.title, ''), '[^\w]+', ' ', 'g'))) as norm
  from public.phf_posts po
),
post_flags as (
  select np.*,
         (select count(*) from public.phf_posts x
            where x.author_id = np.author_id
              and x.created_at > np.created_at - interval '10 minutes'
              and x.created_at <= np.created_at) as in_window,
         row_number() over (
           partition by np.author_id, np.norm order by np.created_at, np.id) as dup_rank
  from norm_posts np
),
scored_posts as (
  select fp.*,
         case when fp.in_window > 3 or fp.dup_rank > 1 then 0 else 3 end as my_pts
  from post_flags fp
)
update public.phf_profiles p
set karma = greatest(0,
    -- you: threads started, comments/replies posted (spam flags zeroed above)
    coalesce((select sum(s.my_pts) from scored_posts s where s.author_id = p.id), 0)
  + coalesce((select sum(s.my_pts) from scored_comments s where s.author_id = p.id), 0)
    -- you: reactions given, upvotes cast (on other people's stuff)
  + coalesce((
      select count(*)
      from public.phf_reactions r
      join public.phf_posts po on po.id = r.post_id
      where r.user_id = p.id and po.author_id <> p.id
    ), 0)
  + coalesce((
      select count(*)
      from public.phf_comment_votes cv
      join public.phf_comments c on c.id = cv.comment_id
      where cv.user_id = p.id and c.author_id <> p.id
    ), 0)
    -- back: reactions received, comments received (non-spam only), upvotes received
  + coalesce((
      select count(*)
      from public.phf_reactions r
      join public.phf_posts po on po.id = r.post_id
      where po.author_id = p.id and r.user_id <> p.id
    ), 0)
  + coalesce((
      select sum(s.received_pts)
      from scored_comments s
      join public.phf_posts po on po.id = s.post_id
      where po.author_id = p.id and s.author_id <> p.id
    ), 0)
  + coalesce((
      select 2 * count(*)
      from public.phf_comment_votes cv
      join public.phf_comments c on c.id = cv.comment_id
      where c.author_id = p.id and cv.user_id <> p.id
    ), 0));

commit;
