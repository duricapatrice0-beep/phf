-- ============================================================
-- .phf — demo content (members, posts, comments, reactions)
-- Run this in Supabase → SQL Editor after phf_realtime.sql.
--
-- Demo logins (password for all: phf-test-123):
--   mira@phf.dev · kenji@phf.dev · dara@phf.dev · noor@phf.dev
--   theo@phf.dev · iris@phf.dev · sam@phf.dev · vee@phf.dev
--
-- Safe to re-run: every insert is conflict-safe.
-- ============================================================

begin;

-- demo members (auth user + profile row)
insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', '00000000-0000-4000-8000-000000000001', 'authenticated', 'authenticated', 'mira@phf.dev', extensions.crypt('phf-test-123', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"name":"Mira Solano"}', '2023-01-15', '2023-01-15')
on conflict (id) do nothing;
insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', '00000000-0000-4000-8000-000000000002', 'authenticated', 'authenticated', 'kenji@phf.dev', extensions.crypt('phf-test-123', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"name":"Kenji Abara"}', '2023-06-12', '2023-06-12')
on conflict (id) do nothing;
insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', '00000000-0000-4000-8000-000000000003', 'authenticated', 'authenticated', 'dara@phf.dev', extensions.crypt('phf-test-123', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"name":"Dara Osei"}', '2023-09-04', '2023-09-04')
on conflict (id) do nothing;
insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', '00000000-0000-4000-8000-000000000004', 'authenticated', 'authenticated', 'noor@phf.dev', extensions.crypt('phf-test-123', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"name":"Noor Habibi"}', '2024-02-19', '2024-02-19')
on conflict (id) do nothing;
insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', '00000000-0000-4000-8000-000000000005', 'authenticated', 'authenticated', 'theo@phf.dev', extensions.crypt('phf-test-123', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"name":"Theo Marchetti"}', '2023-11-27', '2023-11-27')
on conflict (id) do nothing;
insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', '00000000-0000-4000-8000-000000000006', 'authenticated', 'authenticated', 'iris@phf.dev', extensions.crypt('phf-test-123', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"name":"Iris Lindqvist"}', '2024-04-08', '2024-04-08')
on conflict (id) do nothing;
insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', '00000000-0000-4000-8000-000000000007', 'authenticated', 'authenticated', 'sam@phf.dev', extensions.crypt('phf-test-123', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"name":"Sam Okonkwo"}', '2024-08-21', '2024-08-21')
on conflict (id) do nothing;
insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', '00000000-0000-4000-8000-000000000008', 'authenticated', 'authenticated', 'vee@phf.dev', extensions.crypt('phf-test-123', extensions.gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"name":"Vee Tan"}', '2024-12-02', '2024-12-02')
on conflict (id) do nothing;

update public.phf_profiles set handle = 'mira', name = 'Mira Solano', bio = 'Design systems lead. Keeper of the 1px hairline.', location = 'Lisbon, PT', karma = 64210, followers = 9820, following = 214, role = 'Moderator', created_at = '2023-01-15' where id = '00000000-0000-4000-8000-000000000001';
update public.phf_profiles set handle = 'kenji', name = 'Kenji Abara', bio = 'Databases, latency budgets, and the occasional rant about ORMs.', location = 'Berlin, DE', karma = 41980, followers = 6120, following = 180, role = 'Top contributor', created_at = '2023-06-12' where id = '00000000-0000-4000-8000-000000000002';
update public.phf_profiles set handle = 'dara', name = 'Dara Osei', bio = 'Research engineer. I read the paper so you don’t have to.', location = 'Accra, GH', karma = 33150, followers = 5470, following = 96, role = 'Top contributor', created_at = '2023-09-04' where id = '00000000-0000-4000-8000-000000000003';
update public.phf_profiles set handle = 'noor', name = 'Noor Habibi', bio = 'Type, rhythm, and the space between things.', location = 'Amman, JO', karma = 21740, followers = 3380, following = 401, role = 'Member', created_at = '2024-02-19' where id = '00000000-0000-4000-8000-000000000004';
update public.phf_profiles set handle = 'theo', name = 'Theo Marchetti', bio = 'Product. Ex-agency. Allergic to slide decks.', location = 'Milan, IT', karma = 15620, followers = 2140, following = 588, role = 'Member', created_at = '2023-11-27' where id = '00000000-0000-4000-8000-000000000005';
update public.phf_profiles set handle = 'iris', name = 'Iris Lindqvist', bio = 'Photographer. Mostly black, occasionally white.', location = 'Malmö, SE', karma = 12890, followers = 4410, following = 77, role = 'Member', created_at = '2024-04-08' where id = '00000000-0000-4000-8000-000000000006';
update public.phf_profiles set handle = 'sam', name = 'Sam Okonkwo', bio = 'Self-hosting everything until it breaks. It always breaks.', location = 'Lagos, NG', karma = 9340, followers = 1510, following = 244, role = 'Member', created_at = '2024-08-21' where id = '00000000-0000-4000-8000-000000000007';
update public.phf_profiles set handle = 'vee', name = 'Vee Tan', bio = 'Frontend. Motion, restraint, and knowing when to stop.', location = 'Singapore, SG', karma = 7210, followers = 980, following = 156, role = 'New', created_at = '2024-12-02' where id = '00000000-0000-4000-8000-000000000008';

-- posts
insert into public.phf_posts (id, author_id, category, title, excerpt, body, tags, media, pinned, created_at) values
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000001', 'announcements', 'Read this first: seven rooms, and why nothing gets its own forum yet', 'Rules, intros, and feedback share one room on purpose — none of them has the volume to stand alone. Here is the shape we are starting with, and the rule we will use to split rooms later.', 'We opened with seven categories instead of seventeen. Every attempt at a forum I have watched die did so the same way: six rooms with three threads each, and the newest one always looked abandoned. Volume comes before structure, so the structure stays loose.

The split rule is simple and public. A room gets its own category when it holds at least five active threads a week for a month, and when the people posting there keep asking for a door of their own. Until then it stays inside its parent room, and that is not a demotion.

Announcements, intros, and feedback are deliberately lumped here for the same reason. On day one they would each be a room with one pinned post. When the intros start drowning the rules, we will move them — and we will say so in this thread when we do.', array['announcements', 'rules'], null, false, now() - interval '42 minutes'),
  ('00000000-0000-4000-8000-000000000102', '00000000-0000-4000-8000-000000000001', 'announcements', 'Introductions: where you are, what you do, how you found us', 'One thread for hellos so the rest of the forum stays readable. No format rules — a sentence is enough, and lurkers are allowed to say nothing.', 'Post where you are, what you do, and how you ended up here. One paragraph is plenty. If you are overseas, say the country — the OFW room is already the busiest one we have, and knowing who is where makes the answers better.

Two requests. First, keep job pitches out of this thread; there is a room for that and it is not this one. Second, if you are linking your own work, link it once and describe it in your own words — the bare URL gets removed.

This thread doubles as the feedback thread for the forum itself. If something feels broken, misplaced, or too slow, say it here and it gets handled in the open rather than in a DM nobody can read later.', array['introductions', 'feedback'], null, false, now() - interval '96 minutes'),
  ('00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000002', 'general', 'The group chat is the last honest place on the internet', 'Every public feed is a performance now. So why does the typo-filled, three-hour-delayed group chat still beat all of it — and can that survive another five years?', 'I left every public platform for a month and kept exactly four group chats. What I noticed was not the speed, it was the absence of an audience: nobody was building a version of themselves for strangers, so the messages arrived unedited and often wrong in ways that were funny rather than embarrassing.

The uncomfortable part is that this only works because it is small. Past about twenty people the chat stops being a room and becomes a broadcast channel, and the same performance instincts creep back in.

My theory is that every platform since 2010 has been an attempt to give that feeling to ten million people at once, and none of them have managed it because the feeling is a property of size, not of design.', array['internet', 'chitchat'], null, false, now() - interval '180 minutes'),
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000001', 'general', 'What is the one app you still refuse to delete?', 'Not the ones you love — the ones you have simply never gotten around to leaving. Mine is a habit tracker from 2019 with four users left in the entire network.', 'I checked my phone this morning and found eleven apps I have not opened in a year but would not remove. Every one of them has a reason that sounds reasonable out loud and ridiculous when you write it down.

The habit tracker is the worst offender. Four active users worldwide, the server has been slower every year, and I keep it because deleting it would mean admitting I never built the habit.

Your turn. Name the app and the excuse — the more embarrassing the excuse, the better the thread.', array['apps', 'random'], null, false, now() - interval '300 minutes'),
  ('00000000-0000-4000-8000-000000000105', '00000000-0000-4000-8000-000000000004', 'culture', 'OPM is having its best year in two decades and the charts are not what is driving it', 'Streaming numbers are flat. Ticket sales are not. The rooms got smaller, the tickets got pricier, and the audience started showing up in person instead of pressing play.', 'The story everyone tells is that a viral moment fixed the industry. The data disagrees: streaming share for local releases barely moved, while ticketed shows sold out faster than venues could schedule them. The growth is in rooms, not in feeds.

Two things changed at once. Promoters stopped chasing arena scale and started programming 800-seat rooms with real sound, and artists stopped treating the show as marketing for the record — the show became the product, and the record became the trailer.

The risk is obvious. A scene that runs on ticket revenue is more fragile than one that runs on catalogue depth, because a bad quarter hits the calendar before it hits the streaming statement.', array['opm', 'music'], 'type', false, now() - interval '420 minutes'),
  ('00000000-0000-4000-8000-000000000106', '00000000-0000-4000-8000-000000000006', 'culture', 'Every province has one dish tourists are not allowed to order correctly', 'Rice first? Sauce on the side? Hands or fork? The rules are unwritten, fiercely defended, and almost always explained by a lola somewhere in the room.', 'There is a version of every regional dish that the province considers correct, a second version that restaurants serve to visitors, and a third version that exists only on social media. Locals can tell which one you ordered before the plate lands.

I am not arguing for the strict version. I am arguing that the strict version is documentation — it records what the dish was before the shortcut ingredient arrived — and that losing it is how a recipe quietly becomes generic.

So: name the dish, name the place, and say the one thing outsiders always get wrong about it. I will start with the version of laing my grandmother would not let anyone finish cooking in a pressure cooker.', array['food', 'traditions'], 'photo', false, now() - interval '540 minutes'),
  ('00000000-0000-4000-8000-000000000107', '00000000-0000-4000-8000-000000000008', 'ofw', 'Contract checklist for first-time OFWs: the eight lines I wish I read before signing', 'Placement fee, repatriation clause, overtime language, and the salary figure that changes the moment you land. Print this and take it to the agency.', 'Read the gross figure and then read the deductions page, in that order, out loud. The number in the offer letter is not the number that arrives — housing, insurance, and service fees are all negotiable before you sign and almost impossible after.

The clause nobody reads is repatriation: who pays for the ticket home if the contract ends early, and on whose schedule. Mine said “as agreed”, which turned three weeks into four months when the company folded.

Last one: overtime. If the contract says “as required by operational needs” without a rate, write in the rate yourself before anyone initial it. Everything you agree to at the agency is enforceable; everything you agree to on day one at the site is a favour.', array['ofw', 'contracts'], null, false, now() - interval '700 minutes'),
  ('00000000-0000-4000-8000-000000000108', '00000000-0000-4000-8000-000000000003', 'ofw', 'Diaspora math: how much of my salary actually lands home after fees', 'Thirty-six months of remittance receipts, charted. The gap between my best and worst month was never income — it was timing and provider markup.', 'I exported three years of receipts and put every transfer on one chart with the fee, the exchange rate applied, and the peso amount that arrived. The line people react to is the total; the line that matters is the spread between providers in the same week.

The worst month cost me 4.1% in fees and rate alone, and it was the month I sent in a hurry after a hospital call. The best cost 1.2% and took eleven minutes of comparing. Fear is expensive.

The structural fix was boring: two standing instructions, one sent on a fixed date, and a rule that anything urgent goes through the provider with the worst rate but the fastest settlement — planned for, not panicked into.', array['remittances', 'data'], 'chart', false, now() - interval '900 minutes'),
  ('00000000-0000-4000-8000-000000000109', '00000000-0000-4000-8000-000000000005', 'work', 'I negotiated a 40% raise by writing one document', 'No threats, no competing offer, no theatre. Two pages: what I owned, what it was worth in the market, and the number I wanted. The template is below.', 'The document had three sections. First, ownership — the systems I was the only person able to change, written as a list with the risk attached to each. Second, market — three comparable roles with the salary bands published, not hearsay. Third, the ask, stated as a number with a date.

What made it work was that my manager did not have to build the case for me. She took the document into a room, and the conversation that followed was about budget rather than about whether I deserved it.

The part nobody tells you: write it so it survives being forwarded. Anything you would not want a stranger to read stays out of the file, because it will be read by one.', array['salary', 'work'], null, false, now() - interval '1200 minutes'),
  ('00000000-0000-4000-8000-000000000110', '00000000-0000-4000-8000-000000000002', 'work', 'Side business, honest numbers: six months of selling prints on weekends', 'Gross looks impressive until you subtract the stall fee, the misprints, and the hours. Here is the real ledger, including the weekend I made nothing at all.', 'Six months, twelve market days, and a spreadsheet I updated in the car on the way home. Gross was respectable. Net, after the table fee, paper, ink, and the two pieces I underpriced by half, was closer to a good holiday than a salary.

The useful finding is that my best day was not the busiest market — it was a slow Tuesday when a café owner bought forty prints for a wall. One wholesale conversation beat eleven days of retail.

I am keeping it, but on the café model: fewer days, bigger buyers, and a price list that does not need me standing behind it.', array['sidehustle', 'smallbusiness'], 'chart', false, now() - interval '1500 minutes'),
  ('00000000-0000-4000-8000-000000000111', '00000000-0000-4000-8000-000000000007', 'marketplace', 'Selling: full home office setup — 27" monitor, mech keyboard, standing desk (QC, pickup)', 'Upgrading, so it all goes at once. Everything tested and working, priced to move this weekend. DM before Saturday, cash or transfer, pickup in Quezon City.', 'Monitor: 27-inch 1440p, two years old, no dead pixels, original stand and box. Keyboard: hot-swappable 65% with the linear switches still in it, keycaps included. Desk: electric standing desk, 120cm, motors quiet, controller replaced last year.

Individually these would take a month to sell. Together I will let them go for a flat package price, with the monitor arm thrown in if you take all three.

Pickup in Quezon City on a weekend, or meet at a mall if you prefer. No shipping — I have had one too many monitors arrive cracked, and I would rather you inspect it in person.', array['forsale', 'setup'], 'photo', false, now() - interval '95 minutes'),
  ('00000000-0000-4000-8000-000000000112', '00000000-0000-4000-8000-000000000006', 'support', 'How do I talk to my parents about retirement when they do not want to talk about money?', 'They supported us for thirty years and now flinch at the word pension. Looking for scripts from people who have already had this conversation without turning it into a fight.', 'Every attempt so far has ended the same way: I raise it, the subject changes, and we all agree the food was good. I do not think they are in denial about the arithmetic — I think the conversation feels like a report card.

What I want is a way in that does not start with numbers. Someone suggested opening with their own parents, which worked for a friend for exactly one dinner before it stopped working.

If you have done this: how did you start, what did you avoid saying, and did you involve a third person — a sibling, a banker, an accountant — or did that make it worse?', array['family', 'advice'], null, false, now() - interval '240 minutes'),
  ('00000000-0000-4000-8000-000000000113', '00000000-0000-4000-8000-000000000004', 'support', 'Where do people actually go for pro bono legal help in Metro Manila?', 'Overseas contract dispute, no budget for a retainer. Looking for names and intake procedures — not a link to a homepage last updated in 2017.', 'The clinic I called in March only handles walk-ins on Thursdays and the number redirects to a landline that nobody answers. I am sure the resources exist; I am struggling with the part where you find the current door.

Specifically: assistance with an employment contract dispute where the employer is overseas and the signatory is local. Documentation is complete, dates are documented, and the ask is a first opinion rather than representation.

If you have been through this, what was the actual first step — the clinic, the bar association referral, the barangay hall notice board? And roughly how long between the first call and a human who had read the folder?', array['legal', 'help'], null, false, now() - interval '1350 minutes')
on conflict (id) do nothing;

-- comment threads (p1, p3, p4)
insert into public.phf_comments (id, post_id, author_id, parent_id, body, score, created_at) values
  ('00000000-0000-4000-8000-c10000000000', '00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000002', null, 'Publishing the split rule in public is the right call. The forums that die quietly are the ones that merge rooms in a DM and hope nobody notices the graveyard.', 412, now() - interval '31 minutes'),
  ('00000000-0000-4000-8000-c11000000000', '00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-c10000000000', 'It came out of watching two communities I liked do the opposite. Six rooms, three threads each, and the newest room always looked like it had been abandoned mid-sentence.', 288, now() - interval '27 minutes'),
  ('00000000-0000-4000-8000-c11100000000', '00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000008', '00000000-0000-4000-8000-c11000000000', 'The five-threads-a-week threshold is the part I would steal. Vague growth rules get ignored; a number you can count on a Tuesday does not.', 96, now() - interval '22 minutes'),
  ('00000000-0000-4000-8000-c12000000000', '00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-c10000000000', 'Question on the threshold — does a room count its own announcements toward that five, or only organic threads?', 74, now() - interval '18 minutes'),
  ('00000000-0000-4000-8000-c12100000000', '00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-c12000000000', 'Organic only. Pinned posts are infrastructure; if a room needs its own announcements to hit the number, it is not ready to be a room.', 131, now() - interval '15 minutes'),
  ('00000000-0000-4000-8000-c20000000000', '00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000005', null, 'Feedback on the mobile sidebar: the seven categories are easy to lose under the old communities list. Consider collapsing communities behind a toggle once the forum has more than a handful of rooms.', 168, now() - interval '24 minutes'),
  ('00000000-0000-4000-8000-c21000000000', '00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-c20000000000', 'Noted, and agreed. The plan is to collapse the communities section on small screens the moment the forum rooms outnumber them — which, at the current rate, is about three weeks.', 84, now() - interval '19 minutes'),
  ('00000000-0000-4000-8000-c30000000000', '00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000006', null, 'Glad the intros are staying in one thread. The alternative is a front page where every third post is someone saying hello, which is lovely for a week and unreadable after that.', 52, now() - interval '12 minutes'),
  ('00000000-0000-4000-8000-a10000000000', '00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000006', null, 'The size point is the whole thing. My twenty-person chat is honest precisely because there is no algorithm waiting to reward a better version of me, and nobody in it has ever screenshot anything.', 344, now() - interval '46 minutes'),
  ('00000000-0000-4000-8000-a11000000000', '00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-a10000000000', 'Agreed on size, but I would add one condition: someone has to be able to leave without cost. Chats where leaving means losing the plans for Saturday keep people performing too.', 142, now() - interval '41 minutes'),
  ('00000000-0000-4000-8000-a11100000000', '00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000005', '00000000-0000-4000-8000-a11000000000', 'This is why the group that survived has three side chats nobody administers. Exit has to be cheap or the main chat turns into a stage.', 61, now() - interval '33 minutes'),
  ('00000000-0000-4000-8000-a12000000000', '00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000007', '00000000-0000-4000-8000-a10000000000', 'My favourite test: post something slightly wrong on purpose. In the chat, three people correct you within a minute and nobody mentions it again. On a feed, it becomes a quote tweet.', 88, now() - interval '37 minutes'),
  ('00000000-0000-4000-8000-a20000000000', '00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000004', null, 'Counterpoint: the group chat is honest because it is exclusive, and exclusivity is not a scalable property. Every attempt to bottle it ends up with a follow button and the problem returns.', 126, now() - interval '28 minutes'),
  ('00000000-0000-4000-8000-a21000000000', '00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-a20000000000', 'Which is exactly why I stopped expecting platforms to solve it. I treat the chat as the place I live and the feeds as the places I visit.', 91, now() - interval '21 minutes'),
  ('00000000-0000-4000-8000-a30000000000', '00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000003', null, 'Three-year group chat veteran here. Still going, still no memes with visible watermarks, still the only notification I do not mute.', 44, now() - interval '9 minutes'),
  ('00000000-0000-4000-8000-b10000000000', '00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000002', null, 'Saving this. The part about deciding it in the room, with a name attached to each item, is what most of these threads are missing — everything else becomes a follow-up that never happens.', 268, now() - interval '52 minutes'),
  ('00000000-0000-4000-8000-b11000000000', '00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-b10000000000', 'We started writing the decision as a single sentence at the bottom of the thread. If we cannot write the sentence, the answer was not really an answer.', 132, now() - interval '47 minutes'),
  ('00000000-0000-4000-8000-b11100000000', '00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000008', '00000000-0000-4000-8000-b11000000000', 'Stealing that. It also makes the archive readable six months later, which is the part everyone forgets when the thread is still warm.', 76, now() - interval '39 minutes'),
  ('00000000-0000-4000-8000-b12000000000', '00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-b10000000000', 'How do you handle the people who are not in the room? Ours are in three time zones and always find out afterwards.', 58, now() - interval '43 minutes'),
  ('00000000-0000-4000-8000-b12100000000', '00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-b12000000000', 'We post the sentence, not the minutes. If someone wants the reasoning they can ask in the thread — and they usually do, which is the point.', 94, now() - interval '36 minutes'),
  ('00000000-0000-4000-8000-b20000000000', '00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000005', null, 'Practical question for the people who have already done this: how long before it stopped feeling like extra work? Two weeks in and I am still writing every decision down by hand.', 126, now() - interval '26 minutes'),
  ('00000000-0000-4000-8000-b21000000000', '00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000006', '00000000-0000-4000-8000-b20000000000', 'About a month. The trick is that the writing replaces a meeting — once you notice the thread is doing the arguing for you, the habit pays for itself.', 91, now() - interval '19 minutes'),
  ('00000000-0000-4000-8000-b30000000000', '00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000007', null, 'Works better in writing than in a call, for whatever that is worth. Half the disagreement in ours was tone, and tone disappears the moment it is a paragraph.', 44, now() - interval '11 minutes')
on conflict (id) do nothing;

-- reactions (one per member per post)
insert into public.phf_reactions (post_id, user_id, kind) values
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000001', 'like'),
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000002', 'insight'),
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000003', 'fire'),
  ('00000000-0000-4000-8000-000000000102', '00000000-0000-4000-8000-000000000002', 'like'),
  ('00000000-0000-4000-8000-000000000102', '00000000-0000-4000-8000-000000000003', 'insight'),
  ('00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000003', 'like'),
  ('00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000004', 'insight'),
  ('00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000005', 'fire'),
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000004', 'like'),
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000005', 'insight'),
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000006', 'fire'),
  ('00000000-0000-4000-8000-000000000105', '00000000-0000-4000-8000-000000000005', 'like'),
  ('00000000-0000-4000-8000-000000000105', '00000000-0000-4000-8000-000000000006', 'insight'),
  ('00000000-0000-4000-8000-000000000106', '00000000-0000-4000-8000-000000000006', 'like'),
  ('00000000-0000-4000-8000-000000000106', '00000000-0000-4000-8000-000000000007', 'insight'),
  ('00000000-0000-4000-8000-000000000106', '00000000-0000-4000-8000-000000000008', 'fire'),
  ('00000000-0000-4000-8000-000000000107', '00000000-0000-4000-8000-000000000007', 'like'),
  ('00000000-0000-4000-8000-000000000107', '00000000-0000-4000-8000-000000000008', 'insight'),
  ('00000000-0000-4000-8000-000000000107', '00000000-0000-4000-8000-000000000001', 'fire'),
  ('00000000-0000-4000-8000-000000000108', '00000000-0000-4000-8000-000000000008', 'like'),
  ('00000000-0000-4000-8000-000000000108', '00000000-0000-4000-8000-000000000001', 'insight'),
  ('00000000-0000-4000-8000-000000000108', '00000000-0000-4000-8000-000000000002', 'fire'),
  ('00000000-0000-4000-8000-000000000109', '00000000-0000-4000-8000-000000000001', 'like'),
  ('00000000-0000-4000-8000-000000000109', '00000000-0000-4000-8000-000000000002', 'insight'),
  ('00000000-0000-4000-8000-000000000109', '00000000-0000-4000-8000-000000000003', 'fire'),
  ('00000000-0000-4000-8000-000000000110', '00000000-0000-4000-8000-000000000002', 'like'),
  ('00000000-0000-4000-8000-000000000110', '00000000-0000-4000-8000-000000000003', 'insight'),
  ('00000000-0000-4000-8000-000000000111', '00000000-0000-4000-8000-000000000003', 'like'),
  ('00000000-0000-4000-8000-000000000111', '00000000-0000-4000-8000-000000000004', 'insight'),
  ('00000000-0000-4000-8000-000000000112', '00000000-0000-4000-8000-000000000004', 'like'),
  ('00000000-0000-4000-8000-000000000112', '00000000-0000-4000-8000-000000000005', 'insight'),
  ('00000000-0000-4000-8000-000000000112', '00000000-0000-4000-8000-000000000006', 'fire'),
  ('00000000-0000-4000-8000-000000000113', '00000000-0000-4000-8000-000000000005', 'like'),
  ('00000000-0000-4000-8000-000000000113', '00000000-0000-4000-8000-000000000006', 'insight')
on conflict (post_id, user_id) do nothing;

-- saves
insert into public.phf_saves (post_id, user_id) values
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000003'),
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000004'),
  ('00000000-0000-4000-8000-000000000107', '00000000-0000-4000-8000-000000000005'),
  ('00000000-0000-4000-8000-000000000112', '00000000-0000-4000-8000-000000000006')
on conflict do nothing;

-- follows between demo members
insert into public.phf_follows (follower_id, target_id) values
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000002'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000003'),
  ('00000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000003'),
  ('00000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000004'),
  ('00000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-000000000004'),
  ('00000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-000000000005'),
  ('00000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-000000000005'),
  ('00000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-000000000006'),
  ('00000000-0000-4000-8000-000000000005', '00000000-0000-4000-8000-000000000006'),
  ('00000000-0000-4000-8000-000000000005', '00000000-0000-4000-8000-000000000007'),
  ('00000000-0000-4000-8000-000000000006', '00000000-0000-4000-8000-000000000007'),
  ('00000000-0000-4000-8000-000000000006', '00000000-0000-4000-8000-000000000008'),
  ('00000000-0000-4000-8000-000000000007', '00000000-0000-4000-8000-000000000008'),
  ('00000000-0000-4000-8000-000000000007', '00000000-0000-4000-8000-000000000001'),
  ('00000000-0000-4000-8000-000000000008', '00000000-0000-4000-8000-000000000001'),
  ('00000000-0000-4000-8000-000000000008', '00000000-0000-4000-8000-000000000002')
on conflict do nothing;

-- notifications for every non-demo member
insert into public.phf_notifications (id, actor_id, kind, post_id, text, created_at)
select v.id::uuid, v.actor_id::uuid, v.kind, v.post_id::uuid, v.text, now() - make_interval(mins => v.minutes)
from (values
  ('00000000-0000-4000-8000-000000000e01', '00000000-0000-4000-8000-000000000001', 'reply', '00000000-0000-4000-8000-000000000101', 'replied to your comment', 6),
  ('00000000-0000-4000-8000-000000000e02', '00000000-0000-4000-8000-000000000002', 'upvote', '00000000-0000-4000-8000-000000000102', 'upvoted your post', 48),
  ('00000000-0000-4000-8000-000000000e03', '00000000-0000-4000-8000-000000000003', 'mention', '00000000-0000-4000-8000-000000000103', 'mentioned you', 180),
  ('00000000-0000-4000-8000-000000000e04', '00000000-0000-4000-8000-000000000004', 'follow', null, 'started following you', 420),
  ('00000000-0000-4000-8000-000000000e05', '00000000-0000-4000-8000-000000000006', 'badge', '00000000-0000-4000-8000-000000000104', 'saved your comment', 900),
  ('00000000-0000-4000-8000-000000000e06', '00000000-0000-4000-8000-000000000005', 'reply', '00000000-0000-4000-8000-000000000106', 'replied to your thread', 1400)
) as v(id, actor_id, kind, post_id, text, minutes)
cross join public.phf_profiles pr
where pr.id not in ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-000000000005', '00000000-0000-4000-8000-000000000006', '00000000-0000-4000-8000-000000000007', '00000000-0000-4000-8000-000000000008')
on conflict (id) do nothing;

commit;