-- ============================================================
-- .phf — shared database schema
-- Naming convention: every table starts with phf_
-- Run this once in Supabase → SQL Editor → New query → Run.
-- ============================================================

-- ------------------------------------------------------------
-- profiles
-- ------------------------------------------------------------
create table if not exists public.phf_profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  handle      text unique not null,
  name        text not null,
  bio         text,
  avatar_url  text,
  role        text not null default 'member',
  created_at  timestamptz not null default now()
);

-- auto-create a profile whenever an auth user is created
create or replace function public.phf_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  base text;
  candidate text;
begin
  base := coalesce(
    nullif(trim(new.raw_user_meta_data ->> 'name'), ''),
    split_part(coalesce(new.email, 'member'), '@', 1)
  );
  base := regexp_replace(lower(base), '[^a-z0-9_]', '', 'g');
  if base = '' or base is null then
    base := 'member';
  end if;
  if length(base) > 18 then
    base := left(base, 18);
  end if;

  candidate := base;
  if exists (select 1 from public.phf_profiles where handle = candidate) then
    candidate := base || '_' || substr(md5(new.id::text), 1, 6);
  end if;

  insert into public.phf_profiles (id, handle, name)
  values (
    new.id,
    candidate,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'name'), ''), candidate)
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists phf_on_auth_user_created on auth.users;
create trigger phf_on_auth_user_created
  after insert on auth.users
  for each row execute function public.phf_handle_new_user();

-- ------------------------------------------------------------
-- categories (the 7 rooms)
-- ------------------------------------------------------------
create table if not exists public.phf_categories (
  id          text primary key,
  name        text not null,
  short       text not null,
  icon        text not null default 'Messages2',
  description text,
  members     integer not null default 0,
  online      integer not null default 0,
  created_at  timestamptz not null default now()
);

insert into public.phf_categories (id, name, short, icon, members, online) values
  ('announcements', 'Announcements & Community', 'Announcements', 'Notification', 412300, 3841),
  ('general',       'General Discussion',        'General',       'Messages2',   386700, 4102),
  ('culture',       'Culture & Lifestyle',       'Culture',       'Colorfilter',  241800, 1976),
  ('ofw',           'OFW & Overseas Life',       'OFW',           'Airplane',     298400, 5210),
  ('work',          'Work, Money & Business',    'Work & Money',  'Chart21',      187900, 1644),
  ('marketplace',   'Marketplace',               'Marketplace',   'Shop',          96400,  981),
  ('support',       'Help & Support',            'Support',       'Lifebelt',      74200,  743)
on conflict (id) do nothing;

-- ------------------------------------------------------------
-- posts
-- ------------------------------------------------------------
create table if not exists public.phf_posts (
  id           uuid primary key default gen_random_uuid(),
  author_id    uuid not null references public.phf_profiles (id) on delete cascade,
  category     text not null references public.phf_categories (id),
  title        text not null,
  excerpt      text,
  body         text,
  tags         text[] not null default '{}',
  media        text,
  pinned       boolean not null default false,
  comment_count integer not null default 0,
  created_at   timestamptz not null default now()
);

create index if not exists phf_posts_category_idx  on public.phf_posts (category, created_at desc);
create index if not exists phf_posts_author_idx    on public.phf_posts (author_id, created_at desc);

-- ------------------------------------------------------------
-- comments
-- ------------------------------------------------------------
create table if not exists public.phf_comments (
  id         uuid primary key default gen_random_uuid(),
  post_id    uuid not null references public.phf_posts (id) on delete cascade,
  author_id  uuid not null references public.phf_profiles (id) on delete cascade,
  parent_id  uuid references public.phf_comments (id) on delete cascade,
  body       text not null,
  score      integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists phf_comments_post_idx on public.phf_comments (post_id, created_at);

-- ------------------------------------------------------------
-- reactions (like / insight / fire)
-- ------------------------------------------------------------
create table if not exists public.phf_reactions (
  id         uuid primary key default gen_random_uuid(),
  post_id    uuid not null references public.phf_posts (id) on delete cascade,
  user_id    uuid not null references public.phf_profiles (id) on delete cascade,
  kind       text not null check (kind in ('like', 'insight', 'fire')),
  created_at timestamptz not null default now(),
  unique (post_id, user_id)
);

create index if not exists phf_reactions_post_idx on public.phf_reactions (post_id);

-- ------------------------------------------------------------
-- saves
-- ------------------------------------------------------------
create table if not exists public.phf_saves (
  post_id    uuid not null references public.phf_posts (id) on delete cascade,
  user_id    uuid not null references public.phf_profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

-- ------------------------------------------------------------
-- follows (people + rooms)
-- ------------------------------------------------------------
create table if not exists public.phf_follows (
  follower_id uuid not null references public.phf_profiles (id) on delete cascade,
  target_id   uuid not null references public.phf_profiles (id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (follower_id, target_id)
);

create table if not exists public.phf_room_members (
  user_id    uuid not null references public.phf_profiles (id) on delete cascade,
  category   text not null references public.phf_categories (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, category)
);

-- ------------------------------------------------------------
-- notifications
-- ------------------------------------------------------------
create table if not exists public.phf_notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.phf_profiles (id) on delete cascade,
  actor_id   uuid references public.phf_profiles (id) on delete set null,
  kind       text not null default 'reply',
  post_id    uuid references public.phf_posts (id) on delete cascade,
  text       text,
  read       boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists phf_notifications_user_idx on public.phf_notifications (user_id, read, created_at desc);

-- ============================================================
-- Row Level Security
-- ============================================================
alter table public.phf_profiles      enable row level security;
alter table public.phf_categories    enable row level security;
alter table public.phf_posts         enable row level security;
alter table public.phf_comments      enable row level security;
alter table public.phf_reactions     enable row level security;
alter table public.phf_saves         enable row level security;
alter table public.phf_follows       enable row level security;
alter table public.phf_room_members  enable row level security;
alter table public.phf_notifications enable row level security;

-- profiles
drop policy if exists "phf_profiles_select" on public.phf_profiles;
create policy "phf_profiles_select" on public.phf_profiles
  for select using (true);
drop policy if exists "phf_profiles_insert_own" on public.phf_profiles;
create policy "phf_profiles_insert_own" on public.phf_profiles
  for insert with check (auth.uid() = id);
drop policy if exists "phf_profiles_update_own" on public.phf_profiles;
create policy "phf_profiles_update_own" on public.phf_profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- categories
drop policy if exists "phf_categories_select" on public.phf_categories;
create policy "phf_categories_select" on public.phf_categories
  for select using (true);

-- posts
drop policy if exists "phf_posts_select" on public.phf_posts;
create policy "phf_posts_select" on public.phf_posts
  for select using (true);
drop policy if exists "phf_posts_insert_own" on public.phf_posts;
create policy "phf_posts_insert_own" on public.phf_posts
  for insert with check (auth.uid() = author_id);
drop policy if exists "phf_posts_update_own" on public.phf_posts;
create policy "phf_posts_update_own" on public.phf_posts
  for update using (auth.uid() = author_id) with check (auth.uid() = author_id);
drop policy if exists "phf_posts_delete_own" on public.phf_posts;
create policy "phf_posts_delete_own" on public.phf_posts
  for delete using (auth.uid() = author_id);

-- comments
drop policy if exists "phf_comments_select" on public.phf_comments;
create policy "phf_comments_select" on public.phf_comments
  for select using (true);
drop policy if exists "phf_comments_insert_own" on public.phf_comments;
create policy "phf_comments_insert_own" on public.phf_comments
  for insert with check (auth.uid() = author_id);
drop policy if exists "phf_comments_delete_own" on public.phf_comments;
create policy "phf_comments_delete_own" on public.phf_comments
  for delete using (auth.uid() = author_id);

-- reactions
drop policy if exists "phf_reactions_select" on public.phf_reactions;
create policy "phf_reactions_select" on public.phf_reactions
  for select using (true);
drop policy if exists "phf_reactions_insert_own" on public.phf_reactions;
create policy "phf_reactions_insert_own" on public.phf_reactions
  for insert with check (auth.uid() = user_id);
drop policy if exists "phf_reactions_delete_own" on public.phf_reactions;
create policy "phf_reactions_delete_own" on public.phf_reactions
  for delete using (auth.uid() = user_id);

-- saves
drop policy if exists "phf_saves_select" on public.phf_saves;
create policy "phf_saves_select" on public.phf_saves
  for select using (true);
drop policy if exists "phf_saves_insert_own" on public.phf_saves;
create policy "phf_saves_insert_own" on public.phf_saves
  for insert with check (auth.uid() = user_id);
drop policy if exists "phf_saves_delete_own" on public.phf_saves;
create policy "phf_saves_delete_own" on public.phf_saves
  for delete using (auth.uid() = user_id);

-- follows
drop policy if exists "phf_follows_all_own" on public.phf_follows;
create policy "phf_follows_all_own" on public.phf_follows
  for all using (auth.uid() = follower_id) with check (auth.uid() = follower_id);
drop policy if exists "phf_follows_select" on public.phf_follows;
create policy "phf_follows_select" on public.phf_follows
  for select using (true);

-- room members
drop policy if exists "phf_room_members_all_own" on public.phf_room_members;
create policy "phf_room_members_all_own" on public.phf_room_members
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "phf_room_members_select" on public.phf_room_members;
create policy "phf_room_members_select" on public.phf_room_members
  for select using (true);

-- notifications (private)
drop policy if exists "phf_notifications_select_own" on public.phf_notifications;
create policy "phf_notifications_select_own" on public.phf_notifications
  for select using (auth.uid() = user_id);
drop policy if exists "phf_notifications_update_own" on public.phf_notifications;
create policy "phf_notifications_update_own" on public.phf_notifications
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "phf_notifications_insert_any" on public.phf_notifications;
create policy "phf_notifications_insert_any" on public.phf_notifications
  for insert with check (true);
