import { createClient } from '@supabase/supabase-js'
const db = createClient('https://pqjlfumddqoqnhvesyba.supabase.co', 'sb_publishable_0fczz14DX13oAThmHT6Krw_R-rdhQV8', { auth: { persistSession: false } })
for (const table of ['phf_categories', 'phf_posts', 'phf_profiles', 'phf_reactions', 'phf_saves', 'phf_comments', 'phf_notifications', 'phf_room_members']) {
  const { count, error } = await db.from(table).select('*', { count: 'exact', head: true })
  console.log(table.padEnd(20), error ? `ERROR ${error.message}` : `rows=${count}`)
}