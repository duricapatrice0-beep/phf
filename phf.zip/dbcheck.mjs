import { createClient } from '@supabase/supabase-js'
const url = process.env.VITE_SUPABASE_URL || 'https://pqjlfumddqoqnhvesyba.supabase.co'
const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_0fczz14DX13oAThmHT6Krw_R-rdhQV8'
const db = createClient(url, key, { auth: { persistSession: false } })
for (const table of ['phf_categories', 'phf_posts', 'phf_profiles', 'phf_reactions', 'phf_saves', 'phf_comments', 'phf_notifications']) {
  const { data, error } = await db.from(table).select('*', { count: 'exact', head: true })
  console.log(table.padEnd(20), error ? `ERROR: ${error.message} (${error.code || ''})` : `OK count=${data === null ? 'n/a' : ''} ✓`)
}
const { data: cats, error: catErr } = await db.from('phf_categories').select('id, name').limit(3)
console.log('categories sample:', catErr ? catErr.message : JSON.stringify(cats))
const { data: auth } = await db.auth.getSession()
console.log('anon auth session:', auth?.session ? 'signed in' : 'anonymous')