import { createClient } from '@supabase/supabase-js'
const db = createClient('https://pqjlfumddqoqnhvesyba.supabase.co', 'sb_publishable_0fczz14DX13oAThmHT6Krw_R-rdhQV8', { auth: { persistSession: false } })
const { data: auth, error } = await db.auth.signInWithPassword({ email: 'qa-phf@example.com', password: 'phf-test-1234' })
if (error) { console.log('signin failed:', error.message); process.exit(1) }
const uid = auth.user.id
console.log('signed in as', uid)

const events = []
const channel = db.channel('probe')
  .on('postgres_changes', { event: '*', schema: 'public', table: 'phf_posts' }, (payload) => events.push('posts:' + payload.eventType))
  .on('postgres_changes', { event: '*', schema: 'public', table: 'phf_profiles' }, (payload) => events.push('profiles:' + payload.eventType))
  .subscribe((status) => console.log('channel status:', status))
await new Promise((r) => setTimeout(r, 2500))

const { data: post, error: insErr } = await db.from('phf_posts').insert({
  author_id: uid, category: 'announcements', title: 'Realtime probe', excerpt: 'probe', body: 'probe body'
}).select('id').single()
console.log('insert:', insErr ? insErr.message : post.id)
await new Promise((r) => setTimeout(r, 4000))
console.log('events received:', events.length ? events.join(', ') : 'NONE (realtime publication missing)')
if (post) { await db.from('phf_posts').delete().eq('id', post.id); console.log('probe row deleted') }
await db.auth.signOut()
process.exit(0)