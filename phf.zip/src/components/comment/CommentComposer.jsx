import { useState } from 'react'
import { motion } from 'framer-motion'
import { useStore } from '../../lib/store'
import Avatar from '../ui/Avatar'
import { Hashtag, Link1, PenTool, Send2 } from '../icons'

const TOOLBAR = [
  { icon: PenTool, label: 'Bold' },
  { icon: Link1, label: 'Link' },
  { icon: Hashtag, label: 'Quote' },
]

export default function CommentComposer({ postId = null, parentId = null, placeholder = 'Add to the discussion…', onSent }) {
  const { me, addComment } = useStore()
  const [value, setValue] = useState('')
  const [focused, setFocused] = useState(false)
  const [busy, setBusy] = useState(false)

  const submit = async () => {
    if (!value.trim() || busy || !postId) return
    setBusy(true)
    const { error } = await addComment(postId, value, parentId)
    setBusy(false)
    if (!error) {
      setValue('')
      onSent?.()
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.12, ease: [0.16, 1, 0.3, 1] }}
      className={`flex gap-3 rounded-2xl border bg-surface p-3.5 transition-all duration-300 sm:p-4 ${
        focused ? 'border-white/20 shadow-panel' : 'border-line'
      }`}
    >
      <Avatar user={me} size="md" className="mt-0.5" />
      <div className="min-w-0 flex-1">
        <textarea
          rows={focused ? 4 : 2}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onKeyDown={(event) => {
            if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') submit()
          }}
          placeholder={placeholder}
          aria-label="Write a comment"
          className="w-full resize-none bg-transparent text-[14.5px] leading-relaxed text-white placeholder:text-faint focus:outline-none"
        />
        <div className="mt-2 flex items-center gap-1 border-t border-line pt-2.5">
          {TOOLBAR.map((tool) => (
            <button
              key={tool.label}
              type="button"
              aria-label={tool.label}
              className="flex h-7 w-7 items-center justify-center rounded-md text-faint transition-colors hover:bg-white/[0.06] hover:text-white"
            >
              <tool.icon size={14} variant="Bold" />
            </button>
          ))}
          <span className="ml-1 text-[11px] text-faint">
            Markdown supported · <span className="text-dim">⌘ + Enter</span>
          </span>
          <motion.button
            type="button"
            onClick={submit}
            disabled={!value.trim() || busy || !postId}
            className="ml-auto inline-flex h-8 items-center gap-1.5 rounded-lg bg-white px-3 text-[12.5px] font-semibold text-black transition-opacity disabled:opacity-30"
          >
            <Send2 size={14} variant="Bold" />
            {busy ? 'Posting…' : 'Comment'}
          </motion.button>
        </div>
      </div>
    </motion.div>
  )
}
