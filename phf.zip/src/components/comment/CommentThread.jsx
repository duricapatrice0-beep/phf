import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { useRouter, Link } from '../../lib/router'
import { ArrowDown2, Edit, Like1, Messages2, Share, Timer, Trash } from '../icons'
import Avatar from '../ui/Avatar'
import PointsBadge from '../ui/PointsBadge'
import OverflowMenu from '../ui/Menu'
import ConfirmDialog from '../ui/ConfirmDialog'
import { useStore } from '../../lib/store'
import { compact, timeAgo } from '../../lib/format'

function LikeButton({ comment }) {
  const { isCommentVoted, toggleCommentVote } = useStore()
  const voted = isCommentVoted(comment.id)

  return (
    <button
      type="button"
      onClick={() => toggleCommentVote(comment.id)}
      aria-pressed={voted}
      className={`inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[12px] font-medium transition-colors ${
        voted ? 'bg-red-900 text-white' : 'text-faint hover:bg-white/[0.05] hover:text-white'
      }`}
    >
      <Like1 size={14} variant="Bold" />
      {compact(comment.score)}
    </button>
  )
}

function InlineReply({ onCancel, onSubmit }) {
  const [value, setValue] = useState('')
  const [busy, setBusy] = useState(false)

  const send = async () => {
    if (!value.trim() || busy) return
    setBusy(true)
    const { error } = await onSubmit(value)
    setBusy(false)
    if (!error) onCancel()
  }

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
      className="overflow-hidden"
    >
      <div className="mt-3 flex gap-2.5">
        <div className="h-7 w-7 shrink-0 rounded-full bg-white/80" />
        <div className="flex-1 rounded-xl border border-line bg-raised transition-colors focus-within:border-white/25">
          <textarea
            autoFocus
            rows={2}
            value={value}
            onChange={(event) => setValue(event.target.value)}
            placeholder="Write a reply…"
            className="w-full resize-none bg-transparent px-3 py-2.5 text-[13.5px] text-white placeholder:text-faint focus:outline-none"
          />
          <div className="flex justify-end gap-2 border-t border-line px-2.5 py-2">
            <button
              type="button"
              onClick={onCancel}
              className="h-7 rounded-lg px-2.5 text-[12.5px] text-dim transition-colors hover:text-white"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={send}
              disabled={!value.trim() || busy}
              className="h-7 rounded-lg bg-white px-3 text-[12.5px] font-semibold text-black transition-opacity disabled:opacity-35"
            >
              {busy ? 'Posting…' : 'Reply'}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export function CommentItem({ comment, postId, depth = 0 }) {
  const { navigate } = useRouter()
  const { userByHandle, addComment, me, updateComment, deleteComment } = useStore()
  const [collapsed, setCollapsed] = useState(false)
  const [repliesOpen, setRepliesOpen] = useState(depth === 0)
  const [replying, setReplying] = useState(false)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState(null)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [copied, setCopied] = useState(false)
  const author = userByHandle(comment.author) || { handle: comment.author, name: comment.author, seed: 0, role: 'Member', karma: 0 }
  const hasReplies = comment.replies && comment.replies.length > 0
  const replyCount = countReplies(comment)
  const isOwn = Boolean(me?.id && comment.authorId === me.id)

  const startEdit = () => {
    setDraft(comment.body)
    setError(null)
    setCollapsed(false)
    setEditing(true)
  }

  const saveEdit = async () => {
    const text = draft.trim()
    if (!text || busy) return
    setBusy(true)
    setError(null)
    const result = await updateComment(comment.id, text)
    setBusy(false)
    if (result.error) setError(result.error)
    else setEditing(false)
  }

  const remove = async () => {
    setBusy(true)
    setError(null)
    const result = await deleteComment(comment.id)
    setBusy(false)
    if (result.error) setError(result.error)
    else setConfirmDelete(false)
  }

  const share = () => {
    navigator.clipboard?.writeText(`${window.location.origin}/#/post/${postId}`)
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1600)
  }

  return (
    <div className={depth > 0 ? 'relative pl-4 sm:pl-5' : ''}>
      {depth > 0 ? <span className="absolute top-0 bottom-4 left-0 w-px bg-line" /> : null}
      <div className="flex gap-3 py-3.5">
        <button type="button" onClick={() => navigate(`/u/${author.handle}`)} className="shrink-0 self-start">
          <Avatar user={author} size="sm" />
        </button>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Link
              to={`/u/${author.handle}`}
              className="text-[13px] font-semibold text-white transition-opacity hover:opacity-75"
            >
              {author.name}
            </Link>
            <PointsBadge points={author.karma || 0} size="xs" />
            {author.role !== 'Member' && author.role !== 'New' ? (
              <span className="rounded border border-white/15 px-1.5 py-0.5 text-[9.5px] font-semibold tracking-wide text-mute uppercase">
                {author.role}
              </span>
            ) : null}
            <span className="inline-flex items-center gap-1 text-[11.5px] text-faint">
              <span>·</span>
              <Timer size={11} variant="Bold" />
              {timeAgo(comment.minutes)}
            </span>
            {comment.editedAt ? <span className="text-[11.5px] text-faint">· edited</span> : null}

            <span className="ml-auto flex items-center gap-1">
              {isOwn ? (
                <OverflowMenu
                  label="Comment options"
                  items={[
                    { icon: Edit, label: 'Edit comment', onClick: startEdit },
                    { icon: Trash, label: 'Delete comment', danger: true, onClick: () => setConfirmDelete(true) },
                  ]}
                />
              ) : null}
              <button
                type="button"
                onClick={() => setCollapsed((value) => !value)}
                aria-label={collapsed ? 'Expand comment' : 'Collapse comment'}
                className="flex h-7 w-7 items-center justify-center rounded-md text-faint transition-colors hover:bg-white/5 hover:text-white"
              >
                <motion.span
                  animate={{ rotate: collapsed ? -90 : 0 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 26 }}
                  className="inline-flex"
                >
                  <ArrowDown2 size={14} variant="Bold" />
                </motion.span>
              </button>
            </span>
          </div>

          <AnimatePresence initial={false}>
            {!collapsed ? (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className="overflow-hidden"
              >
                {editing ? (
                  <div className="mt-1.5 rounded-xl border border-line bg-raised transition-colors focus-within:border-white/25">
                    <textarea
                      autoFocus
                      rows={3}
                      value={draft}
                      onChange={(event) => setDraft(event.target.value)}
                      className="w-full resize-none bg-transparent px-3 py-2.5 text-[14px] leading-relaxed text-white focus:outline-none"
                    />
                    <div className="flex justify-end gap-2 border-t border-line px-2.5 py-2">
                      <button
                        type="button"
                        onClick={() => setEditing(false)}
                        className="h-7 rounded-lg px-2.5 text-[12.5px] text-dim transition-colors hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={saveEdit}
                        disabled={!draft.trim() || busy}
                        className="h-7 rounded-lg bg-white px-3 text-[12.5px] font-semibold text-black transition-opacity disabled:opacity-35"
                      >
                        {busy ? 'Saving…' : 'Save'}
                      </button>
                    </div>
                    {error ? (
                      <p className="border-t border-red-900 bg-red-900/20 px-3 py-1.5 text-[11.5px] text-white">{error}</p>
                    ) : null}
                  </div>
                ) : (
                  <p className="mt-1.5 text-[14px] leading-[1.65] text-mute">{comment.body}</p>
                )}

                <div className="mt-2 flex items-center gap-1">
                  <LikeButton comment={comment} />
                  <button
                    type="button"
                    onClick={() => {
                      setReplying((value) => !value)
                      setRepliesOpen(true)
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[12px] font-medium text-faint transition-colors hover:bg-white/[0.05] hover:text-white"
                  >
                    <Messages2 size={14} variant="Bold" />
                    Reply
                  </button>
                  <button
                    type="button"
                    onClick={share}
                    className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[12px] font-medium text-faint transition-colors hover:bg-white/[0.05] hover:text-white"
                  >
                    <Share size={14} variant="Bold" />
                    {copied ? 'Copied' : 'Share'}
                  </button>
                </div>

                <AnimatePresence initial={false}>
                  {replying ? (
                    <InlineReply
                      onCancel={() => setReplying(false)}
                      onSubmit={(body) => addComment(postId, body, comment.id)}
                    />
                  ) : null}
                </AnimatePresence>

                {hasReplies ? (
                  <div className="mt-2">
                    <button
                      type="button"
                      onClick={() => setRepliesOpen((value) => !value)}
                      className="group inline-flex items-center gap-2 text-[12px] font-medium text-mute transition-colors hover:text-white"
                    >
                      <span
                        className="h-px w-5 bg-white/25 transition-all duration-300 group-hover:w-8 group-hover:bg-white"
                      />
                      <motion.span
                        animate={{ rotate: repliesOpen ? 180 : 0 }}
                        transition={{ type: 'spring', stiffness: 400, damping: 26 }}
                        className="inline-flex"
                      >
                        <ArrowDown2 size={13} variant="Bold" />
                      </motion.span>
                      {repliesOpen ? 'Hide' : 'Show'} {replyCount} {replyCount === 1 ? 'reply' : 'replies'}
                    </button>

                    <AnimatePresence initial={false}>
                      {repliesOpen ? (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.36, ease: [0.16, 1, 0.3, 1] }}
                          className="overflow-hidden"
                        >
                          <div className="mt-1 divide-y divide-line/60">
                            {comment.replies.map((reply, index) => (
                              <motion.div
                                key={reply.id}
                                initial={{ opacity: 0, x: -8 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ duration: 0.35, delay: index * 0.05, ease: [0.16, 1, 0.3, 1] }}
                              >
                                <CommentItem comment={reply} postId={postId} depth={depth + 1} />
                              </motion.div>
                            ))}
                          </div>
                        </motion.div>
                      ) : null}
                    </AnimatePresence>
                  </div>
                ) : null}
              </motion.div>
            ) : (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="mt-1.5 text-[12.5px] text-faint italic"
              >
                {replyCount > 0 ? `${replyCount} replies hidden` : 'Comment hidden'}
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      </div>

      <ConfirmDialog
        open={confirmDelete}
        onClose={() => {
          setConfirmDelete(false)
          setError(null)
        }}
        onConfirm={remove}
        busy={busy}
        error={error}
        title="Delete this comment?"
        body="Replies underneath go with it. This cannot be undone."
      />
    </div>
  )
}

function countReplies(comment) {
  if (!comment.replies) return 0
  return comment.replies.reduce((total, reply) => total + 1 + countReplies(reply), 0)
}

export default function CommentThread({ postId, sort = 'best' }) {
  const { getComments } = useStore()
  const comments = [...getComments(postId)]
  if (sort === 'best') comments.sort((a, b) => b.score - a.score)
  if (sort === 'new') comments.reverse()

  return (
    <div className="divide-y divide-line">
      {comments.map((comment, index) => (
        <motion.div
          key={comment.id}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.1 + index * 0.06, ease: [0.16, 1, 0.3, 1] }}
        >
          <CommentItem comment={comment} postId={postId} />
        </motion.div>
      ))}
      {!comments.length ? (
        <p className="py-6 text-center text-[13px] text-faint">
          No replies yet — start the discussion.
        </p>
      ) : null}
    </div>
  )
}
