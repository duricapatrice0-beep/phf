import { createElement } from 'react'
import {
  Add as RawAdd,
  AddCircle as RawAddCircle,
  Airplane as RawAirplane,
  AlignLeft as RawAlignLeft,
  Archive as RawArchive,
  ArrowDown as RawArrowDown,
  ArrowDown2 as RawArrowDown2,
  ArrowDown3 as RawArrowDown3,
  ArrowLeft as RawArrowLeft,
  ArrowLeft2 as RawArrowLeft2,
  ArrowRight as RawArrowRight,
  ArrowRight3 as RawArrowRight3,
  ArrowUp as RawArrowUp,
  ArrowUp2 as RawArrowUp2,
  Bookmark as RawBookmark,
  Bookmark2 as RawBookmark2,
  Book1 as RawBook1,
  Bitcoin as RawBitcoin,
  Calendar as RawCalendar,
  Camera as RawCamera,
  Category as RawCategory,
  Chart21 as RawChart21,
  ChartSquare as RawChartSquare,
  Clock as RawClock,
  CloseCircle as RawCloseCircle,
  Code as RawCode,
  CodeCircle as RawCodeCircle,
  Coffee as RawCoffee,
  Colorfilter as RawColorfilter,
  Copy as RawCopy,
  CpuSetting as RawCpuSetting,
  Crown as RawCrown,
  Danger as RawDanger,
  Data as RawData,
  DirectInbox as RawDirectInbox,
  Dislike as RawDislike,
  Document as RawDocument,
  Edit as RawEdit,
  Element3 as RawElement3,
  Eye as RawEye,
  EyeSlash as RawEyeSlash,
  Filter as RawFilter,
  Flash as RawFlash,
  Folder as RawFolder,
  Gameboy as RawGameboy,
  Global as RawGlobal,
  Grid1 as RawGrid1,
  HambergerMenu as RawHambergerMenu,
  Hashtag as RawHashtag,
  Headphone as RawHeadphone,
  Heart as RawHeart,
  Home2 as RawHome2,
  Information as RawInformation,
  Layer as RawLayer,
  Like1 as RawLike1,
  Link1 as RawLink1,
  Logout as RawLogout,
  Menu as RawMenu,
  Medal as RawMedal,
  Message as RawMessage,
  MessageQuestion as RawMessageQuestion,
  Messages2 as RawMessages2,
  Microphone as RawMicrophone,
  Mobile as RawMobile,
  Monitor as RawMonitor,
  Moon as RawMoon,
  More as RawMore,
  More2 as RawMore2,
  Music as RawMusic,
  Note as RawNote,
  Notification as RawNotification,
  People as RawPeople,
  PenTool as RawPenTool,
  Profile2User as RawProfile2User,
  QuoteDown as RawQuoteDown,
  Ranking as RawRanking,
  Refresh as RawRefresh,
  SearchNormal as RawSearchNormal,
  Send2 as RawSend2,
  Setting as RawSetting,
  Setting2 as RawSetting2,
  Share as RawShare,
  Shield as RawShield,
  Sort as RawSort,
  Star as RawStar,
  Star1 as RawStar1,
  Sun as RawSun,
  Text as RawText,
  TickCircle as RawTickCircle,
  Timer as RawTimer,
  Trash as RawTrash,
  TrendUp as RawTrendUp,
  User as RawUser,
  UserAdd as RawUserAdd,
  UserTick as RawUserTick,
  Verify as RawVerify,
  Video as RawVideo,
} from 'iconsax-react'

function withDefaults(Component, name) {
  function Icon(props) {
    return createElement(Component, { variant: 'Bold', color: 'currentColor', size: 24, ...props })
  }
  Icon.displayName = name
  return Icon
}

export const Add = withDefaults(RawAdd, 'Add')
export const AddCircle = withDefaults(RawAddCircle, 'AddCircle')
export const Airplane = withDefaults(RawAirplane, 'Airplane')
export const AlignLeft = withDefaults(RawAlignLeft, 'AlignLeft')
export const Archive = withDefaults(RawArchive, 'Archive')
export const ArrowDown = withDefaults(RawArrowDown, 'ArrowDown')
export const ArrowDown2 = withDefaults(RawArrowDown2, 'ArrowDown2')
export const ArrowDown3 = withDefaults(RawArrowDown3, 'ArrowDown3')
export const ArrowLeft = withDefaults(RawArrowLeft, 'ArrowLeft')
export const ArrowLeft2 = withDefaults(RawArrowLeft2, 'ArrowLeft2')
export const ArrowRight = withDefaults(RawArrowRight, 'ArrowRight')
export const ArrowRight3 = withDefaults(RawArrowRight3, 'ArrowRight3')
export const ArrowUp = withDefaults(RawArrowUp, 'ArrowUp')
export const ArrowUp2 = withDefaults(RawArrowUp2, 'ArrowUp2')
export const Bookmark = withDefaults(RawBookmark, 'Bookmark')
export const Bookmark2 = withDefaults(RawBookmark2, 'Bookmark2')
export const Book1 = withDefaults(RawBook1, 'Book1')
export const Bitcoin = withDefaults(RawBitcoin, 'Bitcoin')
export const Calendar = withDefaults(RawCalendar, 'Calendar')
export const Camera = withDefaults(RawCamera, 'Camera')
export const Category = withDefaults(RawCategory, 'Category')
export const Chart21 = withDefaults(RawChart21, 'Chart21')
export const ChartSquare = withDefaults(RawChartSquare, 'ChartSquare')
export const Clock = withDefaults(RawClock, 'Clock')
export const CloseCircle = withDefaults(RawCloseCircle, 'CloseCircle')
export const Code = withDefaults(RawCode, 'Code')
export const CodeCircle = withDefaults(RawCodeCircle, 'CodeCircle')
export const Coffee = withDefaults(RawCoffee, 'Coffee')
export const Colorfilter = withDefaults(RawColorfilter, 'Colorfilter')
export const Copy = withDefaults(RawCopy, 'Copy')
export const CpuSetting = withDefaults(RawCpuSetting, 'CpuSetting')
export const Crown = withDefaults(RawCrown, 'Crown')
export const Danger = withDefaults(RawDanger, 'Danger')
export const Data = withDefaults(RawData, 'Data')
export const DirectInbox = withDefaults(RawDirectInbox, 'DirectInbox')
export const Dislike = withDefaults(RawDislike, 'Dislike')
export const Document = withDefaults(RawDocument, 'Document')
export const Edit = withDefaults(RawEdit, 'Edit')
export const Element3 = withDefaults(RawElement3, 'Element3')
export const Eye = withDefaults(RawEye, 'Eye')
export const EyeSlash = withDefaults(RawEyeSlash, 'EyeSlash')
export const Filter = withDefaults(RawFilter, 'Filter')
export const Flash = withDefaults(RawFlash, 'Flash')
export const Folder = withDefaults(RawFolder, 'Folder')
export const Gameboy = withDefaults(RawGameboy, 'Gameboy')
export const Global = withDefaults(RawGlobal, 'Global')
export const Grid1 = withDefaults(RawGrid1, 'Grid1')
export const HambergerMenu = withDefaults(RawHambergerMenu, 'HambergerMenu')
export const Hashtag = withDefaults(RawHashtag, 'Hashtag')
export const Headphone = withDefaults(RawHeadphone, 'Headphone')
export const Heart = withDefaults(RawHeart, 'Heart')
export const Home2 = withDefaults(RawHome2, 'Home2')
export const Information = withDefaults(RawInformation, 'Information')
export const Layer = withDefaults(RawLayer, 'Layer')
export const Like1 = withDefaults(RawLike1, 'Like1')
export const Link1 = withDefaults(RawLink1, 'Link1')
export const Logout = withDefaults(RawLogout, 'Logout')
export const Menu = withDefaults(RawMenu, 'Menu')
export const Medal = withDefaults(RawMedal, 'Medal')
export const Message = withDefaults(RawMessage, 'Message')
export const MessageQuestion = withDefaults(RawMessageQuestion, 'MessageQuestion')
export const Messages2 = withDefaults(RawMessages2, 'Messages2')
export const Microphone = withDefaults(RawMicrophone, 'Microphone')
export const Mobile = withDefaults(RawMobile, 'Mobile')
export const Monitor = withDefaults(RawMonitor, 'Monitor')
export const Moon = withDefaults(RawMoon, 'Moon')
export const More = withDefaults(RawMore, 'More')
export const More2 = withDefaults(RawMore2, 'More2')
export const Music = withDefaults(RawMusic, 'Music')
export const Note = withDefaults(RawNote, 'Note')
export const Notification = withDefaults(RawNotification, 'Notification')
export const People = withDefaults(RawPeople, 'People')
export const PenTool = withDefaults(RawPenTool, 'PenTool')
export const Profile2User = withDefaults(RawProfile2User, 'Profile2User')
export const QuoteDown = withDefaults(RawQuoteDown, 'QuoteDown')
export const Ranking = withDefaults(RawRanking, 'Ranking')
export const Refresh = withDefaults(RawRefresh, 'Refresh')
export const SearchNormal = withDefaults(RawSearchNormal, 'SearchNormal')
export const Send2 = withDefaults(RawSend2, 'Send2')
export const Setting = withDefaults(RawSetting, 'Setting')
export const Setting2 = withDefaults(RawSetting2, 'Setting2')
export const Share = withDefaults(RawShare, 'Share')
export const Shield = withDefaults(RawShield, 'Shield')
export const Sort = withDefaults(RawSort, 'Sort')
export const Star = withDefaults(RawStar, 'Star')
export const Star1 = withDefaults(RawStar1, 'Star1')
export const Sun = withDefaults(RawSun, 'Sun')
export const Text = withDefaults(RawText, 'Text')
export const TickCircle = withDefaults(RawTickCircle, 'TickCircle')
export const Timer = withDefaults(RawTimer, 'Timer')
export const Trash = withDefaults(RawTrash, 'Trash')
export const TrendUp = withDefaults(RawTrendUp, 'TrendUp')
export const User = withDefaults(RawUser, 'User')
export const UserAdd = withDefaults(RawUserAdd, 'UserAdd')
export const UserTick = withDefaults(RawUserTick, 'UserTick')
export const Verify = withDefaults(RawVerify, 'Verify')
export const Video = withDefaults(RawVideo, 'Video')