import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Heart } from '../icons'
import { compact } from '../../lib/format'

export default function ReactionBar({ reactions = [], picked = null, className = '', onPick }) {
  const [open, setOpen] = useState(false)

  if (!reactions.length) return null

  // Only kinds that were actually voted (count > 0) render as icons —
  // an unvoted post shows no reaction icon at all until someone votes.
  const visible = reactions.filter((reaction) => reaction.count > 0)
  const total = visible.reduce((sum, item) => sum + item.count, 0)
  const ordered = picked
    ? [visible.find((item) => item.key === picked), ...visible.filter((item) => item.key !== picked)].filter(
        Boolean,
      )
    : visible

  const pick = (key) => {
    const next = picked === key ? null : key
    onPick?.(next)
  }

  return (
    <div
      className={`relative inline-flex ${className}`}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        type="button"
        aria-haspopup="true"
        aria-expanded={open}
        aria-label="Reactions"
        onClick={(event) => {
          event.stopPropagation()
          setOpen((value) => !value)
        }}
        className={`group flex h-8 items-center rounded-full border border-line bg-raised transition-colors duration-150 hover:border-white/30 ${
          ordered.length ? 'gap-2 pl-1.5 pr-3' : 'px-2'
        }`}
      >
        {ordered.length ? (
          <span className="flex -space-x-1.5">
            {ordered.map((reaction) => {
              const Icon = reaction.icon
              const mine = reaction.key === picked
              return (
                <span
                  key={reaction.key}
                  className={`grid h-[21px] w-[21px] place-items-center rounded-full ring-2 transition-shadow ${
                    mine ? 'ring-white' : 'ring-raised'
                  } ${reaction.badge}`}
                >
                  <Icon size={11} variant="Bold" />
                </span>
              )
            })}
          </span>
        ) : (
          <Heart
            size={14}
            variant="Bold"
            className="text-faint transition-colors group-hover:text-mute"
          />
        )}
        <span className="text-[12px] font-semibold text-mute tabular-nums transition-colors group-hover:text-white">
          {ordered.length ? compact(total) : ''}
        </span>
      </button>

      <AnimatePresence>
        {open ? (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.94 }}
            transition={{ type: 'spring', stiffness: 520, damping: 34 }}
            className="absolute bottom-full left-0 z-30 mb-2 flex items-end gap-0.5 rounded-2xl border border-line bg-surface px-2 pt-1.5 pb-1 shadow-lift after:absolute after:top-full after:right-0 after:left-0 after:h-2 after:content-['']"
          >
            {reactions.map((reaction) => {
              const Icon = reaction.icon
              const mine = reaction.key === picked
              return (
                <button
                  key={reaction.key}
                  type="button"
                  aria-pressed={mine}
                  aria-label={reaction.label}
                  onClick={(event) => {
                    event.stopPropagation()
                    pick(reaction.key)
                  }}
                  className="flex w-[46px] flex-col items-center gap-0.5 rounded-lg py-1 transition-colors duration-150"
                >
                  <span
                    className={`grid h-7 w-7 place-items-center rounded-full transition-transform duration-200 hover:-translate-y-0.5 active:scale-95 ${
                      mine ? 'ring-2 ring-white ring-offset-1 ring-offset-surface' : ''
                    } ${reaction.badge}`}
                  >
                    <Icon size={14} variant="Bold" />
                  </span>
                  <span
                    className={`text-[8.5px] font-semibold tracking-[0.06em] uppercase ${
                      mine ? 'text-white' : 'text-faint'
                    }`}
                  >
                    {reaction.label}
                  </span>
                </button>
              )
            })}
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  )
}
