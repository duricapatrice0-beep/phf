import { motion } from 'framer-motion'
import PostCard from './PostCard'
import SortTabs from './SortTabs'
import EmptyState from '../ui/EmptyState'
import { SkeletonPostCard } from '../ui/Skeleton'
import { CategoryTag } from '../ui/Tags'
import { AlignLeft, Filter, Grid1, SearchNormal, Sort } from '../icons'
import { compact } from '../../lib/format'

export default function FeedPage({
  title,
  subtitle,
  posts,
  loading,
  sort,
  onSortChange,
  chips = [],
  activeFilter = 'all',
  onFilterChange,
  emptyTitle = 'Nothing here yet',
  emptyBody = 'No threads match this view. Try another room, switch the sort order, or start the first conversation.',
  emptyAction = null,
}) {
  const showChips = chips.length > 0

  return (
    <div>
      <header className="pt-6 sm:pt-8">
        <div className="flex items-end justify-between gap-4">
          <div className="min-w-0">
            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="display-tight text-[26px] leading-none font-bold text-white sm:text-[34px]"
            >
              {title}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
              className="mt-2 text-[13.5px] text-dim"
            >
              {subtitle}
            </motion.p>
          </div>
          <div className="hidden shrink-0 sm:block">
            <SortTabs value={sort} onChange={onSortChange} />
          </div>
        </div>
      </header>

      <div className="sticky top-16 z-30 -mx-3 mt-5 border-b border-line bg-black/75 px-3 backdrop-blur-xl sm:-mx-4 sm:px-4">
        <div className="flex items-center gap-2 py-2.5">
          <div className="sm:hidden">
            <SortTabs value={sort} onChange={onSortChange} />
          </div>
          {showChips ? (
            <div className="no-scrollbar hidden gap-2 overflow-x-auto sm:flex">
              <CategoryTag
                icon="Grid1"
                label="All"
                active={activeFilter === 'all'}
                onClick={() => onFilterChange('all')}
              />
              {chips.map((chip) => (
                <CategoryTag
                  key={chip.id}
                  icon={chip.icon}
                  label={chip.label}
                  active={activeFilter === chip.id}
                  onClick={() => onFilterChange(chip.id)}
                />
              ))}
            </div>
          ) : null}
          <div className="ml-auto flex shrink-0 items-center gap-1">
            <button
              type="button"
              aria-label="Filter"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-faint transition-colors hover:bg-white/5 hover:text-white"
            >
              <Filter size={15} variant="Bold" />
            </button>
            <button
              type="button"
              aria-label="Change order"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-faint transition-colors hover:bg-white/5 hover:text-white"
            >
              <Sort size={15} variant="Bold" />
            </button>
            <button
              type="button"
              aria-label="Search"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-faint transition-colors hover:bg-white/5 hover:text-white sm:hidden"
            >
              <SearchNormal size={15} variant="Bold" />
            </button>
          </div>
        </div>
      </div>

      <div className="mt-4">
        {loading ? (
          <div>
            {[0, 1, 2, 3].map((row) => (
              <SkeletonPostCard key={row} />
            ))}
          </div>
        ) : posts.length === 0 ? (
          <EmptyState
            icon={AlignLeft}
            title={emptyTitle}
            body={emptyBody}
            action={emptyAction}
          />
        ) : (
          <div>
            {posts.map((post, index) => (
              <PostCard key={post.id} post={post} index={index} />
            ))}
          </div>
        )}

        {!loading && posts.length > 0 ? (
          <div className="flex items-center gap-3 py-8">
            <span className="h-px flex-1 bg-line" />
            <span className="text-[11px] tracking-[0.18em] text-faint uppercase">
              {compact(posts.length)} loaded · end of feed
            </span>
            <span className="h-px flex-1 bg-line" />
          </div>
        ) : null}
      </div>
    </div>
  )
}
