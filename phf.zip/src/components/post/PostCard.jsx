import { useState } from 'react'
import { motion } from 'framer-motion'
import { Link, useRouter } from '../../lib/router'
import { Bookmark2, Edit, Messages2, Share, Trash } from '../icons'
import { getIcon } from '../../lib/iconMap'
import Avatar from '../ui/Avatar'
import PointsBadge from '../ui/PointsBadge'
import OverflowMenu from '../ui/Menu'
import ConfirmDialog from '../ui/ConfirmDialog'
import ReactionBar from './ReactionBar'
import CreatePostModal from '../modal/CreatePostModal'
import { reactionsFor } from '../../lib/reactions'
import { useStore } from '../../lib/store'
import { compact, timeAgo } from '../../lib/format'

function MediaBlock({ kind }) {
  return (
    <div
      className="relative mt-4 h-[190px] overflow-hidden rounded-xl border border-white/[0.07] bg-raised sm:h-[240px]"
    >
      {kind === 'ui' ? (
        <div className="absolute inset-0 p-5">
          <div className="flex h-full gap-3">
            <div className="w-16 space-y-2 rounded-lg border border-white/10 bg-white/[0.03] p-2">
              {[0.7, 0.45, 0.6, 0.35, 0.5].map((w, i) => (
                <div key={i} className="h-1.5 rounded-full bg-white/15" style={{ width: `${w * 100}%` }} />
              ))}
            </div>
            <div className="flex-1 space-y-2.5">
              <div className="h-4 w-1/2 rounded bg-white/15" />
              <div className="h-2 w-full rounded bg-white/[0.07]" />
              <div className="h-2 w-4/5 rounded bg-white/[0.07]" />
              <div className="grid grid-cols-3 gap-2.5 pt-2">
                <div className="h-14 rounded-lg border border-white/10 bg-white/[0.04]" />
                <div className="h-14 rounded-lg border border-white/15 bg-white/[0.07]" />
                <div className="h-14 rounded-lg border border-white/10 bg-white/[0.04]" />
              </div>
              <div className="h-2 w-2/3 rounded bg-white/[0.07]" />
            </div>
          </div>
        </div>
      ) : null}

      {kind === 'chart' ? (
        <div className="absolute inset-0 flex items-end gap-2 px-6 pb-6">
          {[34, 52, 41, 68, 59, 82, 74, 96, 88, 63, 71, 55, 47, 62, 39].map((height, i) => (
            <div
              key={i}
              className="flex-1 rounded-t-sm"
              style={{
                height: `${height}%`,
                background: `linear-gradient(180deg, rgba(255,255,255,${0.15 + (height / 100) * 0.75}), rgba(255,255,255,0.06))`,
              }}
            />
          ))}
          <div className="absolute inset-x-6 bottom-5 h-px bg-white/15" />
        </div>
      ) : null}

      {kind === 'photo' ? (
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(60% 70% at 25% 80%, rgba(255,255,255,0.18), transparent 60%), radial-gradient(45% 55% at 78% 30%, rgba(255,255,255,0.1), transparent 65%), linear-gradient(180deg, #000 0%, #0d0d0d 100%)',
          }}
        >
          <div className="noise-overlay absolute inset-0 opacity-[0.22] mix-blend-overlay" />
          <div className="absolute inset-0 shadow-[inset_0_0_90px_rgba(0,0,0,0.85)]" />
        </div>
      ) : null}

      {kind === 'type' ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
          <span
            className="font-display text-[76px] leading-none font-bold text-white sm:text-[96px]"
            style={{ letterSpacing: '-0.08em' }}
          >
            Aa
          </span>
          <span className="text-[10.5px] tracking-[0.4em] text-faint uppercase">Aleo · Lato · Nanum</span>
        </div>
      ) : null}

      <div className="noise-overlay pointer-events-none absolute inset-0 opacity-[0.05] mix-blend-overlay" />
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: 'linear-gradient(180deg, transparent 55%, rgba(0,0,0,0.55) 100%)' }}
      />
    </div>
  )
}

function FooterAction({ icon: Icon, label, count, active = false, onClick }) {
  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={active}
      onClick={(event) => {
        event.stopPropagation()
        onClick?.(event)
      }}
      className={`inline-flex h-7 items-center gap-1.5 rounded-full border px-2.5 text-[12px] font-medium transition-colors duration-150 ${
        active
          ? 'border-red-900 bg-red-900 text-white'
          : 'border-transparent text-dim hover:border-line hover:bg-raised hover:text-white'
      }`}
    >
      <Icon size={14} variant="Bold" />
      {count != null ? <span className="tabular-nums">{compact(count)}</span> : null}
    </button>
  )
}

export default function PostCard({ post, index = 0 }) {
  const { navigate } = useRouter()
  const { getCategory, userByHandle, react, toggleSave, me, deletePost } = useStore()
  const [copied, setCopied] = useState(false)
  const [menuEdit, setMenuEdit] = useState(false)
  const [menuDelete, setMenuDelete] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState(null)
  const category = getCategory(post.category) || { id: post.category, name: post.category, icon: 'Messages2' }
  const author = userByHandle(post.author) || { handle: post.author, name: post.authorName || 'Member', seed: 0, karma: 0 }
  const Icon = getIcon(category.icon)
  const reactions = reactionsFor(post.reactionCounts, post.mine)
  const saved = post.saved
  const isOwn = Boolean(me?.id && post.authorId === me.id)

  const onReact = (key) => {
    react(post.id, key)
  }

  const onToggleSave = () => {
    toggleSave(post.id, !saved)
  }

  const openThread = (event) => {
    if (event.target.closest('a, button')) return
    navigate(`/post/${post.id}`)
  }

  const share = () => {
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1600)
  }

  const confirmDelete = async () => {
    setBusy(true)
    setError(null)
    const result = await deletePost(post.id)
    setBusy(false)
    if (result.error) setError(result.error)
    else setMenuDelete(false)
  }

  return (
    <motion.article
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: Math.min(index, 6) * 0.04, ease: [0.16, 1, 0.3, 1] }}
      onClick={openThread}
      className="group -mx-3 cursor-pointer border-b border-line px-3 py-6 transition-colors duration-200 hover:bg-white/[0.02] sm:-mx-4 sm:px-4 sm:py-7"
    >
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11.5px] text-faint">
        <span className="inline-flex items-center gap-1.5 text-mute">
          <Icon size={14} variant="Bold" />
          {category.name}
        </span>
        <span>·</span>
        <span>{timeAgo(post.minutes)} ago</span>
        {post.editedAt ? <span className="text-faint">· edited</span> : null}
        {post.pinned ? <span className="text-faint">· pinned</span> : null}
      </div>

      <h3 className="display-tight mt-2.5 text-[18.5px] leading-[1.25] text-white sm:text-[21px]">
        <Link to={`/post/${post.id}`} className="transition-colors duration-150 hover:text-white/70">
          {post.title}
        </Link>
      </h3>

      <p className="mt-2 line-clamp-2 max-w-[75ch] text-[14px] leading-relaxed text-dim">{post.excerpt}</p>

      {post.media ? <MediaBlock kind={post.media} /> : null}

      <div className="mt-4 flex flex-wrap items-center gap-x-2 gap-y-2.5">
        <Link
          to={`/u/${author.handle}`}
          className="flex items-center gap-2 pr-2"
          onClick={(event) => event.stopPropagation()}
        >
          <Avatar user={author} size="xs" />
          <span className="text-[12.5px] text-dim transition-colors duration-150 group-hover:text-white">
            {author.name}
          </span>
          <PointsBadge points={author.karma || 0} size="xs" />
        </Link>

        <div className="ml-auto flex flex-wrap items-center gap-x-2 gap-y-2.5">
          <ReactionBar reactions={reactions} picked={post.mine} onPick={onReact} />

          <span className="inline-flex h-8 items-center gap-1.5 rounded-full border border-line bg-raised px-3 text-[12px] font-semibold text-mute transition-colors duration-150 hover:border-white/30 hover:text-white">
            <Messages2 size={14} variant="Bold" />
            <span className="tabular-nums">{compact(post.comments)}</span>
          </span>

          <FooterAction
            icon={Bookmark2}
            label="Save"
            active={saved}
            onClick={onToggleSave}
          />

          <span className="relative">
            <FooterAction icon={Share} label="Share" active={copied} onClick={share} />
            {copied ? (
              <motion.span
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="absolute -top-8 right-0 rounded-lg border border-line bg-raised px-2.5 py-1 text-[11px] whitespace-nowrap text-white shadow-lift"
              >
                Link copied
              </motion.span>
            ) : null}
          </span>

          {isOwn ? (
            <OverflowMenu
              label="Post options"
              items={[
                { icon: Edit, label: 'Edit post', onClick: () => setMenuEdit(true) },
                { icon: Trash, label: 'Delete post', danger: true, onClick: () => setMenuDelete(true) },
              ]}
            />
          ) : null}
        </div>
      </div>

      {menuEdit ? (
        <CreatePostModal open onClose={() => setMenuEdit(false)} post={post} />
      ) : null}
      <ConfirmDialog
        open={menuDelete}
        onClose={() => {
          setMenuDelete(false)
          setError(null)
        }}
        onConfirm={confirmDelete}
        busy={busy}
        error={error}
        title="Delete this thread?"
        body="The thread, its replies, and its reactions go with it. This cannot be undone."
      />
    </motion.article>
  )
}
