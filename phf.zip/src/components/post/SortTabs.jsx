import Tabs from '../ui/Tabs'
import { Flash, Star, Timer } from '../icons'

const TABS = [
  { id: 'hot', label: 'Hot', icon: Flash },
  { id: 'new', label: 'New', icon: Timer },
  { id: 'top', label: 'Top', icon: Star },
]

export default function SortTabs({ value, onChange }) {
  return (
    <div className="rounded-xl border border-line bg-surface px-1">
      <Tabs tabs={TABS} value={value} onChange={onChange} layoutId="sort-underline" size="sm" />
    </div>
  )
}
