import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { useRouter, Link } from '../../lib/router'
import { Add, Bookmark2, Logout, Notification, SearchNormal, Setting, User } from '../icons'
import Avatar from '../ui/Avatar'
import { Badge } from '../ui/Tags'
import { useStore } from '../../lib/store'
import { useAuth } from '../../lib/auth'

export default function Navbar({ onMenuClick, onCreate }) {
  const { path, navigate } = useRouter()
  const { signOut } = useAuth()
  const { me, unreadCount } = useStore()
  const currentUser = me
  const [menuOpen, setMenuOpen] = useState(false)
  const [query, setQuery] = useState('')
  const menuRef = useRef(null)

  useEffect(() => {
    if (!menuOpen) return undefined
    const onDown = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) setMenuOpen(false)
    }
    const onKey = (event) => event.key === 'Escape' && setMenuOpen(false)
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [menuOpen])

  const submitSearch = (event) => {
    event.preventDefault()
    navigate(query.trim() ? `/search?q=${encodeURIComponent(query.trim())}` : '/search')
  }

  return (
    <motion.header
      initial={{ y: -64, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 260, damping: 30 }}
      className="sticky top-0 z-50 border-b border-line bg-black/70 backdrop-blur-xl"
    >
      <div className="mx-auto flex h-16 max-w-[1520px] items-center gap-3 px-3 sm:px-5">
        <button
          type="button"
          onClick={onMenuClick}
          aria-label="Open communities"
          className="flex h-9 w-9 items-center justify-center rounded-lg text-mute transition-colors hover:bg-white/5 hover:text-white md:hidden"
        >
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
            <path d="M2 4.5h14M2 9h14M2 13.5h9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </button>

        <Link to="/" className="group flex shrink-0 items-center gap-2">
          <span className="font-display text-[22px] leading-none font-bold tracking-[-0.02em] text-white transition-text-shadow duration-300 group-hover:[text-shadow:0_0_22px_rgba(255,255,255,0.55)]">
            .phf
          </span>
          <motion.span
            className="h-1.5 w-1.5 rounded-full bg-white"
            animate={{ opacity: [1, 0.25, 1] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
            style={{ boxShadow: '0 0 10px rgba(255,255,255,0.9)' }}
          />
        </Link>

        <form onSubmit={submitSearch} className="mx-auto hidden w-full max-w-sm flex-1 md:block">
          <div className="group relative">
            <SearchNormal
              size={16}
              variant="Bold"
              className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-faint transition-colors group-focus-within:text-white"
            />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search threads, people, tags"
              aria-label="Search"
              className="h-9 w-full rounded-xl border border-line bg-surface pr-14 pl-9 text-sm text-white placeholder:text-faint transition-all duration-200 outline-none group-focus-within:border-white/25 group-focus-within:shadow-[0_0_0_3px_rgba(255,255,255,0.05)]"
            />
            <kbd className="pointer-events-none absolute top-1/2 right-2.5 -translate-y-1/2 rounded-md border border-line bg-raised px-1.5 py-0.5 text-[10px] font-medium text-faint">
              ⌘K
            </kbd>
            <div className="pointer-events-none absolute -bottom-px left-4 right-4 h-px scale-x-0 bg-white/50 transition-transform duration-300 group-focus-within:scale-x-100" />
          </div>
        </form>

        <div className="ml-auto flex shrink-0 items-center gap-1.5 sm:gap-2 md:ml-0">
          <motion.button
            type="button"
            onClick={onCreate}
            className="hidden h-9 items-center gap-1.5 rounded-xl bg-white px-3.5 text-[13px] font-semibold text-black transition-shadow duration-200  md:inline-flex"
          >
            <Add size={16} variant="Bold" />
            Create Post
          </motion.button>

          <button
            type="button"
            onClick={() => navigate('/notifications')}
            aria-label={`Notifications, ${unreadCount} unread`}
            className="relative flex h-9 w-9 items-center justify-center rounded-xl text-mute transition-colors hover:bg-white/5 hover:text-white"
          >
            <Notification size={19} variant="Bold" />
            <Badge count={unreadCount} />
          </button>

          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setMenuOpen((open) => !open)}
              aria-haspopup="menu"
              aria-expanded={menuOpen}
              className="flex h-9 items-center gap-1 rounded-xl pl-0.5 pr-1 transition-colors hover:bg-white/5"
            >
              <Avatar user={currentUser} size="sm" />
            </button>

            <AnimatePresence>
              {menuOpen ? (
                <motion.div
                  role="menu"
                  initial={{ opacity: 0, y: -8, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -6, scale: 0.97 }}
                  transition={{ type: 'spring', stiffness: 420, damping: 30 }}
                  className="absolute right-0 mt-2 w-60 origin-top-right overflow-hidden rounded-2xl border border-line bg-surface shadow-panel"
                >
                  <div className="flex items-center gap-3 border-b border-line px-4 py-3.5">
                    <Avatar user={currentUser} size="md" />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-white">{currentUser.name}</p>
                      <p className="truncate text-xs text-dim">@{currentUser.handle}</p>
                    </div>
                  </div>
                  <div className="p-1.5">
                    <MenuItem icon={User} label="Profile" onClick={() => navigate(`/u/${currentUser.handle}`)} />
                    <MenuItem icon={Bookmark2} label="Saved" onClick={() => navigate('/saved')} />
                    <MenuItem icon={Setting} label="Settings" onClick={() => navigate('/saved')} />
                  </div>
                  <div className="h-px bg-line" />
                  <div className="p-1.5">
                    <MenuItem icon={Logout} label="Log out" onClick={() => { setMenuOpen(false); signOut() }} />
                  </div>
                </motion.div>
              ) : null}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.header>
  )
}

function MenuItem({ icon: Icon, label, onClick }) {
  return (
    <button
      type="button"
      role="menuitem"
      onClick={onClick}
      className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-sm text-mute transition-colors hover:bg-white/[0.06] hover:text-white"
    >
      <Icon size={16} variant="Bold" />
      {label}
    </button>
  )
}
