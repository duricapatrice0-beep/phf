import { AnimatePresence, motion } from 'framer-motion'
import { useRouter, Link } from '../../lib/router'
import {
  Add,
  AlignLeft,
  ArrowRight,
  CloseCircle,
  Hashtag,
  Home2,
  Messages2 as Chat,
  Ranking,
  Video,
} from '../icons'
import { getIcon } from '../../lib/iconMap'
import { useStore } from '../../lib/store'
import { compact } from '../../lib/format'

function Row({ icon: Icon, label, meta, active, collapsed, onClick, layoutId, iconOnly, trailing }) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      className={`group relative flex w-full items-center gap-2.5 rounded-lg border px-2 py-[7px] text-left transition-colors duration-200 ${
        collapsed ? 'justify-center' : ''
      } ${
        active
          ? 'border-red-900/70 bg-red-900/25'
          : 'border-transparent hover:border-white/[0.06] hover:bg-white/[0.035]'
      }`}
    >
      {active ? (
        <motion.span
          layoutId={layoutId}
          className="absolute top-2 bottom-2 -left-[3px] w-[2px] rounded-full bg-red-900"
          transition={{ type: 'spring', stiffness: 500, damping: 40 }}
        />
      ) : null}
      <span
        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border transition-colors duration-200 ${
          active
            ? 'border-red-900 bg-red-900 text-white'
            : 'border-line bg-raised text-mute group-hover:border-white/25 group-hover:bg-overlay group-hover:text-white'
        }`}
      >
        <Icon size={17} variant="Bold" />
      </span>
      {!collapsed && !iconOnly ? (
        <span className="min-w-0 flex-1">
          <span
            className={`block truncate text-[13.5px] leading-tight font-medium transition-transform duration-200 group-hover:translate-x-[1px] ${
              active ? 'text-white' : 'text-mute group-hover:text-white'
            }`}
          >
            {label}
          </span>
          {meta ? (
            <span className="mt-0.5 block truncate text-[11px] tabular-nums text-faint">{meta}</span>
          ) : null}
        </span>
      ) : null}
      {!collapsed && !iconOnly && trailing ? (
        <span className="shrink-0 text-faint transition-colors group-hover:text-white">{trailing}</span>
      ) : null}
      {!collapsed && active && !iconOnly && !trailing ? (
        <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-white" />
      ) : null}
    </button>
  )
}

function SectionLabel({ children, collapsed, divider = false }) {
  if (collapsed) return <div className="mx-3 my-3 h-px bg-line" />
  return (
    <div className={`flex items-center gap-3 px-2.5 pt-5 pb-2 ${divider ? 'mt-3 border-t border-line pt-5' : ''}`}>
      <span className="text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">{children}</span>
      <span className="h-px flex-1 bg-line" />
    </div>
  )
}

function SidebarBody({ path, collapsed, onToggleCollapse, onPick }) {
  const { navigate } = useRouter()
  const { categories, communities, trendingTags } = useStore()
  const go = (to) => {
    navigate(to)
    onPick?.()
  }

  return (
    <div className="flex h-full flex-col">
      <div className={`flex items-center justify-between gap-2 px-3 pt-4 pb-1 ${collapsed ? 'justify-center' : ''}`}>
        {!collapsed ? (
          <span className="text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">Browse</span>
        ) : null}
        <button
          type="button"
          onClick={onToggleCollapse}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className="hidden h-7 w-7 items-center justify-center rounded-lg text-faint transition-colors hover:bg-white/5 hover:text-white md:flex"
        >
          <motion.span animate={{ rotate: collapsed ? 180 : 0 }} transition={{ type: 'spring', stiffness: 400, damping: 28 }}>
            <ArrowRight size={15} variant="Bold" />
          </motion.span>
        </button>
      </div>

      <div className="no-scrollbar flex-1 overflow-y-auto px-2 pt-1 pb-5">
        <div className="space-y-0.5">
          <Row
            icon={Home2}
            label="Home Feed"
            meta="Your ranked front page"
            active={path === '/'}
            collapsed={collapsed}
            layoutId="side-active"
            onClick={() => go('/')}
          />
          <Row
            icon={AlignLeft}
            label="Forum"
            meta={`${categories.length} rooms`}
            active={path === '/forum'}
            collapsed={collapsed}
            layoutId="side-active"
            onClick={() => go('/forum')}
          />
          <Row
            icon={Ranking}
            label="Rank Ladder"
            meta="Points standings"
            active={path === '/rank'}
            collapsed={collapsed}
            layoutId="side-active"
            onClick={() => go('/rank')}
          />
          <Row
            icon={Video}
            label="Videos"
            meta="Clips and talks"
            active={path === '/videos'}
            collapsed={collapsed}
            layoutId="side-active"
            onClick={() => go('/videos')}
          />
          <Row
            icon={Chat}
            label="Chat"
            meta="Live rooms"
            active={path === '/chat'}
            collapsed={collapsed}
            layoutId="side-active"
            onClick={() => go('/chat')}
          />
        </div>

        <SectionLabel collapsed={collapsed} divider>
          Communities
        </SectionLabel>
        <div className="space-y-0.5">
          {communities.slice(0, 5).map((community) => (
            <Row
              key={community.id}
              icon={getIcon(community.icon)}
              label={community.name}
              meta={`${compact(community.members)} members`}
              active={false}
              collapsed={collapsed}
              layoutId="side-active"
              onClick={() => go('/explore')}
            />
          ))}
          {!collapsed && communities.length > 5 ? (
            <button
              type="button"
              onClick={() => go('/explore')}
              className="group flex w-full items-center gap-2.5 rounded-lg border border-transparent px-2 py-[7px] text-left transition-colors duration-200 hover:border-white/[0.06] hover:bg-white/[0.035]"
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-dashed border-line text-faint transition-colors group-hover:border-white/30 group-hover:text-white">
                <ArrowRight size={15} variant="Bold" />
              </span>
              <span className="flex-1 text-[13px] font-medium text-dim transition-colors group-hover:text-white">
                View more
              </span>
              <span className="text-[11px] tabular-nums text-faint">
                {Math.max(0, communities.length - 5)} left
              </span>
            </button>
          ) : null}
        </div>

        <SectionLabel collapsed={collapsed} divider>
          Trending tags
        </SectionLabel>
        {!collapsed ? (
          <div className="flex flex-wrap gap-1.5 px-1.5">
            {trendingTags.slice(0, 5).map((item) => (
              <button
                key={item.tag}
                type="button"
                onClick={() => go(`/search?q=${item.tag}`)}
                className="inline-flex items-center gap-1 rounded-full border border-line bg-raised px-2.5 py-1 text-[11px] text-dim transition-colors hover:border-white/30 hover:bg-overlay hover:text-white"
              >
                <Hashtag size={10} variant="Bold" />
                {item.tag}
              </button>
            ))}
          </div>
        ) : null}

        {!collapsed ? (
          <div className="mt-5 rounded-xl border border-line bg-surface p-3 transition-colors hover:border-white/[0.1]">
            <p className="text-[13px] leading-snug font-medium text-white">Start a community</p>
            <p className="mt-1 text-[11.5px] leading-relaxed text-dim">
              Pick a topic, set three rules, and let the thread do the rest.
            </p>
            <button
              type="button"
              className="mt-3 inline-flex h-8 w-full items-center justify-center gap-1.5 rounded-lg border border-white/15 text-[12.5px] font-medium text-white transition-colors hover:border-white/40 hover:bg-white/[0.06]"
            >
              <Add size={14} variant="Bold" />
              New community
            </button>
          </div>
        ) : null}
      </div>
    </div>
  )
}

export function Sidebar({ path, collapsed, onToggleCollapse }) {
  return (
    <motion.aside
      initial={{ x: -40, opacity: 0 }}
      animate={{ x: 0, opacity: 1, width: collapsed ? 72 : 264 }}
      transition={{ type: 'spring', stiffness: 240, damping: 30 }}
      className="sticky top-16 hidden h-[calc(100dvh-4rem)] shrink-0 flex-col border-r border-line bg-void md:flex"
    >
      <SidebarBody
        path={path}
        collapsed={collapsed}
        onToggleCollapse={onToggleCollapse}
      />
    </motion.aside>
  )
}

export function SidebarDrawer({ open, onClose, path }) {
  return (
    <AnimatePresence>
      {open ? (
        <div className="fixed inset-0 z-[90] md:hidden">
          <motion.div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.aside
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ type: 'spring', stiffness: 320, damping: 34 }}
            className="absolute inset-y-0 left-0 flex w-[300px] flex-col border-r border-line bg-void shadow-panel"
          >
            <div className="flex h-16 shrink-0 items-center justify-between border-b border-line px-4">
              <Link to="/" onClick={onClose} className="font-display text-xl font-bold tracking-[-0.02em] text-white">
                .phf
              </Link>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close menu"
                className="flex h-8 w-8 items-center justify-center rounded-lg text-dim transition-colors hover:bg-white/5 hover:text-white"
              >
                <CloseCircle size={19} variant="Bold" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-hidden">
              <SidebarBody
                path={path}
                collapsed={false}
                onToggleCollapse={() => {}}
                onPick={onClose}
              />
            </div>
          </motion.aside>
        </div>
      ) : null}
    </AnimatePresence>
  )
}
