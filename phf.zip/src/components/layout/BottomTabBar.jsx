import { AnimatePresence, motion } from 'framer-motion'
import { useRouter } from '../../lib/router'
import { Add, Home2, Notification, SearchNormal, User } from '../icons'
import { Badge } from '../ui/Tags'
import { useStore } from '../../lib/store'

export default function BottomTabBar({ onCreate, path }) {
  const { navigate } = useRouter()
  const { me, unreadCount } = useStore()
  const tabs = [
    { id: 'home', label: 'Home', icon: Home2, to: '/' },
    { id: 'search', label: 'Search', icon: SearchNormal, to: '/search' },
    { id: 'create', label: 'Create', icon: Add, action: onCreate },
    { id: 'alerts', label: 'Alerts', icon: Notification, to: '/notifications', badge: unreadCount },
    { id: 'profile', label: 'Profile', icon: User, to: me ? `/u/${me.handle}` : '/' },
  ]

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t border-line bg-black/85 backdrop-blur-xl md:hidden"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="mx-auto flex h-16 max-w-md items-stretch justify-between px-2">
        {tabs.map((tab) => {
          const active = tab.to ? path === tab.to || (tab.to === '/search' && path.startsWith('/search')) : false

          if (tab.action) {
            return (
              <button
                key={tab.id}
                type="button"
                onClick={tab.action}
                aria-label="Create post"
                className="flex flex-1 items-center justify-center"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-black">
                  <Add size={20} variant="Bold" />
                </span>
              </button>
            )
          }

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => navigate(tab.to)}
              aria-label={tab.label}
              aria-current={active ? 'page' : undefined}
              className="relative flex flex-1 flex-col items-center justify-center gap-1"
            >
              <span className={`relative ${active ? 'text-white' : 'text-faint'}`}>
                <tab.icon size={20} variant="Bold" />
                {tab.badge ? <Badge count={tab.badge} className="-top-1.5 -right-2" /> : null}
              </span>
              <span className={`text-[10px] font-medium ${active ? 'text-white' : 'text-faint'}`}>{tab.label}</span>
              <AnimatePresence>
                {active ? (
                  <motion.span
                    layoutId="tab-indicator"
                    className="absolute top-0 h-[2px] w-7 rounded-full bg-red-900"
                    transition={{ type: 'spring', stiffness: 480, damping: 38 }}
                  />
                ) : null}
              </AnimatePresence>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
