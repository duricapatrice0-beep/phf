import { useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from '../../lib/router'
import { ArrowRight, Crown, Verify } from '../icons'
import Avatar from '../ui/Avatar'
import PointsBadge from '../ui/PointsBadge'
import { Skeleton } from '../ui/Skeleton'
import { useStore } from '../../lib/store'
import { compact } from '../../lib/format'

function SectionLabel({ children, action, divider = false }) {
  return (
    <div
      className={`flex items-center gap-3 px-2.5 pt-5 pb-2 ${divider ? 'mt-3 border-t border-line' : ''}`}
    >
      <span className="text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">
        {children}
      </span>
      <span className="h-px flex-1 bg-line" />
      {action}
    </div>
  )
}

function SectionAction({ to, label }) {
  return (
    <Link
      to={to}
      className="group inline-flex shrink-0 items-center gap-1 text-[11px] font-medium text-faint transition-colors hover:text-white"
    >
      {label}
      <ArrowRight size={11} variant="Bold" className="transition-transform group-hover:translate-x-0.5" />
    </Link>
  )
}

const RANK = (index) =>
  `w-4 shrink-0 text-center text-[12px] font-semibold tabular-nums transition-colors ${
    index === 0 ? 'text-yellow-300' : 'text-faint group-hover:text-white'
  }`

function RailLoading() {
  return (
    <>
      <SectionLabel>About</SectionLabel>
      <div className="space-y-2.5 px-2.5">
        <Skeleton className="h-5 w-24" rounded="rounded-md" />
        <Skeleton className="h-3.5 w-full" />
        <Skeleton className="h-3.5 w-[85%]" />
        <div className="grid grid-cols-3 divide-x divide-line border-y border-line py-2.5">
          {[0, 1, 2].map((cell) => (
            <div key={cell} className="flex justify-center">
              <Skeleton className="h-4 w-10" rounded="rounded-md" />
            </div>
          ))}
        </div>
        <Skeleton className="h-9 w-full" rounded="rounded-xl" />
      </div>

      <SectionLabel divider>Top contributors</SectionLabel>
      <ul className="space-y-0.5 px-2">
        {[0, 1, 2].map((row) => (
          <li key={row} className="flex items-center gap-2.5 rounded-lg px-2 py-[7px]">
            <Skeleton className="h-4 w-4" rounded="rounded-md" />
            <Skeleton className="h-8 w-8" rounded="rounded-full" />
            <div className="min-w-0 flex-1 space-y-1.5">
              <Skeleton className="h-3.5 w-28" rounded="rounded-md" />
              <Skeleton className="h-2.5 w-16" rounded="rounded-full" />
            </div>
            <Skeleton className="h-3.5 w-8" rounded="rounded-md" />
          </li>
        ))}
      </ul>

      <SectionLabel divider>Trending today</SectionLabel>
      <ul className="space-y-0.5 px-2">
        {[0, 1].map((row) => (
          <li key={row} className="flex items-center gap-2.5 rounded-lg px-2 py-[7px]">
            <Skeleton className="h-4 w-4" rounded="rounded-md" />
            <div className="min-w-0 flex-1 space-y-1.5">
              <Skeleton className="h-3.5 w-[85%]" rounded="rounded-md" />
              <Skeleton className="h-2.5 w-24" rounded="rounded-full" />
            </div>
          </li>
        ))}
      </ul>
    </>
  )
}

export default function RightRail({ activeCategory }) {
  const [following, setFollowing] = useState(false)
  const {
    status,
    getCategory,
    categoryThreads,
    categories,
    posts,
    topContributors,
    trendingToday,
    isJoined,
    toggleRoom,
  } = useStore()

  const loading = status === 'loading'
  const category = activeCategory ? getCategory(activeCategory) : null
  const joined = category ? isJoined(category.id) : following
  const totalMembers = categories.reduce((sum, item) => sum + item.members, 0)
  const totalOnline = categories.reduce((sum, item) => sum + item.online, 0)

  const onJoin = () => {
    if (category) toggleRoom(category.id)
    else setFollowing((value) => !value)
  }

  return (
    <motion.aside
      initial={{ x: 24, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 240, damping: 30, delay: 0.1 }}
      className="hidden w-[300px] shrink-0 xl:block"
    >
      <div className="sticky top-20 pb-10">
        {loading ? (
          <RailLoading />
        ) : (
          <>
            <SectionLabel>{category ? 'Forum room' : 'About'}</SectionLabel>
            <div className="px-2.5">
              <h3 className="display-tight text-[17px] leading-none text-white">
                {category ? category.name : '.phf'}
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-dim">
                {category
                  ? category.description
                  : 'A quiet forum for people who like their interfaces monochrome and their arguments with citations.'}
              </p>
              <div className="mt-3.5 grid grid-cols-3 divide-x divide-line border-y border-line py-2.5 text-center">
                <div>
                  <p className="text-sm font-semibold text-white tabular-nums">
                    {compact(category ? category.members : totalMembers)}
                  </p>
                  <p className="mt-0.5 text-[10px] tracking-wide text-faint uppercase">Members</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-white tabular-nums">
                    {compact(category ? category.online : totalOnline)}
                  </p>
                  <p className="mt-0.5 text-[10px] tracking-wide text-faint uppercase">Online</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-white tabular-nums">
                    {compact(category ? categoryThreads(category.id) : posts.length)}
                  </p>
                  <p className="mt-0.5 text-[10px] tracking-wide text-faint uppercase">Threads</p>
                </div>
              </div>
              <button
                type="button"
                onClick={onJoin}
                className={`mt-3.5 h-9 w-full rounded-xl text-[13px] font-semibold transition-colors ${
                  joined
                    ? 'border border-red-900 bg-red-900 text-white hover:bg-red-900/80'
                    : 'bg-blue-700 text-white hover:bg-blue-600'
                }`}
              >
                {joined ? 'Joined' : category ? 'Join room' : 'Follow feed'}
              </button>
            </div>

            <SectionLabel
              divider
              action={<SectionAction to="/explore" label="See all" />}
            >
              Top contributors
            </SectionLabel>
            <ul className="space-y-0.5 px-2">
              {topContributors.map((entry, index) => (
                <li key={entry.user.id}>
                  <Link
                    to={`/u/${entry.user.handle}`}
                    className="group flex items-center gap-2.5 rounded-lg px-2 py-[7px] transition-colors duration-200 hover:bg-white/[0.035]"
                  >
                    <span className={RANK(index)}>{index + 1}</span>
                    <Avatar user={entry.user} size="sm" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13.5px] leading-tight font-medium text-mute transition-colors group-hover:text-white">
                        {entry.user.name}
                      </span>
                      <span className="mt-1 block">
                        <PointsBadge points={entry.user.karma} size="xs" />
                      </span>
                    </span>
                    <span className="shrink-0 text-[11px] font-medium text-faint tabular-nums transition-colors group-hover:text-mute">
                      {compact(entry.score)}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>

            <SectionLabel
              divider
              action={<SectionAction to="/forum" label="Open forum" />}
            >
              Trending today
            </SectionLabel>
            <ul className="space-y-0.5 px-2">
              {trendingToday.map((entry, index) => (
                <li key={entry.post.id}>
                  <Link
                    to={`/post/${entry.post.id}`}
                    className="group flex items-center gap-2.5 rounded-lg px-2 py-[7px] transition-colors duration-200 hover:bg-white/[0.035]"
                  >
                    <span className={RANK(index)}>{index + 1}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13.5px] leading-tight font-medium text-mute transition-colors group-hover:text-white">
                        {entry.post.title}
                      </span>
                      <span className="mt-0.5 flex items-center gap-1.5 text-[11px] text-faint">
                        <span className="truncate">
                          {getCategory(entry.post.category)?.name || ''}
                        </span>
                        <span className="inline-flex shrink-0 items-center gap-1 font-semibold text-yellow-300">
                          <Crown size={10} variant="Bold" />
                          {entry.delta}
                        </span>
                      </span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </>
        )}

        <div className="mt-4 flex flex-wrap items-center gap-x-2.5 gap-y-1.5 px-2.5 text-[11px] text-faint">
          <span className="inline-flex items-center gap-1 transition-colors hover:text-yellow-300">
            <Verify size={11} variant="Bold" className="text-yellow-300" /> Verified guidelines
          </span>
          <span>·</span>
          <span className="transition-colors hover:text-white">Privacy</span>
          <span>·</span>
          <span className="transition-colors hover:text-white">Terms</span>
          <span>·</span>
          <span>© 2026 .phf</span>
        </div>
      </div>
    </motion.aside>
  )
}
