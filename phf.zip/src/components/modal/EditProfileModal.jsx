import { useEffect, useState } from 'react'
import Modal, { ModalHeader } from '../ui/Modal'
import Avatar from '../ui/Avatar'
import { Refresh, TickCircle } from '../icons'
import { useStore } from '../../lib/store'
import { dicebearUrl, randomAvatarSeed } from '../../lib/avatar'

export default function EditProfileModal({ open, onClose, user }) {
  const { updateProfile } = useStore()
  const [name, setName] = useState('')
  const [bio, setBio] = useState('')
  const [location, setLocation] = useState('')
  const [avatar, setAvatar] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!open || !user) return
    setName(user.name || '')
    setBio(user.bio || '')
    setLocation(user.location || '')
    setAvatar(user.avatarUrl || dicebearUrl(user.handle || user.name))
    setError(null)
  }, [open, user])

  const canSave = name.trim().length >= 2 && !busy

  const save = async () => {
    if (!canSave) return
    setBusy(true)
    setError(null)
    const result = await updateProfile({
      name: name.trim(),
      bio: bio.trim(),
      location: location.trim(),
      avatar_url: avatar,
    })
    setBusy(false)
    if (result.error) setError(result.error)
    else onClose()
  }

  return (
    <Modal open={open} onClose={onClose} width="max-w-lg" labelId="edit-profile-title">
      <ModalHeader
        title="Edit profile"
        subtitle="Name, bio, location — and a fresh face from the avatar press."
        titleId="edit-profile-title"
        onClose={onClose}
      />

      <div className="space-y-5 px-5 py-5 sm:px-6">
        <div className="flex items-center gap-4">
          <Avatar user={{ ...user, avatarUrl: avatar }} size="xl" />
          <div className="min-w-0">
            <button
              type="button"
              onClick={() => setAvatar(dicebearUrl(randomAvatarSeed()))}
              className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-white/15 px-3 text-[12.5px] font-medium text-white transition-colors hover:border-white/40 hover:bg-white/[0.06]"
            >
              <Refresh size={14} variant="Bold" />
              Shuffle avatar
            </button>
            <p className="mt-2 text-[11.5px] text-faint">
              DiceBear Notionists · redrawn every click
            </p>
          </div>
        </div>

        <label className="block">
          <span className="label-caps block pb-2 text-[10px] text-faint">Display name</span>
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            maxLength={40}
            placeholder="How the rooms read you"
            className="h-11 w-full rounded-xl border border-line bg-raised px-4 text-[15px] text-white placeholder:text-faint transition-all outline-none focus:border-white/25 focus:shadow-[0_0_0_3px_rgba(255,255,255,0.05)]"
          />
        </label>

        <label className="block">
          <span className="label-caps flex items-center justify-between pb-2 text-[10px] text-faint">
            Bio
            <span className="text-faint tabular-nums">{bio.length}/200</span>
          </span>
          <textarea
            value={bio}
            onChange={(event) => setBio(event.target.value.slice(0, 200))}
            rows={3}
            placeholder="One honest paragraph beats three vague ones."
            className="w-full resize-none rounded-xl border border-line bg-raised px-4 py-3 text-[14.5px] leading-relaxed text-white placeholder:text-faint transition-all outline-none focus:border-white/25 focus:shadow-[0_0_0_3px_rgba(255,255,255,0.05)]"
          />
        </label>

        <label className="block">
          <span className="label-caps block pb-2 text-[10px] text-faint">Location</span>
          <input
            value={location}
            onChange={(event) => setLocation(event.target.value)}
            maxLength={60}
            placeholder="City, country"
            className="h-11 w-full rounded-xl border border-line bg-raised px-4 text-[15px] text-white placeholder:text-faint transition-all outline-none focus:border-white/25 focus:shadow-[0_0_0_3px_rgba(255,255,255,0.05)]"
          />
        </label>
      </div>

      {error ? (
        <p className="border-t border-red-900 bg-red-900/20 px-5 py-2.5 text-[12.5px] text-white sm:px-6">
          {error}
        </p>
      ) : null}

      <div className="flex items-center justify-end gap-2 border-t border-line bg-surface px-5 py-4 sm:px-6">
        <button
          type="button"
          onClick={onClose}
          className="h-10 rounded-xl border border-line px-4 text-sm font-medium text-mute transition-colors hover:border-white/20 hover:text-white"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={save}
          disabled={!canSave}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-white px-5 text-sm font-semibold text-black transition-opacity disabled:opacity-30"
        >
          <TickCircle size={16} variant="Bold" />
          {busy ? 'Saving…' : 'Save changes'}
        </button>
      </div>
    </Modal>
  )
}
