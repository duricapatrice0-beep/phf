import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Modal, { ModalHeader } from '../ui/Modal'
import { Add, ArrowDown2, Hashtag, CloseCircle, Document, Category as CategoryIcon, TickCircle } from '../icons'
import { getIcon } from '../../lib/iconMap'
import { useStore } from '../../lib/store'
import { useAuth } from '../../lib/auth'

const TITLE_ID = 'create-post-title'

function FieldLabel({ children, hint }) {
  return (
    <div className="mb-2 flex items-baseline justify-between">
      <span className="text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">{children}</span>
      {hint ? <span className="text-[11px] text-faint">{hint}</span> : null}
    </div>
  )
}

export default function CreatePostModal({ open, onClose, post = null }) {
  const { user } = useAuth()
  const { categories, createPost, updatePost } = useStore()
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [categoryId, setCategoryId] = useState(categories[0]?.id || '')
  const [tags, setTags] = useState([])
  const [tagDraft, setTagDraft] = useState('')
  const [pickerOpen, setPickerOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState(null)
  const pickerRef = useRef(null)

  useEffect(() => {
    if (!open || !post) return
    setTitle(post.title)
    setBody(post.body.join('\n\n'))
    setTags(post.tags)
    setCategoryId(post.category)
    setTagDraft('')
    setPickerOpen(false)
    setError(null)
  }, [open, post])

  useEffect(() => {
    if (!pickerOpen) return undefined
    const onDown = (event) => {
      if (pickerRef.current && !pickerRef.current.contains(event.target)) setPickerOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [pickerOpen])

  const room = categories.find((item) => item.id === categoryId) || categories[0]
  const RoomIcon = getIcon(room?.icon)
  const canPublish = title.trim().length > 3 && body.trim().length > 10

  const addTag = () => {
    const clean = tagDraft.trim().replace(/^#/, '').toLowerCase()
    if (clean && !tags.includes(clean) && tags.length < 4) setTags([...tags, clean])
    setTagDraft('')
  }

  const reset = () => {
    setTitle('')
    setBody('')
    setTags([])
    setTagDraft('')
    setCategoryId(categories[0]?.id || '')
    setPickerOpen(false)
    setError(null)
  }

  const publish = async () => {
    if (!canPublish || busy || !room) return
    setBusy(true)
    setError(null)
    const payload = {
      title: title.trim(),
      excerpt: body.trim().slice(0, 240),
      body: body.trim(),
      category: room.id,
      tags,
    }
    const { error: failure } = post
      ? await updatePost(post.id, payload)
      : await createPost({ ...payload, authorId: user?.id })
    setBusy(false)
    if (failure) {
      setError(failure)
      return
    }
    reset()
    onClose()
  }

  if (!room) return null

  return (
    <Modal open={open} onClose={onClose} width="max-w-2xl" labelId={TITLE_ID}>
      <ModalHeader
        titleId={TITLE_ID}
        title={post ? 'Edit post' : 'Create a post'}
        subtitle={post ? 'Tweak the words — the thread keeps its place.' : 'Start something worth replying to.'}
        onClose={onClose}
      />

      <div className="no-scrollbar max-h-[62vh] space-y-5 overflow-y-auto px-5 py-5 sm:px-6">
        <div ref={pickerRef} className="relative">
          <FieldLabel>Room</FieldLabel>
          <button
            type="button"
            onClick={() => setPickerOpen((value) => !value)}
            className="flex h-11 w-full items-center gap-3 rounded-xl border border-line bg-raised px-3 text-left transition-colors hover:border-white/20"
          >
            <span className="flex h-7 w-7 items-center justify-center rounded-lg border border-line bg-surface text-mute">
              <RoomIcon size={15} variant="Bold" />
            </span>
            <span className="flex-1 text-sm font-medium text-white">{room.name}</span>
            <motion.span animate={{ rotate: pickerOpen ? 180 : 0 }} transition={{ type: 'spring', stiffness: 400, damping: 26 }}>
              <ArrowDown2 size={16} variant="Bold" className="text-faint" />
            </motion.span>
          </button>

          <AnimatePresence>
            {pickerOpen ? (
              <motion.div
                initial={{ opacity: 0, y: -6, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.98 }}
                transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                className="absolute z-20 mt-2 max-h-64 w-full overflow-y-auto rounded-xl border border-line bg-surface p-1.5 shadow-panel"
              >
                {categories.map((item) => {
                  const Icon = getIcon(item.icon)
                  const active = item.id === room.id
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setCategoryId(item.id)
                        setPickerOpen(false)
                      }}
                      className={`flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors ${
                        active ? 'bg-red-900/25' : 'hover:bg-white/[0.04]'
                      }`}
                    >
                      <span
                        className={`flex h-7 w-7 items-center justify-center rounded-lg border ${
                          active ? 'border-red-900 bg-red-900 text-white' : 'border-line bg-raised text-mute'
                        }`}
                      >
                        <Icon size={14} variant="Bold" />
                      </span>
                      <span className="flex-1 text-[13.5px] text-white">{item.name}</span>
                      {active ? <TickCircle size={15} variant="Bold" className="text-white" /> : null}
                    </button>
                  )
                })}
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>

        <div>
          <FieldLabel hint={`${title.length}/120`}>Title</FieldLabel>
          <input
            value={title}
            maxLength={120}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Say the thing plainly"
            className="h-12 w-full rounded-xl border border-line bg-raised px-4 text-[16px] font-medium text-white placeholder:text-faint transition-all outline-none focus:border-white/25 focus:shadow-[0_0_0_3px_rgba(255,255,255,0.05)]"
          />
        </div>

        <div>
          <FieldLabel hint="Markdown">Body</FieldLabel>
          <div className="rounded-xl border border-line bg-raised transition-all focus-within:border-white/25 focus-within:shadow-[0_0_0_3px_rgba(255,255,255,0.05)]">
            <div className="flex items-center gap-1 border-b border-line px-2.5 py-1.5">
              <span className="flex h-7 w-7 items-center justify-center rounded-md text-faint">
                <Document size={14} variant="Bold" />
              </span>
              <span className="rounded-md px-2 py-1 text-[12px] font-medium text-mute">B</span>
              <span className="rounded-md px-2 py-1 text-[12px] italic text-mute">i</span>
              <span className="rounded-md px-2 py-1 text-[12px] text-mute">H2</span>
              <span className="rounded-md px-2 py-1 text-[12px] text-mute">{'</>'}</span>
              <span className="ml-auto text-[11px] text-faint">Preview</span>
            </div>
            <textarea
              value={body}
              rows={9}
              onChange={(event) => setBody(event.target.value)}
              placeholder={'## Context\n\nWhat happened, and why does it matter?\n\n## The part that surprised us\n\n- a detail with a number in it\n- a tradeoff you actually made'}
              className="w-full resize-none bg-transparent px-4 py-3.5 text-[14.5px] leading-relaxed text-white placeholder:text-faint focus:outline-none"
            />
          </div>
        </div>

        <div>
          <FieldLabel hint={`${tags.length}/4`}>Tags</FieldLabel>
          <div className="flex flex-wrap items-center gap-2 rounded-xl border border-line bg-raised px-3 py-2.5 transition-all focus-within:border-white/25">
            <AnimatePresence initial={false}>
              {tags.map((tag) => (
                <motion.span
                  key={tag}
                  layout
                  initial={{ opacity: 0, scale: 0.85 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.85 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  className="inline-flex items-center gap-1 rounded-full border border-white/20 bg-white/[0.07] py-1 pr-1.5 pl-2.5 text-[12px] text-white"
                >
                  <Hashtag size={11} variant="Bold" />
                  {tag}
                  <button
                    type="button"
                    onClick={() => setTags(tags.filter((item) => item !== tag))}
                    aria-label={`Remove ${tag}`}
                    className="flex h-4 w-4 items-center justify-center rounded-full text-faint transition-colors hover:text-white"
                  >
                    <CloseCircle size={12} variant="Bold" />
                  </button>
                </motion.span>
              ))}
            </AnimatePresence>
            <input
              value={tagDraft}
              onChange={(event) => setTagDraft(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter' || event.key === ',') {
                  event.preventDefault()
                  addTag()
                }
                if (event.key === 'Backspace' && !tagDraft && tags.length) {
                  setTags(tags.slice(0, -1))
                }
              }}
              onBlur={addTag}
              placeholder={tags.length >= 4 ? 'Max tags reached' : 'Add a tag, press enter'}
              disabled={tags.length >= 4}
              className="min-w-32 flex-1 bg-transparent py-1 text-[13px] text-white placeholder:text-faint focus:outline-none disabled:cursor-not-allowed"
            />
          </div>
        </div>
      </div>

      {error ? (
        <p className="border-t border-red-900 bg-red-900/20 px-5 py-2.5 text-[12.5px] text-white sm:px-6">
          {error}
        </p>
      ) : null}

      <div className="flex items-center gap-3 border-t border-line bg-surface px-5 py-4 sm:px-6">
        <span className="hidden items-center gap-1.5 text-[11.5px] text-faint sm:inline-flex">
          <CategoryIcon size={13} variant="Bold" />
          {post ? `Editing in ${room.name}` : `Posting to ${room.name}`}
        </span>
        <div className="ml-auto flex w-full items-center gap-2 sm:w-auto">
          <button
            type="button"
            onClick={onClose}
            className="h-10 flex-1 rounded-xl border border-line px-4 text-sm font-medium text-mute transition-colors hover:border-white/20 hover:text-white sm:flex-none"
          >
            Cancel
          </button>
          <motion.button
            type="button"
            onClick={publish}
            disabled={!canPublish || busy}
            className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl bg-white px-5 text-sm font-semibold text-black transition-opacity disabled:opacity-30 sm:flex-none"
          >
            <Add size={16} variant="Bold" />
            {post ? (busy ? 'Saving…' : 'Save changes') : busy ? 'Publishing…' : 'Publish'}
          </motion.button>
        </div>
      </div>
    </Modal>
  )
}
