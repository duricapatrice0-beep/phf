import { useEffect, useState } from 'react'
import { initials } from '../../lib/format'
import { dicebearUrl } from '../../lib/avatar'

const RAMPS = [
  'radial-gradient(120% 120% at 20% 0%, #ffffff 0%, #d4d4d4 45%, #8f8f8f 100%)',
  'radial-gradient(120% 120% at 80% 10%, #fafafa 0%, #bcbcbc 50%, #737373 100%)',
  'radial-gradient(130% 130% at 50% 100%, #ffffff 0%, #c9c9c9 40%, #6b6b6b 100%)',
  'linear-gradient(150deg, #e5e5e5 0%, #9ca3af 40%, #3f3f46 100%)',
  'linear-gradient(140deg, #ffffff 0%, #a3a3a3 55%, #525252 100%)',
  'radial-gradient(100% 100% at 100% 0%, #f5f5f5 0%, #a8a8a8 50%, #404040 100%)',
  'linear-gradient(160deg, #d4d4d4 0%, #737373 50%, #171717 100%)',
  'radial-gradient(140% 140% at 30% 20%, #ffffff 0%, #a1a1a1 55%, #262626 100%)',
  'linear-gradient(135deg, #ededed 0%, #8b8b8b 45%, #333333 100%)',
]

const SIZES = {
  xs: { box: 20, font: 9 },
  sm: { box: 26, font: 11 },
  md: { box: 34, font: 13 },
  lg: { box: 44, font: 16 },
  xl: { box: 64, font: 22 },
  '2xl': { box: 96, font: 34 },
}

export default function Avatar({ user, size = 'md', ring = false, className = '' }) {
  const meta = SIZES[size] || SIZES.md
  const [broken, setBroken] = useState(false)
  const seed = user?.seed ?? 0
  const src = user?.avatarUrl || dicebearUrl(user?.handle || user?.name || 'phf')

  useEffect(() => {
    setBroken(false)
  }, [src])

  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full ${className}`}
      style={{
        width: meta.box,
        height: meta.box,
        background: broken ? RAMPS[seed % RAMPS.length] : '#f0f0f0',
        boxShadow: ring
          ? '0 0 0 1px rgba(255,255,255,0.18), 0 0 30px -10px rgba(255,255,255,0.5)'
          : '0 0 0 1px rgba(255,255,255,0.1)',
      }}
      aria-hidden="true"
    >
      {!broken ? (
        <img
          src={src}
          alt=""
          width={meta.box}
          height={meta.box}
          loading="lazy"
          onError={() => setBroken(true)}
          className="h-full w-full object-cover"
        />
      ) : (
        <span
          className="font-display select-none leading-none"
          style={{ color: '#000', fontSize: meta.font, fontWeight: 600, letterSpacing: '-0.04em' }}
        >
          {initials(user?.name || '?')}
        </span>
      )}
    </span>
  )
}
