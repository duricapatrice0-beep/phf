import { badgeFor } from '../../lib/badges'

const SIZES = {
  xs: { box: 'h-[18px] gap-0.5 px-1.5 text-[9px]', icon: 10 },
  sm: { box: 'h-5 gap-1 px-2 text-[10px]', icon: 11 },
  md: { box: 'h-6 gap-1.5 px-2.5 text-[11px]', icon: 13 },
}

export default function PointsBadge({ points = 0, size = 'sm', className = '' }) {
  const tier = badgeFor(points)
  const Icon = tier.icon
  const dims = SIZES[size] || SIZES.sm

  return (
    <span
      title={`${points} points · ${tier.label}${tier.next ? ` · ${tier.next.min - points} to ${tier.next.label}` : ''}`}
      className={`relative inline-flex shrink-0 items-center overflow-hidden rounded-full border-2 font-bold tracking-[0.08em] uppercase ${dims.box} ${tier.chip} ${tier.anim} ${className}`}
    >
      <Icon size={dims.icon} variant="Bold" className="relative z-10" />
      <span className="relative z-10">{tier.label}</span>
    </span>
  )
}
