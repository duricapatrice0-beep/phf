const VARIANTS = {
  primary: 'bg-white text-black hover:bg-white/80',
  secondary: 'bg-raised text-white border border-line hover:border-white/25 hover:bg-overlay',
  outline: 'border border-white/15 text-white hover:bg-white/5 hover:border-white/30',
  ghost: 'text-mute hover:text-white hover:bg-white/5',
  soft: 'bg-white/[0.06] text-white border border-white/10 hover:bg-white/[0.1]',
  danger: 'bg-white/5 text-white border border-white/15 hover:bg-white/10',
}

const SIZES = {
  xs: 'h-7 px-2.5 text-[12px] gap-1.5 rounded-lg',
  sm: 'h-8 px-3 text-[13px] gap-1.5 rounded-lg',
  md: 'h-10 px-4 text-sm gap-2 rounded-xl',
  lg: 'h-11 px-5 text-[15px] gap-2 rounded-xl',
}

export function Button({
  variant = 'secondary',
  size = 'md',
  className = '',
  children,
  type = 'button',
  ...rest
}) {
  return (
    <button
      type={type}
      className={`inline-flex items-center justify-center font-medium whitespace-nowrap transition-colors duration-200 ${
        VARIANTS[variant]
      } ${SIZES[size]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}

const ICON_SIZES = {
  sm: 'h-8 w-8 rounded-lg',
  md: 'h-9 w-9 rounded-lg',
  lg: 'h-10 w-10 rounded-xl',
}

export function IconButton({
  size = 'md',
  variant = 'ghost',
  className = '',
  children,
  type = 'button',
  ...rest
}) {
  return (
    <button
      type={type}
      className={`inline-flex items-center justify-center transition-colors duration-200 ${
        VARIANTS[variant]
      } ${ICON_SIZES[size]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}
