export function Skeleton({ className = '', rounded = 'rounded-lg' }) {
  return <div className={`phf-shimmer bg-white/[0.045] ${rounded} ${className}`} />
}

export function SkeletonPostCard() {
  return (
    <div className="-mx-3 border-b border-line px-3 py-7 sm:-mx-4 sm:px-4">
      <div className="flex items-center gap-2">
        <Skeleton className="h-3 w-3" rounded="rounded-full" />
        <Skeleton className="h-3 w-24" rounded="rounded-full" />
        <Skeleton className="h-3 w-14" rounded="rounded-full" />
      </div>
      <div className="mt-3.5 space-y-2.5">
        <Skeleton className="h-5 w-[72%]" rounded="rounded-md" />
        <Skeleton className="h-5 w-[46%]" rounded="rounded-md" />
      </div>
      <div className="mt-3.5 space-y-2">
        <Skeleton className="h-3 w-full" rounded="rounded-full" />
        <Skeleton className="h-3 w-[92%]" rounded="rounded-full" />
        <Skeleton className="h-3 w-[38%]" rounded="rounded-full" />
      </div>
      <div className="mt-5 flex flex-wrap items-center gap-2">
        <Skeleton className="h-7 w-7" rounded="rounded-full" />
        <Skeleton className="h-7 w-16" rounded="rounded-full" />
        <Skeleton className="h-7 w-14" rounded="rounded-full" />
        <Skeleton className="ml-auto h-7 w-16" rounded="rounded-full" />
      </div>
    </div>
  )
}

export function SkeletonComment() {
  return (
    <div className="flex gap-3 py-4">
      <Skeleton className="h-8 w-8 shrink-0" rounded="rounded-full" />
      <div className="min-w-0 flex-1 space-y-2">
        <Skeleton className="h-3 w-32" />
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-[78%]" />
        <div className="flex gap-3 pt-1">
          <Skeleton className="h-3 w-10" />
          <Skeleton className="h-3 w-12" />
        </div>
      </div>
    </div>
  )
}

export function SkeletonPage({ rows = 3 }) {
  return (
    <div className="pt-6 sm:pt-8">
      <Skeleton className="h-7 w-40" rounded="rounded-md" />
      <Skeleton className="mt-3 h-3.5 w-64" />
      <div className="mt-8 space-y-4">
        {Array.from({ length: rows }).map((_, index) => (
          <div key={index} className="rounded-2xl border border-line bg-surface p-4">
            <div className="flex items-center gap-3">
              <Skeleton className="h-8 w-8" rounded="rounded-full" />
              <Skeleton className="h-3.5 w-32" />
            </div>
            <Skeleton className="mt-3 h-4 w-[70%]" rounded="rounded-md" />
            <Skeleton className="mt-2 h-3 w-full" />
            <Skeleton className="mt-1.5 h-3 w-[80%]" />
          </div>
        ))}
      </div>
    </div>
  )
}

export function SkeletonThread() {
  return (
    <div className="pt-5 pb-10 sm:pt-7">
      <Skeleton className="h-3 w-28" rounded="rounded-full" />
      <Skeleton className="mt-4 h-7 w-[85%]" rounded="rounded-md" />
      <Skeleton className="mt-3 h-7 w-[55%]" rounded="rounded-md" />
      <div className="mt-5 space-y-2.5">
        <Skeleton className="h-3.5 w-full" />
        <Skeleton className="h-3.5 w-[94%]" />
        <Skeleton className="h-3.5 w-[70%]" />
      </div>
      <div className="mt-6 h-px bg-line" />
      <div className="pt-2">
        <SkeletonComment />
        <SkeletonComment />
      </div>
    </div>
  )
}

export function SkeletonProfile() {
  return (
    <div className="pb-10">
      <div className="h-32 rounded-t-2xl border border-line bg-white/[0.02] sm:h-44" />
      <div className="rounded-b-2xl border border-t-0 border-line bg-surface px-4 pb-5 sm:px-6">
        <div className="relative z-10 -mt-12 flex items-end justify-between gap-3">
          <Skeleton className="h-24 w-24" rounded="rounded-full" />
          <div className="mb-2 flex gap-2">
            <Skeleton className="h-9 w-9" />
            <Skeleton className="h-9 w-24" />
          </div>
        </div>
        <Skeleton className="mt-4 h-5 w-40" rounded="rounded-md" />
        <Skeleton className="mt-2.5 h-3.5 w-64" />
        <div className="mt-5 grid grid-cols-4 gap-3 border-t border-line pt-4">
          {[0, 1, 2, 3].map((cell) => (
            <div key={cell} className="flex flex-col items-center gap-2">
              <Skeleton className="h-4 w-10" rounded="rounded-md" />
              <Skeleton className="h-2.5 w-14" rounded="rounded-full" />
            </div>
          ))}
        </div>
      </div>
      <div className="mt-6">
        <SkeletonPostCard />
        <SkeletonPostCard />
      </div>
    </div>
  )
}
