export default function Tabs({ tabs, value, onChange, className = '', size = 'md' }) {
  const heights = size === 'sm' ? 'h-9 text-[13px]' : 'h-11 text-sm'
  return (
    <div className={`flex items-center gap-1 ${className}`} role="tablist">
      {tabs.map((tab) => {
        const active = tab.id === value
        return (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(tab.id)}
            className={`relative flex items-center gap-1.5 rounded-lg px-3 font-medium transition-colors duration-200 ${heights} ${
              active ? 'bg-red-900 text-white' : 'text-dim hover:bg-white/[0.04] hover:text-mute'
            }`}
          >
            {tab.icon ? <tab.icon size={15} variant="Bold" /> : null}
            <span className="whitespace-nowrap">{tab.label}</span>
          </button>
        )
      })}
    </div>
  )
}
