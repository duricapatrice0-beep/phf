import { getIcon } from '../../lib/iconMap'

export function Pill({ children, className = '', ...rest }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-line bg-raised px-2.5 py-1 text-[11px] leading-none font-medium tracking-wide whitespace-nowrap text-mute ${className}`}
      {...rest}
    >
      {children}
    </span>
  )
}

export function CategoryTag({ icon, label, onClick, active = false, size = 'sm' }) {
  const Icon = getIcon(icon)
  const dims = size === 'xs' ? 'h-5 px-2 text-[10px] gap-1' : 'h-6 px-2.5 text-[11px] gap-1.5'
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center rounded-full border font-medium leading-none whitespace-nowrap transition-colors duration-200 ${dims} ${
        active
          ? 'border-red-900 bg-red-900 text-white'
          : 'border-line bg-raised text-mute hover:border-white/25 hover:text-white'
      }`}
    >
      <Icon size={size === 'xs' ? 11 : 12} variant="Bold" />
      {label}
    </button>
  )
}

export function Badge({ count, className = '' }) {
  return (
    <span
      className={`pointer-events-none absolute -top-1 -right-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-red-900 px-1 text-[9px] leading-none font-semibold text-white ring-1 ring-white/15 ${className}`}
    >
      {count}
    </span>
  )
}

export function Divider({ className = '' }) {
  return <div className={`h-px w-full bg-line ${className}`} />
}
