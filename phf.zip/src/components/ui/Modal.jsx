import { useEffect } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { CloseCircle } from '../icons'

export default function Modal({ open, onClose, children, width = 'max-w-2xl', labelId }) {
  useEffect(() => {
    if (!open) return undefined
    const previous = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const onKeyDown = (event) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => {
      document.body.style.overflow = previous
      window.removeEventListener('keydown', onKeyDown)
    }
  }, [open, onClose])

  return (
    <AnimatePresence>
      {open ? (
        <div
          className="fixed inset-0 z-[100] flex items-end justify-center sm:items-center"
          onClick={(event) => event.stopPropagation()}
        >
          <motion.div
            className="absolute inset-0 bg-black/75 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby={labelId}
            initial={{ opacity: 0, scale: 0.96, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 16 }}
            transition={{ type: 'spring', stiffness: 340, damping: 30, mass: 0.9 }}
            className={`relative z-10 max-h-[92vh] w-full ${width} overflow-hidden rounded-t-2xl border border-line bg-surface shadow-panel sm:rounded-2xl`}
          >
            {children}
          </motion.div>
        </div>
      ) : null}
    </AnimatePresence>
  )
}

export function ModalHeader({ title, subtitle, onClose, titleId }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4 sm:px-6">
      <div className="min-w-0">
        <h2 id={titleId} className="display-tight text-lg text-white sm:text-xl">
          {title}
        </h2>
        {subtitle ? <p className="mt-1 text-[13px] text-dim">{subtitle}</p> : null}
      </div>
      <motion.button
        type="button"
        onClick={onClose}
        aria-label="Close dialog"
        className="-m-1 rounded-full p-1 text-dim transition-colors hover:text-white"
      >
        <CloseCircle size={22} variant="Bold" />
      </motion.button>
    </div>
  )
}
