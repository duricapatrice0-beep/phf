import { motion } from 'framer-motion'

export default function EmptyState({ icon: Icon, title, body, action, className = '' }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className={`relative flex flex-col items-center justify-center overflow-hidden rounded-2xl border border-line bg-surface px-6 py-16 text-center ${className}`}
    >
      <div className="relative mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-line bg-raised shadow-panel">
        {Icon ? <Icon size={24} variant="Bold" className="text-white" /> : null}
      </div>
      <h3 className="display-tight relative text-xl text-white">{title}</h3>
      <p className="relative mt-2 max-w-sm text-sm leading-relaxed text-dim">{body}</p>
      {action ? <div className="relative mt-6">{action}</div> : null}
    </motion.div>
  )
}
