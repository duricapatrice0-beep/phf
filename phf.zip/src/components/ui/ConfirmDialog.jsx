import Modal, { ModalHeader } from './Modal'

export default function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  body,
  confirmLabel = 'Delete',
  cancelLabel = 'Cancel',
  busy = false,
  error = null,
}) {
  return (
    <Modal open={open} onClose={onClose} width="max-w-sm" labelId="confirm-title">
      <ModalHeader titleId="confirm-title" title={title} onClose={onClose} />
      <div className="px-5 py-4 sm:px-6">
        <p className="text-[13.5px] leading-relaxed text-dim">{body}</p>
      </div>
      {error ? (
        <p className="border-t border-red-900 bg-red-900/20 px-5 py-2.5 text-[12.5px] text-white sm:px-6">
          {error}
        </p>
      ) : null}
      <div className="flex justify-end gap-2 border-t border-line bg-surface px-5 py-4 sm:px-6">
        <button
          type="button"
          onClick={onClose}
          className="h-10 rounded-xl border border-line px-4 text-sm font-medium text-mute transition-colors hover:border-white/20 hover:text-white"
        >
          {cancelLabel}
        </button>
        <button
          type="button"
          onClick={onConfirm}
          disabled={busy}
          className="inline-flex h-10 items-center rounded-xl bg-red-900 px-4 text-sm font-semibold text-white transition-colors hover:bg-red-900/75 disabled:opacity-40"
        >
          {busy ? 'Deleting…' : confirmLabel}
        </button>
      </div>
    </Modal>
  )
}
