import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from '../lib/router'
import {
  ArrowLeft2,
  Crown,
  Eye,
  Flash,
  Heart,
  Like1,
  Medal,
  PenTool,
  Ranking,
  Shield,
  Star,
  Star1,
  TickCircle,
  TrendUp,
  Verify,
} from '../components/icons'
import Avatar from '../components/ui/Avatar'
import PointsBadge from '../components/ui/PointsBadge'
import Tabs from '../components/ui/Tabs'
import EmptyState from '../components/ui/EmptyState'
import { SkeletonPage } from '../components/ui/Skeleton'
import { useStore } from '../lib/store'
import { compact } from '../lib/format'
import { BADGE_TIERS, POINT_RULES, badgeFor } from '../lib/badges'

const TABS = [
  { id: 'karma', label: 'All time' },
  { id: 'week', label: 'This week' },
]

const WEEK_MINUTES = 7 * 24 * 60
const PAGE_SIZE = 10

function ChevronRight(props) {
  const { className = '', ...rest } = props
  return <ArrowLeft2 {...rest} className={`rotate-180 ${className}`} />
}

const RANK_BADGES = [
  { icon: Crown, grad: 'linear-gradient(135deg, #fde047, #f59e0b)', ink: '#0a0a0a', name: 'Crown' },
  { icon: Medal, grad: 'linear-gradient(135deg, #f1f5f9, #94a3b8)', ink: '#0a0a0a', name: 'Medal' },
  { icon: Shield, grad: 'linear-gradient(135deg, #fdba74, #ea580c)', ink: '#0a0a0a', name: 'Shield' },
  { icon: Star, grad: 'linear-gradient(135deg, #60a5fa, #2563eb)', ink: '#ffffff', name: 'Star' },
  { icon: Flash, grad: 'linear-gradient(135deg, #a78bfa, #7c3aed)', ink: '#ffffff', name: 'Bolt' },
  { icon: TrendUp, grad: 'linear-gradient(135deg, #2dd4bf, #0d9488)', ink: '#0a0a0a', name: 'Trend' },
  { icon: Verify, grad: 'linear-gradient(135deg, #f472b6, #db2777)', ink: '#ffffff', name: 'Verified' },
  { icon: Eye, grad: 'linear-gradient(135deg, #22d3ee, #0891b2)', ink: '#0a0a0a', name: 'Watch' },
  { icon: Like1, grad: 'linear-gradient(135deg, #a3e635, #65a30d)', ink: '#0a0a0a', name: 'Like' },
  { icon: Star1, grad: 'linear-gradient(135deg, #fb923c, #ea580c)', ink: '#0a0a0a', name: 'Spark' },
]

const VALUE_STICKER = {
  3: 'bg-[#3b82f6] border-[#93c5fd] text-white',
  2: 'bg-[#ef4444] border-[#fecaca] text-white',
  1: 'bg-[#e4e4e7] border-[#52525b] text-black',
  0.5: 'bg-[#a3a3a3] border-[#e5e5e5] text-black',
}

const STEPS = [
  {
    n: '01',
    icon: PenTool,
    title: 'Contribute',
    body: 'Threads score +3, replies +1, comments +0.5. Your own words always count.',
    bg: '#e4e4e7',
    ring: '#52525b',
    ink: '#0a0a0a',
  },
  {
    n: '02',
    icon: Heart,
    title: 'Engage',
    body: 'React +1 and upvote +1 — but only on other people’s posts and comments.',
    bg: '#ef4444',
    ring: '#991b1b',
    ink: '#ffffff',
  },
  {
    n: '03',
    icon: Like1,
    title: 'Get it back',
    body: 'Reactions +1, comments +0.5 and upvotes +2 land on whatever you wrote.',
    bg: '#fde047',
    ring: '#b45309',
    ink: '#0a0a0a',
  },
  {
    n: '04',
    icon: TrendUp,
    title: 'Climb',
    body: 'All-time total sets your rank and badge. This week resets every 7 days.',
    bg: '#3b82f6',
    ring: '#1e40af',
    ink: '#ffffff',
  },
]

function useCountUp(target, ms = 750) {
  const [value, setValue] = useState(0)
  useEffect(() => {
    let frame
    let start = null
    const tick = (now) => {
      if (start == null) start = now
      const p = Math.min((now - start) / ms, 1)
      const eased = 1 - Math.pow(1 - p, 3)
      const raw = target * eased
      setValue(target % 1 !== 0 ? Math.round(raw * 2) / 2 : Math.round(raw))
      if (p < 1) frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [target, ms])
  return value
}

function CountUp({ value }) {
  const shown = useCountUp(value)
  return <>{value >= 1000 ? compact(shown) : shown}</>
}

function RankBadge({ rank }) {
  const spec = RANK_BADGES[rank - 1]
  if (!spec) return null
  const Icon = spec.icon
  return (
    <span
      title={`#${rank} — ${spec.name} rank`}
      style={{ backgroundImage: spec.grad, color: spec.ink }}
      className="flex h-8 w-8 shrink-0 items-center justify-center shadow-[3px_3px_0_0_rgba(0,0,0,0.55)]"
    >
      <Icon size={15} variant="Bold" />
    </span>
  )
}

function RankSlot({ rank }) {
  const color =
    rank === 1 ? 'text-yellow-300' : rank === 2 ? 'text-zinc-300' : rank === 3 ? 'text-orange-300' : 'text-mute'
  return (
    <span className="flex shrink-0 items-center gap-2">
      <span className="flex w-8 justify-center">{rank <= 10 ? <RankBadge rank={rank} /> : null}</span>
      <span
        className={`w-7 text-right font-sans text-[15px] font-black tracking-tight tabular-nums ${color}`}
      >
        {rank}
      </span>
    </span>
  )
}

function TierProgress({ points, compactBar = false }) {
  const tier = badgeFor(points)
  if (!tier.next) {
    return <span className="text-[10.5px] font-semibold text-yellow-300">Top tier reached</span>
  }
  const pct = Math.max(4, Math.round(((points - tier.min) / (tier.next.min - tier.min)) * 100))
  return (
    <span className={`flex items-center gap-2 ${compactBar ? '' : 'w-full'}`}>
      <span className={`h-1.5 overflow-hidden rounded-full bg-white/10 ${compactBar ? 'w-20' : 'w-full max-w-40'}`}>
        <span className="block h-full rounded-full bg-white/75" style={{ width: `${pct}%` }} />
      </span>
      <span className="shrink-0 text-[10.5px] text-faint tabular-nums">
        {tier.next.min - points} pts to {tier.next.label}
      </span>
    </span>
  )
}

function Section({ kicker, title, children }) {
  return (
    <section className="mt-11">
      <div className="flex items-center gap-3">
        <span className="label-caps text-[10px] text-faint">{kicker}</span>
        <span className="h-px flex-1 bg-line" />
      </div>
      <h2 className="display-tight mt-3 text-[20px] font-bold text-white">{title}</h2>
      {children}
    </section>
  )
}

function PointsChip({ points }) {
  return (
    <span
      className={`inline-flex h-5 shrink-0 items-center rounded-full border-2 px-1.5 text-[10px] leading-none font-bold tabular-nums ${
        VALUE_STICKER[points] || VALUE_STICKER[0.5]
      }`}
    >
      +{points}
    </span>
  )
}

function RuleRow({ rule }) {
  const Icon = rule.icon
  return (
    <li className="flex items-center gap-3 py-2">
      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-line bg-black text-mute">
        <Icon size={13} variant="Bold" />
      </span>
      <span className="min-w-0 flex-1 truncate text-[13px] text-dim">{rule.label}</span>
      <PointsChip points={rule.points} />
    </li>
  )
}

function RankGuide({ me }) {
  const myTier = badgeFor(me?.karma || 0)
  return (
    <div>
      <Section kicker="The rules" title="How the ladder works">
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((step, index) => {
            const Icon = step.icon
            return (
              <motion.div
                key={step.n}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.35, delay: index * 0.05, ease: [0.16, 1, 0.3, 1] }}
                className="rounded-2xl border border-line bg-surface p-4"
              >
                <span
                  style={{ background: step.bg, borderColor: step.ring, color: step.ink }}
                  className="flex h-7 w-7 items-center justify-center rounded-full border-2 font-display text-[11px] font-bold"
                >
                  {step.n}
                </span>
                <p className="mt-3 text-[14px] font-semibold text-white">{step.title}</p>
                <p className="mt-1 text-[12.5px] leading-relaxed text-faint">{step.body}</p>
              </motion.div>
            )
          })}
        </div>
        <p className="mt-3 text-[12px] leading-relaxed text-faint">
          Self-help doesn’t pay: you can’t react to or upvote your own content — and spam doesn’t either. The
          6th comment or 4th thread inside 10 minutes, plus any repeated comment text, scores nothing.
        </p>
      </Section>

      <Section kicker="The economy" title="Every point, accounted for">
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div className="rounded-2xl border border-line bg-surface p-4">
            <p className="label-caps text-[10px] text-faint">You give — by acting</p>
            <ul className="mt-1 divide-y divide-line">
              {POINT_RULES.give.map((rule) => (
                <RuleRow key={rule.label} rule={rule} />
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-line bg-surface p-4">
            <p className="label-caps text-[10px] text-faint">You receive — from others</p>
            <ul className="mt-1 divide-y divide-line">
              {POINT_RULES.receive.map((rule) => (
                <RuleRow key={rule.label} rule={rule} />
              ))}
            </ul>
          </div>
        </div>
      </Section>

      <Section kicker="The stickers" title="Badges & what they take">
        <div className="mt-4 flex flex-wrap items-center gap-2">
          {BADGE_TIERS.map((tier, index) => (
            <span key={tier.id} className="flex items-center gap-2">
              <span className="text-[11.5px] font-semibold text-mute tabular-nums">{compact(tier.min)} pts</span>
              {index < BADGE_TIERS.length - 1 ? (
                <ChevronRight size={12} variant="Bold" className="text-faint" />
              ) : null}
            </span>
          ))}
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {BADGE_TIERS.map((tier) => {
            const Icon = tier.icon
            const mine = tier.id === myTier.id
            return (
              <div
                key={tier.id}
                className={`relative rounded-2xl border bg-surface p-4 ${
                  mine ? 'border-white/25 ring-1 ring-white/10' : 'border-line'
                }`}
              >
                {mine ? (
                  <span className="absolute top-3 right-3 rounded-full bg-white px-1.5 py-0.5 text-[8.5px] font-bold tracking-wide text-black uppercase">
                    You are here
                  </span>
                ) : null}
                <span className={`relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border-2 ${tier.chip} ${tier.anim}`}>
                  <Icon size={17} variant="Bold" className="relative z-10" />
                </span>
                <p className="mt-3 font-display text-[22px] leading-none font-bold text-white tabular-nums">
                  {tier.min.toLocaleString()}
                  <span className="ml-1 text-[11px] font-medium text-faint">pts</span>
                </p>
                <p className="mt-2 flex items-center gap-1.5 text-[12.5px] font-semibold text-white">
                  {tier.label}
                </p>
                <p className="mt-1 text-[11.5px] leading-relaxed text-faint">{tier.perk}</p>
              </div>
            )
          })}
        </div>
      </Section>

      <Section kicker="Why bother" title="What points buy you">
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {[
            {
              title: 'Wear it everywhere',
              body: 'Your sticker sits next to your name on the profile, every thread and every comment.',
            },
            {
              title: 'Own the rail',
              body: 'Top three get a permanent seat in Top contributors on every forum page.',
            },
            {
              title: 'Weekly bragging rights',
              body: 'This week’s ladder clears every 7 days — a fresh race even if the all-time crown is taken.',
            },
          ].map((item, index) => (
            <div key={item.title} className="flex gap-3 rounded-2xl border border-line bg-surface p-4">
              <TickCircle
                size={16}
                variant="Bold"
                className={index === 0 ? 'mt-0.5 shrink-0 text-white' : index === 1 ? 'mt-0.5 shrink-0 text-yellow-300' : 'mt-0.5 shrink-0 text-red-900'}
              />
              <div>
                <p className="text-[13.5px] font-semibold text-white">{item.title}</p>
                <p className="mt-1 text-[12px] leading-relaxed text-faint">{item.body}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-5 flex flex-wrap items-center gap-4 rounded-2xl border border-line bg-surface px-5 py-4">
          <div className="min-w-0 flex-1">
            <p className="text-[14px] font-semibold text-white">Ranks move in real time.</p>
            <p className="mt-0.5 text-[12.5px] text-faint">
              Post something, react to something, and watch the numbers change before you refresh.
            </p>
          </div>
          <Link
            to="/forum"
            className="inline-flex h-10 shrink-0 items-center gap-2 rounded-full bg-white px-5 text-[13px] font-bold text-black transition-colors hover:bg-white/85"
          >
            Write a thread
            <ChevronRight size={14} variant="Bold" />
          </Link>
        </div>
      </Section>
    </div>
  )
}

export default function RankPage() {
  const { status, users, posts, comments, me } = useStore()
  const [tab, setTab] = useState('karma')
  const [page, setPage] = useState(1)

  const { rows, totalKarma, myIndex } = useMemo(() => {
    const threads = new Map()
    const replies = new Map()
    for (const post of posts) threads.set(post.authorId, (threads.get(post.authorId) || 0) + 1)
    for (const comment of comments) replies.set(comment.authorId, (replies.get(comment.authorId) || 0) + 1)

    let karmaSum = 0
    const mapped = users.map((user) => {
      karmaSum += user.karma
      const weekActivity =
        posts.filter((post) => post.authorId === user.id && post.minutes <= WEEK_MINUTES).length * 3 +
        comments.filter((comment) => comment.authorId === user.id && comment.minutes <= WEEK_MINUTES).length
      return {
        user,
        threads: threads.get(user.id) || 0,
        replies: replies.get(user.id) || 0,
        weekActivity,
        score: tab === 'karma' ? user.karma : weekActivity,
      }
    })

    const list = tab === 'week' ? mapped.filter((row) => row.score > 0) : mapped
    list.sort((a, b) => b.score - a.score || b.threads - a.threads || a.user.handle.localeCompare(b.user.handle))
    const index = me ? list.findIndex((row) => row.user.id === me.id) : -1
    return { rows: list, totalKarma: karmaSum, myIndex: index }
  }, [tab, users, posts, comments, me])

  if (status === 'loading') {
    return <SkeletonPage rows={5} />
  }

  const subtitle =
    tab === 'karma'
      ? 'Points are receipts — start a thread (+3), reply (+1), comment (+0.5), react (+1), upvote (+1), then collect what others hand back. Spam pays zero.'
      : 'Threads and replies from the last seven days. A thread counts triple, because starting beats agreeing.'

  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE))
  const safePage = Math.min(page, totalPages)
  const start = (safePage - 1) * PAGE_SIZE
  const pageRows = rows.slice(start, start + PAGE_SIZE)
  const myRow = myIndex >= 0 ? rows[myIndex] : null
  const meInPage = myIndex >= start && myIndex < start + PAGE_SIZE
  const showMyPosition = Boolean(myRow && !meInPage)
  const myRank = myIndex + 1
  const myPoints = me?.karma || 0
  const allTimeRank = (() => {
    const sorted = [...users].sort((a, b) => b.karma - a.karma)
    const idx = me ? sorted.findIndex((u) => u.id === me.id) : -1
    return idx >= 0 ? idx + 1 : null
  })()

  const onTab = (id) => {
    setTab(id)
    setPage(1)
  }

  const pageNumbers = []
  for (let n = 1; n <= totalPages; n += 1) pageNumbers.push(n)

  const rowBody = (row, rank, isMe, pageKey) => (
    <motion.div
      key={`${pageKey}-${row.user.id}`}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: Math.min(rank - 1, 9) * 0.03, ease: [0.16, 1, 0.3, 1] }}
      className="border-t border-line first:border-t-0"
    >
      <Link
        to={`/u/${row.user.handle}`}
        className={`flex items-center gap-3 px-4 py-3.5 transition-colors hover:bg-white/[0.03] ${
          rank === 1 ? 'bg-yellow-300/[0.045]' : isMe ? 'bg-white/[0.035]' : ''
        }`}
      >
        <RankSlot rank={rank} />
        <Avatar user={row.user} size="md" />

        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2">
            <span className="truncate text-[14px] font-semibold text-white">{row.user.name}</span>
            <PointsBadge points={row.user.karma} size="xs" />
            {row.user.role !== 'Member' && row.user.role !== 'New' ? (
              <span className="shrink-0 rounded border border-white/15 px-1.5 py-0.5 text-[9.5px] font-semibold tracking-wide text-mute uppercase">
                {row.user.role}
              </span>
            ) : null}
            {isMe ? (
              <span className="shrink-0 rounded-full border border-red-900 bg-red-900/30 px-1.5 py-0.5 text-[9.5px] font-semibold tracking-wide text-white uppercase">
                You
              </span>
            ) : null}
          </span>
          <span className="mt-0.5 block truncate text-[12px] text-faint">
            @{row.user.handle} · {row.threads} thread{row.threads === 1 ? '' : 's'} · {row.replies} repl
            {row.replies === 1 ? 'y' : 'ies'}
            {isMe && myRow?.user.karma != null && tab === 'karma' ? (
              <span className="ml-3 inline-flex align-middle">
                <TierProgress points={row.user.karma} compactBar />
              </span>
            ) : null}
          </span>
        </span>

        <span className="shrink-0 text-right">
          <span className="block text-[15px] font-semibold text-white tabular-nums">{compact(row.score)}</span>
          <span className="label-caps mt-0.5 block text-[9.5px] text-faint">
            {tab === 'karma' ? 'points' : 'activity'}
          </span>
        </span>
      </Link>
    </motion.div>
  )

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="pb-10"
    >
      <header className="pt-6 sm:pt-8">
        <h1 className="display-tight text-[26px] leading-none font-bold text-white sm:text-[34px]">Rank Ladder</h1>
        <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-dim">{subtitle}</p>

        <div className="mt-5 grid grid-cols-2 border-t border-line pt-4 sm:grid-cols-4">
          {[
            { label: 'Members', value: users.length },
            { label: 'Points given', value: totalKarma },
            { label: 'Your points', value: myPoints },
            { label: 'Your rank', value: allTimeRank },
          ].map((stat, index) => (
            <div
              key={stat.label}
              className={`py-1 ${index % 2 === 1 ? 'border-l border-line pl-4' : ''} ${
                index >= 2 ? 'mt-3 sm:mt-0' : ''
              } ${index === 2 ? 'sm:border-l sm:border-line sm:pl-4' : ''}`}
            >
              <span className="block text-[18px] font-semibold text-white tabular-nums sm:text-[20px]">
                {stat.label === 'Your rank' ? (
                  stat.value ? (
                    <>
                      #<CountUp value={stat.value} />
                    </>
                  ) : (
                    '—'
                  )
                ) : (
                  <CountUp value={stat.value} />
                )}
              </span>
              <span className="label-caps mt-1 block text-[10px] text-faint">{stat.label}</span>
            </div>
          ))}
        </div>

        {me ? (
          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-2xl border border-line bg-surface px-4 py-3">
            <span className="flex items-center gap-2">
              <Avatar user={me} size="sm" />
              <span className="text-[13px] font-semibold text-white">{me.name}</span>
              <PointsBadge points={me.karma} size="xs" />
            </span>
            <span className="hidden h-4 w-px bg-line sm:block" />
            <span className="flex-1">
              <TierProgress points={me.karma} />
            </span>
          </div>
        ) : null}
      </header>

      <div className="sticky top-16 z-30 mt-5 border-b border-line bg-black/75 backdrop-blur-xl">
        <Tabs tabs={TABS} value={tab} onChange={onTab} />
      </div>

      {rows.length ? (
        <div className="mt-5 overflow-hidden rounded-2xl border border-line bg-surface">
          {pageRows.map((row) => {
            const rank = rows.indexOf(row) + 1
            return rowBody(row, rank, me?.id === row.user.id, `${tab}-${safePage}`)
          })}

          {showMyPosition ? (
            <div className="border-t border-line">
              <div className="flex items-center gap-3 px-4 pt-3 pb-1">
                <span className="h-px flex-1 bg-line" />
                <span className="label-caps text-[9.5px] text-faint">Your position</span>
                <span className="h-px flex-1 bg-line" />
              </div>
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              >
                <Link
                  to={`/u/${myRow.user.handle}`}
                  className="flex items-center gap-3 border-l-2 border-red-900 bg-red-900/[0.12] px-4 py-3.5 transition-colors hover:bg-red-900/[0.18]"
                >
                  <RankSlot rank={myRank} />
                  <Avatar user={myRow.user} size="md" />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate text-[14px] font-semibold text-white">{myRow.user.name}</span>
                      <PointsBadge points={myRow.user.karma} size="xs" />
                      <span className="shrink-0 rounded-full border border-red-900 bg-red-900/30 px-1.5 py-0.5 text-[9.5px] font-semibold tracking-wide text-white uppercase">
                        You
                      </span>
                    </span>
                    <span className="mt-0.5 block">
                      <TierProgress points={myRow.user.karma} compactBar />
                    </span>
                  </span>
                  <span className="shrink-0 text-right">
                    <span className="block text-[15px] font-semibold text-white tabular-nums">
                      {compact(myRow.score)}
                    </span>
                    <span className="label-caps mt-0.5 block text-[9.5px] text-faint">
                      {tab === 'karma' ? 'points' : 'activity'}
                    </span>
                  </span>
                </Link>
              </motion.div>
            </div>
          ) : null}

          {totalPages > 1 || rows.length > 0 ? (
            <nav className="flex flex-wrap items-center justify-between gap-3 border-t border-line px-4 py-3">
              <span className="text-[11.5px] text-faint tabular-nums">
                Showing {start + 1}–{Math.min(start + PAGE_SIZE, rows.length)} of {rows.length}
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={safePage <= 1}
                  onClick={() => setPage(safePage - 1)}
                  aria-label="Previous page"
                  className="flex h-7 w-7 items-center justify-center rounded-lg border border-line text-mute transition-colors hover:bg-white/5 hover:text-white disabled:pointer-events-none disabled:opacity-30"
                >
                  <ArrowLeft2 size={13} variant="Bold" />
                </button>
                {pageNumbers.map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setPage(n)}
                    className={`h-7 min-w-7 rounded-lg border px-2 text-[12px] font-semibold tabular-nums transition-colors ${
                      n === safePage
                        ? 'border-white bg-white text-black'
                        : 'border-line text-mute hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    {n}
                  </button>
                ))}
                <button
                  type="button"
                  disabled={safePage >= totalPages}
                  onClick={() => setPage(safePage + 1)}
                  aria-label="Next page"
                  className="flex h-7 w-7 items-center justify-center rounded-lg border border-line text-mute transition-colors hover:bg-white/5 hover:text-white disabled:pointer-events-none disabled:opacity-30"
                >
                  <ChevronRight size={13} variant="Bold" />
                </button>
              </div>
            </nav>
          ) : null}
        </div>
      ) : (
        <div className="mt-6">
          <EmptyState
            icon={Ranking}
            title="No activity this week yet"
            body="Nobody has started or replied to a thread in the last seven days. The all-time ladder still remembers everything."
          />
        </div>
      )}

      <RankGuide me={me} />
    </motion.div>
  )
}
