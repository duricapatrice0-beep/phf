import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Link, useRouter } from '../lib/router'
import { Bookmark2, Calendar, Copy, Edit, Notification, Profile2User, TickCircle, UserAdd, Verify } from '../components/icons'
import Avatar from '../components/ui/Avatar'
import PointsBadge from '../components/ui/PointsBadge'
import { badgeFor } from '../lib/badges'
import EmptyState from '../components/ui/EmptyState'
import { SkeletonProfile } from '../components/ui/Skeleton'
import Tabs from '../components/ui/Tabs'
import PostCard from '../components/post/PostCard'
import EditProfileModal from '../components/modal/EditProfileModal'
import { useStore } from '../lib/store'
import { compact, timeAgo } from '../lib/format'

function CommentPreview({ comment }) {
  const { userByHandle, getPost } = useStore()
  const author = userByHandle(comment.author) || { name: 'Member', handle: comment.author, seed: 0 }
  const post = getPost(comment.postId)
  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      className="rounded-2xl border border-line bg-surface p-4 transition-[border-color,box-shadow] duration-300 hover:border-white/[0.12] sm:p-5"
    >
      <div className="flex items-center gap-2 text-[11.5px] text-faint">
        <Avatar user={author} size="xs" />
        <span className="font-medium text-mute">{author.name}</span>
        <span>·</span>
        <span>{timeAgo(comment.minutes)} ago</span>
        <span className="ml-auto rounded-full border border-line bg-raised px-2 py-0.5 text-[10.5px] text-dim">
          {compact(comment.score)} likes
        </span>
      </div>
      <p className="mt-2.5 line-clamp-3 text-[14px] leading-relaxed text-mute">{comment.body}</p>
      {post ? (
        <Link
          to={`/post/${post.id}`}
          className="mt-3 inline-flex items-center gap-1.5 text-[12px] text-dim transition-colors hover:text-white"
        >
          in “{post.title}” →
        </Link>
      ) : null}
    </motion.article>
  )
}

export default function ProfilePage({ handle }) {
  const { navigate } = useRouter()
  const { me, userByHandle, posts, comments, isFollowing, toggleFollow, status } = useStore()
  const [tab, setTab] = useState('posts')
  const [editOpen, setEditOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const user = userByHandle(handle)

  const userPosts = useMemo(() => posts.filter((post) => post.authorId === user?.id), [posts, user])
  const userComments = useMemo(
    () => comments.filter((comment) => comment.authorId === user?.id),
    [comments, user],
  )
  const savedPosts = useMemo(() => posts.filter((post) => post.saved), [posts])

  if (status === 'loading') {
    return <SkeletonProfile />
  }

  if (!user) {
    return (
      <div className="py-12">
        <EmptyState
          icon={UserAdd}
          title="No such profile"
          body="That handle doesn’t exist on .phf — it may have been renamed or removed."
          action={
            <button
              type="button"
              onClick={() => navigate('/')}
              className="inline-flex h-10 items-center rounded-xl bg-white px-4 text-sm font-semibold text-black"
            >
              Back to feed
            </button>
          }
        />
      </div>
    )
  }

  const isSelf = user.id === me?.id
  const followerCount = user.followers
  const follows = isFollowing(user.id)
  const badgeTier = badgeFor(user.karma)
  const activeTab = isSelf || tab !== 'saved' ? tab : 'posts'

  const tabs = [
    { id: 'posts', label: userPosts.length ? `Posts · ${userPosts.length}` : 'Posts' },
    { id: 'comments', label: userComments.length ? `Comments · ${userComments.length}` : 'Comments' },
    ...(isSelf ? [{ id: 'saved', label: savedPosts.length ? `Saved · ${savedPosts.length}` : 'Saved' }] : []),
  ]

  const share = () => {
    navigator.clipboard?.writeText(window.location.href)
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1600)
  }

  const emptyCopy = {
    posts: isSelf
      ? { title: 'No posts yet', body: 'Your threads will show up here. Start with the question you keep asking in group chats.' }
      : { title: 'No posts yet', body: `${user.name.split(' ')[0]} hasn’t published anything to .phf yet.` },
    comments: { title: 'No comments yet', body: 'Replies and threaded contributions will collect here.' },
    saved: { title: 'Nothing saved', body: 'Tap the bookmark on any thread to keep it here for later.' },
  }

  const current = emptyCopy[activeTab]

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }} className="pb-10">
      <div className="relative h-32 overflow-hidden rounded-t-2xl border border-b-0 border-line bg-raised sm:h-44">
        <div className="noise-overlay absolute inset-0 opacity-[0.06] mix-blend-overlay" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-white/20" />
      </div>

      <div className="rounded-b-2xl border border-line bg-surface px-4 pb-5 sm:px-6">
        <div className="relative z-10 -mt-12 flex items-end justify-between gap-3">
          <Avatar user={user} size="2xl" ring />
          <div className="mb-1 flex items-center gap-2">
            <span className="relative">
              <button
                type="button"
                aria-label="Copy profile link"
                onClick={share}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-line bg-raised text-dim transition-colors hover:border-white/20 hover:text-white"
              >
                {copied ? (
                  <TickCircle size={16} variant="Bold" className="text-yellow-300" />
                ) : (
                  <Copy size={16} variant="Bold" />
                )}
              </button>
              {copied ? (
                <motion.span
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className="absolute -top-8 right-0 rounded-lg border border-line bg-raised px-2.5 py-1 text-[11px] whitespace-nowrap text-white shadow-lift"
                >
                  Link copied
                </motion.span>
              ) : null}
            </span>
            <motion.button
              type="button"
              onClick={() => (isSelf ? setEditOpen(true) : !isSelf && toggleFollow(user.id))}
              className={`inline-flex h-9 items-center gap-1.5 rounded-xl px-4 text-[13px] font-semibold transition-colors ${
                isSelf
                  ? 'border border-white/15 text-white hover:bg-white/5'
                  : follows
                    ? 'border border-red-900 bg-red-900 text-white hover:bg-red-900/80'
                    : 'bg-blue-700 text-white hover:bg-blue-600'
              }`}
            >
              {isSelf ? (
                <>
                  <Edit size={15} variant="Bold" />
                  Edit profile
                </>
              ) : follows ? (
                <>
                  <UserAdd size={15} variant="Bold" />
                  Following
                </>
              ) : (
                <>
                  <UserAdd size={15} variant="Bold" />
                  Follow
                </>
              )}
            </motion.button>
          </div>
        </div>

        <div className="mt-4">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="display-tight text-[24px] leading-none font-bold text-white sm:text-[30px]">{user.name}</h1>
            <PointsBadge points={user.karma} size="md" />
            {user.role !== 'Member' && user.role !== 'New' ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-white/20 bg-white/[0.07] px-2 py-1 text-[10.5px] font-semibold tracking-wide text-white uppercase">
                <Verify size={11} variant="Bold" className="text-yellow-300" />
                {user.role}
              </span>
            ) : null}
            {badgeTier.next ? (
              <span className="text-[11.5px] text-faint">
                {badgeTier.next.min - user.karma} pts to {badgeTier.next.label} →
              </span>
            ) : null}
          </div>
          <p className="mt-1.5 text-[13.5px] text-dim">
            @{user.handle}
            {user.location ? (
              <>
                {' '}
                <span className="text-faint">·</span> {user.location}
              </>
            ) : null}{' '}
            <span className="text-faint">·</span> {user.role}
          </p>
          {user.bio ? (
            <p className="mt-3 max-w-2xl text-[14.5px] leading-relaxed text-mute">{user.bio}</p>
          ) : isSelf ? (
            <button
              type="button"
              onClick={() => setEditOpen(true)}
              className="mt-3 inline-flex max-w-2xl text-left text-[14.5px] leading-relaxed text-faint transition-colors hover:text-white"
            >
              Add a bio — tell the rooms who you are, and what you read first. →
            </button>
          ) : null}
        </div>

        <div className="mt-5 grid grid-cols-2 divide-line border-y border-line sm:grid-cols-5 sm:divide-x">
          {[
            { label: 'Threads', value: userPosts.length },
            { label: 'Comments', value: userComments.length },
            { label: 'Points', value: user.karma },
            { label: 'Followers', value: followerCount },
            { label: 'Following', value: user.following || 0 },
          ].map((stat, index) => (
            <div
              key={stat.label}
              className={`px-1 py-3.5 sm:px-4 ${index < 4 ? 'border-b border-line sm:border-b-0' : ''}`}
            >
              <p className="display-tight text-lg leading-none text-white tabular-nums sm:text-xl">{compact(stat.value)}</p>
              <p className="mt-1.5 text-[10.5px] tracking-[0.14em] text-faint uppercase">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-[11.5px] text-faint">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-raised px-2.5 py-1">
            <Calendar size={12} variant="Bold" />
            {user.joined}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-raised px-2.5 py-1">
            <Profile2User size={12} variant="Bold" />
            {compact(user.following)} following
          </span>
        </div>
      </div>

      <div className="sticky top-16 z-30 mt-5 border-b border-line bg-black/75 backdrop-blur-xl">
        <Tabs tabs={tabs} value={activeTab} onChange={setTab} />
      </div>

      <div className="mt-5">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
          >
            {activeTab === 'posts' ? (
              userPosts.length ? (
                <div className="space-y-3.5">
                  {userPosts.map((post, index) => (
                    <PostCard key={post.id} post={post} index={index} />
                  ))}
                </div>
              ) : (
                <EmptyState icon={Edit} title={current.title} body={current.body} />
              )
            ) : null}

            {activeTab === 'comments' ? (
              userComments.length ? (
                <div className="space-y-3.5">
                  {userComments.map((comment) => (
                    <CommentPreview key={comment.id} comment={comment} />
                  ))}
                </div>
              ) : (
                <EmptyState icon={Notification} title={current.title} body={current.body} />
              )
            ) : null}

            {activeTab === 'saved' ? (
              isSelf && savedPosts.length ? (
                <div className="space-y-3.5">
                  {savedPosts.map((post, index) => (
                    <PostCard key={post.id} post={post} index={index} />
                  ))}
                </div>
              ) : (
                <EmptyState icon={Bookmark2} title={current.title} body={current.body} />
              )
            ) : null}
          </motion.div>
        </AnimatePresence>
      </div>

      <EditProfileModal open={editOpen} onClose={() => setEditOpen(false)} user={user} />
    </motion.div>
  )
}
