import { motion } from 'framer-motion'
import { useRouter } from '../lib/router'
import EmptyState from '../components/ui/EmptyState'

export default function SoonPage({ title, subtitle, icon, heading, body }) {
  const { navigate } = useRouter()

  return (
    <div className="pb-10">
      <header className="pt-6 sm:pt-8">
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="display-tight text-[26px] leading-none font-bold text-white sm:text-[34px]"
        >
          {title}
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
          className="mt-2 text-[13.5px] text-dim"
        >
          {subtitle}
        </motion.p>
      </header>

      <div className="mt-6">
        <EmptyState
          icon={icon}
          title={heading}
          body={body}
          action={
            <button
              type="button"
              onClick={() => navigate('/forum')}
              className="inline-flex h-10 items-center rounded-xl bg-white px-4 text-sm font-semibold text-black transition-colors hover:bg-white/80"
            >
              Browse the forum
            </button>
          }
        />
      </div>
    </div>
  )
}
