import { Fragment, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Link, useRouter } from '../lib/router'
import { ArrowUp, Hashtag, Messages2, Star, TickCircle, UserAdd } from '../components/icons'
import Avatar from '../components/ui/Avatar'
import EmptyState from '../components/ui/EmptyState'
import { SkeletonPage } from '../components/ui/Skeleton'
import { useStore } from '../lib/store'
import { timeAgo } from '../lib/format'

const TYPE_ICON = {
  reply: Messages2,
  upvote: ArrowUp,
  mention: Hashtag,
  follow: UserAdd,
  badge: Star,
}

export default function NotificationsPage() {
  const { navigate } = useRouter()
  const { notifications, markAllRead, status } = useStore()
  const [hidden, setHidden] = useState(false)

  const isRead = (item) => !item.unread
  const unread = notifications.filter((item) => item.unread).length

  const today = notifications.filter((item) => item.minutes < 600)
  const earlier = notifications.filter((item) => item.minutes >= 600)

  const markAll = () => {
    markAllRead()
    setHidden(true)
    window.setTimeout(() => setHidden(false), 1400)
  }

  const Row = ({ item }) => {
    const actor = item.actor
    const Icon = TYPE_ICON[item.type] || Messages2
    const read = isRead(item)

    return (
      <motion.li
        layout
        onClick={() => (item.postId ? navigate(`/post/${item.postId}`) : navigate(`/u/${actor.handle}`))}
        transition={{ type: 'spring', stiffness: 500, damping: 34 }}
        className={`relative flex cursor-pointer gap-3 px-4 py-3.5 transition-colors sm:px-5 ${
          read ? '' : 'bg-red-900/15'
        } hover:bg-white/[0.05]`}
      >
        {!read ? (
          <motion.span
            layoutId={`dot-${item.id}`}
            className="absolute top-1/2 left-1.5 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-red-900 ring-2 ring-red-900/40"
          />
        ) : null}

        <div className="relative shrink-0">
          <Avatar user={actor} size="md" />
          <span className="absolute -right-1.5 -bottom-1.5 flex h-5 w-5 items-center justify-center rounded-full border border-line bg-raised text-mute">
            <Icon size={11} variant="Bold" />
          </span>
        </div>

        <div className="min-w-0 flex-1">
          <p className="text-[13.5px] leading-snug text-mute">
            <span className="font-semibold text-white">{actor.name}</span> {item.title}
          </p>
          {item.context ? (
            <p className="mt-1 line-clamp-1 text-[12.5px] text-dim">
              {item.context}
            </p>
          ) : null}
          <p className="mt-1.5 text-[11.5px] text-faint">{timeAgo(item.minutes)} ago</p>
        </div>

        <span className="self-center text-faint">
          <Link to={item.postId ? `/post/${item.postId}` : `/u/${actor.handle}`} className="block">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path d="M6 3.5 10.5 8 6 12.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Link>
        </span>
      </motion.li>
    )
  }

  if (status === 'loading') {
    return <SkeletonPage rows={3} />
  }

  return (
    <div className="pb-10">
      <header className="flex flex-wrap items-end justify-between gap-3 pt-6 sm:pt-8">
        <div>
          <motion.h1
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="display-tight text-[26px] leading-none font-bold text-white sm:text-[34px]"
          >
            Notifications
          </motion.h1>
          <p className="mt-2 text-[13.5px] text-dim">
            {unread > 0 ? `${unread} unread update${unread === 1 ? '' : 's'}` : 'You’re all caught up.'}
          </p>
        </div>
        <motion.button
          type="button"
          onClick={markAll}
          disabled={unread === 0}
          className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-white/15 px-3.5 text-[13px] font-medium text-white transition-colors hover:bg-white/5 disabled:opacity-40"
        >
          <TickCircle size={15} variant="Bold" />
          Mark all as read
        </motion.button>
      </header>

      <div className="mt-6 space-y-4">
        <section className="overflow-hidden rounded-2xl border border-line bg-surface">
          <header className="flex items-center justify-between border-b border-line px-4 py-3 sm:px-5">
            <h2 className="text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">Today</h2>
            <span className="text-[11px] text-faint tabular-nums">{today.length}</span>
          </header>
          <ul className="divide-y divide-line">
            <AnimatePresence initial={false}>
              {today.map((item) => (
                <Fragment key={item.id}>{Row({ item })}</Fragment>
              ))}
            </AnimatePresence>
          </ul>
        </section>

        <section className="overflow-hidden rounded-2xl border border-line bg-surface">
          <header className="flex items-center justify-between border-b border-line px-4 py-3 sm:px-5">
            <h2 className="text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">Earlier</h2>
            <span className="text-[11px] text-faint tabular-nums">{earlier.length}</span>
          </header>
          <ul className="divide-y divide-line">
            {earlier.map((item) => (
              <Fragment key={item.id}>{Row({ item })}</Fragment>
            ))}
          </ul>
        </section>
      </div>

      <AnimatePresence>
        {hidden ? (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.97 }}
            transition={{ type: 'spring', stiffness: 420, damping: 30 }}
            className="fixed bottom-24 left-1/2 z-[80] -translate-x-1/2 rounded-xl border border-line bg-raised px-4 py-2.5 text-[13px] text-white shadow-panel md:bottom-8"
          >
            All caught up
          </motion.div>
        ) : null}
      </AnimatePresence>

      {unread === 0 && notifications.length === 0 ? (
        <EmptyState icon={Star} title="No notifications" body="Nothing here yet." />
      ) : null}
    </div>
  )
}
