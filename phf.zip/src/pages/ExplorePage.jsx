import { motion } from 'framer-motion'
import { useRouter, Link } from '../lib/router'
import { AlignLeft, ArrowRight, Hashtag, TrendUp } from '../components/icons'
import { getIcon } from '../lib/iconMap'
import Avatar from '../components/ui/Avatar'
import { SkeletonPage } from '../components/ui/Skeleton'
import { useStore } from '../lib/store'
import { compact } from '../lib/format'

export default function ExplorePage() {
  const { navigate } = useRouter()
  const { communities, trendingTags, categories, categoryThreads, topContributors, status } = useStore()

  if (status === 'loading') {
    return <SkeletonPage rows={3} />
  }

  return (
    <div className="pb-10">
      <header className="pt-6 sm:pt-8">
        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="display-tight text-[26px] leading-none font-bold text-white sm:text-[34px]"
        >
          Explore
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
          className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-dim"
        >
          {categories.length} forum rooms and {communities.length} communities, one tone of
          voice. Pick a room, follow a tag, and let the feed do the ranking.
        </motion.p>
      </header>

      <section className="mt-7">
        <div className="mb-3 flex items-center gap-2 text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">
          <TrendUp size={13} variant="Bold" />
          Trending tags
        </div>
        <div className="flex flex-wrap gap-2">
          {trendingTags.map((item, index) => (
            <motion.button
              key={item.tag}
              type="button"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.05, ease: [0.16, 1, 0.3, 1] }}
              onClick={() => navigate(`/search?q=${item.tag}`)}
              className="group inline-flex items-center gap-2 rounded-full border border-line bg-surface px-3.5 py-2 text-[13px] text-mute transition-colors hover:border-white/25 hover:text-white"
            >
              <Hashtag size={13} variant="Bold" />
              {item.tag}
              <span className="text-[11.5px] text-faint tabular-nums">{compact(item.count)}</span>
            </motion.button>
          ))}
        </div>
      </section>

      <section className="mt-8">
        <div className="mb-3 flex items-center gap-2 text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">
          <AlignLeft size={13} variant="Bold" />
          Forum rooms
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {categories.map((room, index) => {
            const Icon = getIcon(room.icon)
            const threads = categoryThreads(room.id)
            return (
              <motion.button
                key={room.id}
                type="button"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: Math.min(index, 8) * 0.04, ease: [0.16, 1, 0.3, 1] }}
                onClick={() => navigate(`/forum?c=${room.id}`)}
                className="group relative overflow-hidden rounded-2xl border border-line bg-surface p-4 text-left transition-colors duration-300 hover:border-white/[0.14]"
              >
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-line bg-raised text-mute transition-colors group-hover:border-white group-hover:bg-white group-hover:text-black">
                    <Icon size={19} variant="Bold" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="display-tight text-[15.5px] text-white">{room.name}</h3>
                      <ArrowRight
                        size={14}
                        variant="Bold"
                        className="ml-auto text-faint opacity-0 transition-all duration-300 group-hover:translate-x-0.5 group-hover:opacity-100"
                      />
                    </div>
                    <p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-dim">{room.description}</p>
                    <div className="mt-3 flex items-center gap-3 text-[11.5px] text-faint">
                      <span className="tabular-nums">{compact(room.members)} members</span>
                      <span className="h-1 w-1 rounded-full bg-faint" />
                      <span className="tabular-nums">{threads} thread{threads === 1 ? '' : 's'}</span>
                    </div>
                  </div>
                </div>
              </motion.button>
            )
          })}
        </div>
      </section>

      <section className="mt-8">
        <div className="mb-3 text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">Communities</div>
        <div className="grid gap-3 sm:grid-cols-2">
          {communities.map((community, index) => {
            const Icon = getIcon(community.icon)
            return (
              <motion.div
                key={community.id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: Math.min(index, 8) * 0.04, ease: [0.16, 1, 0.3, 1] }}
                className="group relative overflow-hidden rounded-2xl border border-line bg-surface p-4 text-left"
              >
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-line bg-raised text-mute transition-colors group-hover:border-white group-hover:bg-white group-hover:text-black">
                    <Icon size={19} variant="Bold" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="display-tight text-[15.5px] text-white">{community.name}</h3>
                      <span className="ml-auto rounded-full border border-line bg-raised px-2 py-0.5 text-[10.5px] tracking-wide text-faint uppercase">
                        Soon
                      </span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-dim">{community.description}</p>
                    <div className="mt-3 flex items-center gap-3 text-[11.5px] text-faint">
                      <span className="tabular-nums">{compact(community.members)} members</span>
                      <span className="h-1 w-1 rounded-full bg-faint" />
                      <span className="inline-flex items-center gap-1 tabular-nums">
                        <span className="h-1.5 w-1.5 rounded-full bg-blue-700" />
                        {compact(community.online)} online
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>
      </section>

      <section className="mt-8 rounded-2xl border border-line bg-surface">
        <header className="border-b border-line px-4 py-3.5">
          <h2 className="text-[10.5px] font-semibold tracking-[0.16em] text-faint uppercase">Most helpful this week</h2>
        </header>
        <ul className="divide-y divide-line">
          {topContributors.map((entry, index) => (
            <li key={entry.user.id}>
              <Link
                to={`/u/${entry.user.handle}`}
                className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-white/[0.03]"
              >
                <span className="display-tight w-5 text-sm text-faint">{index + 1}</span>
                <Avatar user={entry.user} size="md" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14px] font-medium text-white">{entry.user.name}</span>
                  <span className="block truncate text-[12px] text-dim">{entry.user.bio}</span>
                </span>
                <span className="text-[12.5px] font-medium text-mute tabular-nums">{compact(entry.score)}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
