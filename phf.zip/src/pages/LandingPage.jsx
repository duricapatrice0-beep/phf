import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from '../lib/router'
import { useAuth } from '../lib/auth'
import { ArrowRight, Category, Eye, EyeSlash, Heart, Shield, Timer } from '../components/icons'
import { useStore } from '../lib/store'
import { compact, timeAgo } from '../lib/format'

const FEATURES = [
  {
    icon: Category,
    title: 'Seven rooms, not seventy',
    body: 'One place per subject until a subject earns its own. No empty rooms, no dead categories, no scavenger hunts.',
  },
  {
    icon: Heart,
    title: 'Reactions that mean something',
    body: 'Love, Insight, Boost. Three signals with weight instead of a wall of identical thumbs.',
  },
  {
    icon: Timer,
    title: 'Built for the slow take',
    body: 'No infinite bait, no engagement theatre. Threads stay readable a week after they are posted.',
  },
  {
    icon: Shield,
    title: 'Quiet by moderation',
    body: 'Rules live in the sidebar and are enforced in the open. The room is the moderator, not a feed algorithm.',
  },
]

const PREVIEW = [
  { room: 'Announcements', title: 'Read this first: seven rooms, and why nothing gets its own forum yet', meta: '2h · 184 replies', tone: 'bg-red-900 text-white' },
  { room: 'OFW', title: 'Contract checklist for first-time OFWs: the eight lines I wish I read before signing', meta: '5h · 96 replies', tone: 'bg-yellow-300 text-black' },
  { room: 'Work & Money', title: 'Numbers over vibes: what hiring managers actually mean by “competitive salary”', meta: '1d · 71 replies', tone: 'bg-blue-700 text-white' },
]

const TONES = ['bg-red-900 text-white', 'bg-yellow-300 text-black', 'bg-blue-700 text-white']

function Field({ label, type = 'text', value, onChange, placeholder, autoComplete, trailing }) {
  return (
    <label className="block">
      <span className="label-caps block pb-2 text-[10px] text-faint">{label}</span>
      <span className="relative block">
        <input
          type={type}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className="h-11 w-full rounded-xl border border-line bg-raised pr-10 pl-3.5 text-[14.5px] text-white placeholder:text-faint transition-colors focus:border-white/30 focus:outline-none"
        />
        {trailing}
      </span>
    </label>
  )
}

export default function LandingPage() {
  const { signIn, signUp } = useAuth()
  const { navigate } = useRouter()
  const { categories, posts, getCategory } = useStore()
  const [mode, setMode] = useState('signup')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [reveal, setReveal] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState(null)
  const cardRef = useRef(null)

  const preview = posts.length
    ? posts.slice(0, 3).map((post, index) => ({
        room: getCategory(post.category)?.short || 'Forum',
        title: post.title,
        meta: `${timeAgo(post.minutes)} · ${post.comments} replies`,
        tone: TONES[index % TONES.length],
        count: compact(
          post.reactionCounts.like + post.reactionCounts.insight + post.reactionCounts.fire,
        ),
      }))
    : PREVIEW

  useEffect(() => {
    document.title = '.phf — a quiet place for sharp conversations'
  }, [])

  const focusCard = (nextMode) => {
    setMode(nextMode)
    setError(null)
    cardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    window.setTimeout(() => cardRef.current?.querySelector('input')?.focus(), 420)
  }

  const submit = async (event) => {
    event.preventDefault()
    if (busy) return
    setError(null)

    const cleanEmail = email.trim().toLowerCase()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setError('Enter a valid email address.')
      return
    }
    if (password.length < 8) {
      setError('Passwords need at least 8 characters.')
      return
    }

    setBusy(true)
    const result =
      mode === 'signin'
        ? await signIn(cleanEmail, password)
        : await signUp({ name: name.trim(), email: cleanEmail, password })
    setBusy(false)

    if (result.error) {
      setError(result.error)
      return
    }
    if (result.needsConfirm) {
      setError('Check your inbox — that email still needs a confirmation link before you can sign in.')
      return
    }
    navigate('/')
  }

  return (
    <div className="min-h-dvh bg-void">
      <header className="mx-auto flex w-full max-w-[1240px] items-center justify-between px-5 py-5 sm:px-8">
        <div className="flex items-center gap-2">
          <span className="font-display text-[22px] leading-none font-bold tracking-[-0.02em] text-white">
            .phf
          </span>
          <span className="hidden text-[11px] tracking-[0.22em] text-faint uppercase sm:inline">
            The quiet forum
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => focusCard('signin')}
            className="h-9 rounded-xl border border-line px-3.5 text-[13px] font-semibold text-mute transition-colors hover:border-white/30 hover:text-white"
          >
            Sign in
          </button>
          <button
            type="button"
            onClick={() => focusCard('signup')}
            className="h-9 rounded-xl bg-white px-3.5 text-[13px] font-semibold text-black transition-colors hover:bg-white/85"
          >
            Create account
          </button>
        </div>
      </header>

      <main className="mx-auto w-full max-w-[1240px] px-5 sm:px-8">
        <section className="grid items-start gap-10 pt-6 pb-16 lg:grid-cols-[1.1fr_0.9fr] lg:gap-14 lg:pt-14 lg:pb-24">
          <div>
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="label-caps text-[10.5px] text-faint"
            >
              Est. 2026 · Monochrome · Philippines-first
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              className="font-display mt-5 text-[clamp(42px,7vw,78px)] leading-[0.98] font-bold tracking-[-0.03em] text-white"
            >
              Say the <em className="font-normal italic">sharp</em> thing,
              <br />
              slowly.
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
              className="mt-6 max-w-[54ch] text-[16.5px] leading-relaxed text-mute"
            >
              .phf is a forum, not a feed. Seven rooms, long threads, three reactions with weight —
              and none of the noise that usually comes with an audience.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.12 }}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <button
                type="button"
                onClick={() => focusCard('signup')}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-white px-5 text-sm font-bold text-black transition-colors hover:bg-white/85"
              >
                Create your account
                <ArrowRight size={16} variant="Bold" />
              </button>
              <button
                type="button"
                onClick={() => focusCard('signin')}
                className="inline-flex h-11 items-center rounded-xl border border-line px-5 text-sm font-semibold text-mute transition-colors hover:border-white/30 hover:text-white"
              >
                I already have one
              </button>
            </motion.div>

            <dl className="mt-10 grid max-w-md grid-cols-3 gap-4 border-t border-line pt-6">
              {[
                ['412k', 'Members'],
                ['3.8k', 'Threads'],
                ['4.2k', 'Replies'],
              ].map(([value, label]) => (
                <div key={label}>
                  <dt className="font-display text-2xl font-bold text-white tabular-nums">{value}</dt>
                  <dd className="label-caps pt-1 text-[9.5px] text-faint">{label}</dd>
                </div>
              ))}
            </dl>
          </div>

          <motion.div
            ref={cardRef}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-3xl border border-line bg-surface p-5 shadow-panel sm:p-7"
          >
            <div className="grid grid-cols-2 gap-1 rounded-2xl border border-line bg-raised p-1">
              {[
                ['signup', 'Create account'],
                ['signin', 'Sign in'],
              ].map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    setMode(id)
                    setError(null)
                  }}
                  className={`h-9 rounded-xl text-[13px] font-semibold transition-colors ${
                    mode === id ? 'bg-red-900 text-white' : 'text-dim hover:text-white'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            <form onSubmit={submit} className="mt-5 space-y-4">
              {mode === 'signup' ? (
                <Field
                  label="Display name"
                  value={name}
                  onChange={setName}
                  placeholder="Mira Solano"
                  autoComplete="name"
                />
              ) : null}

              <Field
                label="Email"
                type="email"
                value={email}
                onChange={setEmail}
                placeholder="you@example.com"
                autoComplete="email"
              />

              <Field
                label="Password"
                type={reveal ? 'text' : 'password'}
                value={password}
                onChange={setPassword}
                placeholder="At least 8 characters"
                autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                trailing={
                  <button
                    type="button"
                    onClick={() => setReveal((value) => !value)}
                    aria-label={reveal ? 'Hide password' : 'Show password'}
                    className="absolute top-1/2 right-2.5 -translate-y-1/2 rounded-lg p-1.5 text-faint transition-colors hover:text-white"
                  >
                    {reveal ? <EyeSlash size={16} variant="Bold" /> : <Eye size={16} variant="Bold" />}
                  </button>
                }
              />

              {error ? (
                <p className="rounded-xl border border-red-900 bg-red-900/20 px-3.5 py-2.5 text-[13px] text-white">
                  {error}
                </p>
              ) : null}

              <button
                type="submit"
                disabled={busy}
                className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-white text-sm font-bold text-black transition-colors hover:bg-white/85 disabled:opacity-60"
              >
                {busy ? 'One moment…' : mode === 'signin' ? 'Sign in' : 'Create account'}
                {!busy ? <ArrowRight size={16} variant="Bold" /> : null}
              </button>
            </form>

            <p className="mt-4 text-[12.5px] leading-relaxed text-faint">
              Email and password only — no social sign-in. Confirmation emails are off during
              development, so you land straight inside the forum.
            </p>
          </motion.div>
        </section>

        <section className="grid gap-4 border-t border-line py-14 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature) => (
            <div
              key={feature.title}
              className="rounded-2xl border border-line bg-surface p-5 transition-colors hover:border-white/20"
            >
              <span className="grid h-10 w-10 place-items-center rounded-xl border border-line bg-raised text-white">
                <feature.icon size={19} variant="Bold" />
              </span>
              <h3 className="font-display mt-4 text-[17px] font-semibold text-white">{feature.title}</h3>
              <p className="mt-2 text-[14px] leading-relaxed text-dim">{feature.body}</p>
            </div>
          ))}
        </section>

        <section className="grid gap-8 border-t border-line py-14 lg:grid-cols-[0.85fr_1.15fr] lg:items-center">
          <div>
            <p className="label-caps text-[10.5px] text-faint">Inside the forum</p>
            <h2 className="font-display mt-4 text-[clamp(28px,3.4vw,40px)] leading-tight font-bold text-white">
              Threads first. Everything else second.
            </h2>
            <p className="mt-4 max-w-[48ch] text-[15.5px] leading-relaxed text-dim">
              The timeline is a list of real conversations with real length — category, age, and
              reply count before you open anything. Reactions sit in one pill so the row stays clean.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {categories.slice(0, 7).map((category) => (
                <span
                  key={category.id}
                  className="rounded-full border border-line bg-raised px-3 py-1.5 text-[12.5px] text-mute"
                >
                  {category.short}
                </span>
              ))}
            </div>
          </div>

          <div className="overflow-hidden rounded-3xl border border-line bg-surface shadow-panel">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <span className="label-caps text-[10px] text-faint">Forum · sorted by hot</span>
              <span className="rounded-full bg-red-900 px-2.5 py-1 text-[11px] font-semibold text-white">
                {categories.length || 7} rooms
              </span>
            </div>
            <div className="divide-y divide-[#1f1f1f]">
              {preview.map((row) => (
                <div key={row.title} className="px-5 py-4 transition-colors hover:bg-white/[0.02]">
                  <div className="flex items-center gap-2 text-[11.5px] text-faint">
                    <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${row.tone}`}>
                      {row.room}
                    </span>
                    <span>{row.meta}</span>
                  </div>
                  <p className="font-display mt-2 text-[16.5px] leading-snug font-semibold text-white">
                    {row.title}
                  </p>
                  <div className="mt-3 flex items-center gap-2">
                    <span className="inline-flex h-7 items-center gap-1.5 rounded-full border border-line bg-raised pr-2.5 pl-1.5">
                      <span className="grid h-[21px] w-[21px] place-items-center rounded-full bg-red-900 ring-2 ring-raised">
                        <Heart size={11} variant="Bold" className="text-white" />
                      </span>
                      <span className="text-[12px] font-semibold text-mute tabular-nums">{row.count}</span>
                    </span>
                    <span className="inline-flex h-7 items-center rounded-full border border-line bg-raised px-2.5 text-[12px] font-semibold text-mute">
                      Reply
                    </span>
                    <span className="ml-auto text-[11.5px] text-faint">Insight · Boost</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-line">
        <div className="mx-auto flex w-full max-w-[1240px] flex-wrap items-center justify-between gap-3 px-5 py-8 text-[12.5px] text-faint sm:px-8">
          <span className="font-display text-[15px] font-bold text-white">.phf</span>
          <span>Monochrome forum prototype · React + Supabase</span>
          <span className="label-caps text-[9.5px]">© 2026</span>
        </div>
      </footer>
    </div>
  )
}
