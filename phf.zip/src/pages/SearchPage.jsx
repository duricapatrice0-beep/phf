import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { useRouter } from '../lib/router'
import { Hashtag, SearchNormal, Star } from '../components/icons'
import EmptyState from '../components/ui/EmptyState'
import { SkeletonPage } from '../components/ui/Skeleton'
import PostCard from '../components/post/PostCard'
import { useStore } from '../lib/store'

export default function SearchPage({ query }) {
  const { navigate } = useRouter()
  const { posts, trendingTags, status } = useStore()
  const [value, setValue] = useState(query || '')

  const results = useMemo(() => {
    const needle = (query || '').trim().toLowerCase()
    if (!needle) return []
    return posts.filter((post) => {
      const haystack = `${post.title} ${post.excerpt} ${post.tags.join(' ')} ${post.body.join(' ')}`.toLowerCase()
      return haystack.includes(needle)
    })
  }, [query, posts])

  if (status === 'loading') {
    return <SkeletonPage rows={2} />
  }

  return (
    <div className="pb-10">
      <header className="pt-6 sm:pt-8">
        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="display-tight text-[26px] leading-none font-bold text-white sm:text-[34px]"
        >
          Search
        </motion.h1>
        <motion.form
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
          onSubmit={(event) => {
            event.preventDefault()
            navigate(value.trim() ? `/search?q=${encodeURIComponent(value.trim())}` : '/search')
          }}
          className="group relative mt-5"
        >
          <SearchNormal
            size={20}
            variant="Bold"
            className="pointer-events-none absolute top-1/2 left-4 -translate-y-1/2 text-faint transition-colors group-focus-within:text-white"
          />
          <input
            autoFocus
            value={value}
            onChange={(event) => setValue(event.target.value)}
            placeholder="Search threads, people, tags…"
            className="h-14 w-full rounded-2xl border border-line bg-surface pr-4 pl-12 text-[16px] text-white placeholder:text-faint transition-all outline-none group-focus-within:border-white/25 "
          />
        </motion.form>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-[12px] text-faint">
          <span>Try</span>
          {trendingTags.slice(0, 4).map((item) => (
            <button
              key={item.tag}
              type="button"
              onClick={() => {
                setValue(item.tag)
                navigate(`/search?q=${item.tag}`)
              }}
              className="inline-flex items-center gap-1 rounded-full border border-line bg-raised px-2.5 py-1 text-dim transition-colors hover:border-white/25 hover:text-white"
            >
              <Hashtag size={11} variant="Bold" />
              {item.tag}
            </button>
          ))}
        </div>
      </header>

      <div className="mt-7">
        <AnimatePresence mode="wait">
          {!query ? (
            <motion.div key="idle" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
              <EmptyState
                icon={SearchNormal}
                title="What are you looking for?"
                body="Search across titles, bodies, tags and authors. Everything on .phf is public and indexed the moment it’s published."
              />
            </motion.div>
          ) : results.length === 0 ? (
            <motion.div key="none" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
              <EmptyState
                icon={Star}
                title={`No results for “${query}”`}
                body="Try a shorter phrase, a tag without the hash, or browse the trending topics above."
                action={
                  <button
                    type="button"
                    onClick={() => navigate('/explore')}
                    className="inline-flex h-10 items-center rounded-xl bg-white px-4 text-sm font-semibold text-black"
                  >
                    Explore communities
                  </button>
                }
              />
            </motion.div>
          ) : (
            <motion.div key={`results-${query}`} className="space-y-3.5">
              <p className="text-[12px] text-faint">
                <span className="font-medium text-white tabular-nums">{results.length}</span> result
                {results.length === 1 ? '' : 's'} for “{query}”
              </p>
              {results.map((post, index) => (
                <PostCard key={post.id} post={post} index={index} />
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
