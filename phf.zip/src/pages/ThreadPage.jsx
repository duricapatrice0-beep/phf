import { useState } from 'react'
import { motion } from 'framer-motion'
import { Link, useRouter } from '../lib/router'
import { ArrowLeft2, Bookmark2, Edit, Messages2, Share, Timer, Trash } from '../components/icons'
import { getIcon } from '../lib/iconMap'
import Avatar from '../components/ui/Avatar'
import PointsBadge from '../components/ui/PointsBadge'
import ReactionBar from '../components/post/ReactionBar'
import Tabs from '../components/ui/Tabs'
import EmptyState from '../components/ui/EmptyState'
import OverflowMenu from '../components/ui/Menu'
import ConfirmDialog from '../components/ui/ConfirmDialog'
import { SkeletonThread } from '../components/ui/Skeleton'
import { CategoryTag } from '../components/ui/Tags'
import CommentThread from '../components/comment/CommentThread'
import CommentComposer from '../components/comment/CommentComposer'
import CreatePostModal from '../components/modal/CreatePostModal'
import { reactionsFor } from '../lib/reactions'
import { useStore } from '../lib/store'
import { compact, timeAgo } from '../lib/format'

const COMMENT_SORTS = [
  { id: 'best', label: 'Best' },
  { id: 'new', label: 'New' },
  { id: 'old', label: 'Old' },
]

export default function ThreadPage({ post }) {
  const { navigate } = useRouter()
  const { status, getCategory, userByHandle, react, toggleSave, isFollowing, toggleFollow, me, deletePost } = useStore()
  const [copied, setCopied] = useState(false)
  const [commentSort, setCommentSort] = useState('best')
  const [menuEdit, setMenuEdit] = useState(false)
  const [menuDelete, setMenuDelete] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState(null)

  if (status === 'loading') {
    return <SkeletonThread />
  }

  if (!post) {
    return (
      <div className="py-10">
        <EmptyState
          icon={Messages2}
          title="Thread not found"
          body="This conversation may have been removed, or the link is missing a beat."
          action={
            <button
              type="button"
              onClick={() => navigate('/')}
              className="inline-flex h-10 items-center rounded-xl bg-white px-4 text-sm font-semibold text-black"
            >
              Back to feed
            </button>
          }
        />
      </div>
    )
  }

  const category = getCategory(post.category) || { id: post.category, name: post.category, icon: 'Messages2', rules: [] }
  const author = userByHandle(post.author) || { handle: post.author, name: post.authorName || 'Member', seed: 0, karma: 0 }
  const CategoryIcon = getIcon(category.icon)
  const reactions = reactionsFor(post.reactionCounts, post.mine)
  const saved = post.saved
  const follows = isFollowing(author.id)
  const isOwn = Boolean(me?.id && post.authorId === me.id)

  const onReact = (key) => {
    react(post.id, key)
  }

  const onToggleSave = () => {
    toggleSave(post.id, !saved)
  }

  const share = () => {
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1600)
  }

  const confirmDelete = async () => {
    setBusy(true)
    setError(null)
    const result = await deletePost(post.id)
    setBusy(false)
    if (result.error) {
      setError(result.error)
      return
    }
    setMenuDelete(false)
    navigate('/')
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="pt-5 pb-10 sm:pt-7"
    >
      <div className="flex items-center gap-3 text-[12.5px]">
        <button
          type="button"
          onClick={() => navigate('/')}
          className="inline-flex items-center gap-1.5 rounded-lg border border-line bg-surface px-2.5 py-1.5 text-mute transition-colors hover:border-white/20 hover:text-white"
        >
          <ArrowLeft2 size={14} variant="Bold" />
          Feed
        </button>
        <span className="hidden text-faint sm:inline">/</span>
        <Link to="/explore" className="hidden text-dim transition-colors hover:text-white sm:inline">
          {category.name}
        </Link>
        <span className="hidden text-faint sm:inline">/</span>
        <span className="truncate text-faint">thread</span>
      </div>

      <article className="mt-4">
        <div className="flex gap-3 sm:gap-5">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <CategoryTag icon={category.icon} label={category.name} onClick={() => navigate(`/forum?c=${category.id}`)} />
              <span className="text-[11px] text-faint">·</span>
              <span className="inline-flex items-center gap-1 text-[11px] text-faint">
                <Timer size={11} variant="Bold" />
                {timeAgo(post.minutes)} ago
              </span>
              {post.editedAt ? <span className="text-[11px] text-faint">· edited</span> : null}
              <span className="text-[11px] text-faint">·</span>
              <span className="text-[11px] text-faint">{compact(post.comments)} comments</span>
            </div>

            <h1 className="display-tight mt-3 text-[24px] leading-[1.15] font-bold text-white sm:text-[32px]">
              {post.title}
            </h1>

            <div className="mt-4 flex items-center gap-3">
              <Link to={`/u/${author.handle}`} className="flex items-center gap-2.5">
                <Avatar user={author} size="md" />
                <span>
                  <span className="flex items-center gap-1.5">
                    <span className="text-[13.5px] font-semibold text-white">{author.name}</span>
                    <PointsBadge points={author.karma || 0} size="xs" />
                  </span>
                  <span className="mt-0.5 block text-[11.5px] text-faint">
                    @{author.handle} · {author.karma.toLocaleString()} points
                  </span>
                </span>
              </Link>
              <motion.button
                type="button"
                onClick={() => author.id && toggleFollow(author.id)}
                className={`ml-auto inline-flex h-8 items-center rounded-lg px-3.5 text-[12.5px] font-semibold transition-colors ${
                  follows
                    ? 'border border-red-900 bg-red-900 text-white hover:bg-red-900/80'
                    : 'bg-blue-700 text-white hover:bg-blue-600'
                }`}
              >
                {follows ? 'Following' : 'Follow'}
              </motion.button>
            </div>

            <div className="mt-5 space-y-4 border-t border-line pt-5">
              {post.body.map((paragraph, index) => (
                <motion.p
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 + index * 0.07, ease: [0.16, 1, 0.3, 1] }}
                  className="text-[15px] leading-[1.75] text-mute sm:text-[15.5px]"
                >
                  {paragraph}
                </motion.p>
              ))}
            </div>

            <div className="mt-5 flex flex-wrap gap-1.5">
              {post.tags.map((tag) => (
                <Link key={tag} to={`/search?q=${tag}`}>
                  <span className="inline-flex items-center gap-1 rounded-full border border-line bg-raised px-2.5 py-1 text-[11.5px] text-dim transition-colors hover:border-white/25 hover:text-white">
                    #{tag}
                  </span>
                </Link>
              ))}
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-1.5 border-t border-line pt-4">
              <div className="ml-auto flex flex-wrap items-center gap-1.5">
                <ReactionBar reactions={reactions} picked={post.mine} onPick={onReact} />
                <span className="inline-flex h-8 items-center gap-1.5 rounded-full border border-line bg-raised px-3 text-[12px] font-semibold text-mute transition-colors hover:border-white/30 hover:text-white">
                  <Messages2 size={14} variant="Bold" />
                  <span className="tabular-nums">{compact(post.comments)}</span>
                </span>
                <button
                  type="button"
                  onClick={onToggleSave}
                  className={`inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-[12px] font-semibold transition-colors ${
                    saved
                      ? 'border-red-900 bg-red-900 text-white'
                      : 'border-line bg-raised text-mute hover:border-white/30 hover:text-white'
                  }`}
                >
                  <Bookmark2 size={14} variant="Bold" />
                  {saved ? 'Saved' : 'Save'}
                </button>
                <div className="relative">
                  <button
                    type="button"
                    onClick={share}
                    className="inline-flex h-8 items-center gap-1.5 rounded-full border border-line bg-raised px-3 text-[12px] font-semibold text-mute transition-colors hover:border-white/30 hover:text-white"
                  >
                    <Share size={14} variant="Bold" />
                    {copied ? 'Copied' : 'Share'}
                  </button>
                </div>
              </div>
              {isOwn ? (
                <OverflowMenu
                  label="Thread options"
                  buttonClassName="h-8 w-8"
                  items={[
                    { icon: Edit, label: 'Edit post', onClick: () => setMenuEdit(true) },
                    { icon: Trash, label: 'Delete post', danger: true, onClick: () => setMenuDelete(true) },
                  ]}
                />
              ) : null}
            </div>
          </div>
        </div>
      </article>

      {menuEdit ? (
        <CreatePostModal open onClose={() => setMenuEdit(false)} post={post} />
      ) : null}
      <ConfirmDialog
        open={menuDelete}
        onClose={() => {
          setMenuDelete(false)
          setError(null)
        }}
        onConfirm={confirmDelete}
        busy={busy}
        error={error}
        title="Delete this thread?"
        body="The thread, its replies, and its reactions go with it. This cannot be undone."
      />

      <section className="mt-8 border-t border-line pt-6">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <CategoryIcon size={16} variant="Bold" className="text-mute" />
            <h2 className="display-tight text-lg text-white">Discussion</h2>
            <span className="rounded-full border border-line bg-raised px-2 py-0.5 text-[11px] text-dim tabular-nums">
              {compact(post.comments)}
            </span>
          </div>
          <div className="rounded-xl border border-line bg-raised px-1">
            <Tabs tabs={COMMENT_SORTS} value={commentSort} onChange={setCommentSort} layoutId="comment-sort" size="sm" />
          </div>
        </header>

        <div className="mt-4">
          <CommentComposer postId={post.id} />
        </div>

        <div className="mt-3">
          <CommentThread postId={post.id} sort={commentSort} />
        </div>

        <div className="mt-4 flex items-center gap-3 border-t border-line pt-5">
          <span className="h-px flex-1 bg-line" />
          <span className="text-[11px] tracking-[0.18em] text-faint uppercase">End of thread</span>
          <span className="h-px flex-1 bg-line" />
        </div>
      </section>
    </motion.div>
  )
}
