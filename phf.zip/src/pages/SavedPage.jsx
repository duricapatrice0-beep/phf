import { motion } from 'framer-motion'
import { Bookmark2 } from '../components/icons'
import EmptyState from '../components/ui/EmptyState'
import { SkeletonPage } from '../components/ui/Skeleton'
import PostCard from '../components/post/PostCard'
import { useRouter } from '../lib/router'
import { useStore } from '../lib/store'

export default function SavedPage() {
  const { navigate } = useRouter()
  const { posts, status } = useStore()
  const saved = posts.filter((post) => post.saved)

  if (status === 'loading') {
    return <SkeletonPage rows={2} />
  }

  return (
    <div className="pb-10">
      <header className="pt-6 sm:pt-8">
        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="display-tight text-[26px] leading-none font-bold text-white sm:text-[34px]"
        >
          Saved
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
          className="mt-2 text-[13.5px] text-dim"
        >
          {saved.length} thread{saved.length === 1 ? '' : 's'} kept for later — private to you.
        </motion.p>
      </header>

      <div className="mt-6">
        {saved.length ? (
          <div className="space-y-3.5">
            {saved.map((post, index) => (
              <PostCard key={post.id} post={post} index={index} />
            ))}
          </div>
        ) : (
          <EmptyState
            icon={Bookmark2}
            title="Nothing saved yet"
            body="Bookmark any thread and it will wait here — no algorithm, no expiry, no noise."
            action={
              <button
                type="button"
                onClick={() => navigate('/')}
                className="inline-flex h-10 items-center rounded-xl bg-white px-4 text-sm font-semibold text-black"
              >
                Browse the feed
              </button>
            }
          />
        )}
      </div>
    </div>
  )
}
