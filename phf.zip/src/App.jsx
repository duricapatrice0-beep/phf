import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { RouterProvider, matchRoute, useRouter } from './lib/router'
import Navbar from './components/layout/Navbar'
import { Sidebar, SidebarDrawer } from './components/layout/Sidebar'
import RightRail from './components/layout/RightRail'
import BottomTabBar from './components/layout/BottomTabBar'
import CreatePostModal from './components/modal/CreatePostModal'
import FeedPage from './components/post/FeedPage'
import EmptyState from './components/ui/EmptyState'
import ThreadPage from './pages/ThreadPage'
import ProfilePage from './pages/ProfilePage'
import ExplorePage from './pages/ExplorePage'
import SearchPage from './pages/SearchPage'
import SavedPage from './pages/SavedPage'
import NotificationsPage from './pages/NotificationsPage'
import SoonPage from './pages/SoonPage'
import RankPage from './pages/RankPage'
import LandingPage from './pages/LandingPage'
import { Messages2 as Chat, Video } from './components/icons'
import { AuthProvider, useAuth } from './lib/auth'
import { StoreProvider, useStore, sortPosts } from './lib/store'

function BootScreen() {
  return (
    <div className="grid min-h-dvh place-items-center bg-void">
      <div className="flex flex-col items-center gap-4">
        <span className="font-display text-[26px] leading-none font-bold tracking-[-0.02em] text-white">
          .phf
        </span>
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
      </div>
    </div>
  )
}

function Shell() {
  const { path, navigate } = useRouter()
  const { posts, categories, getCategory, categoryThreads, getPost, status } = useStore()
  const [rawPath, queryString] = path.split('?')
  const params = new URLSearchParams(queryString || '')
  const category = params.get('c') || 'all'
  const loading = status === 'loading'

  const [drawerOpen, setDrawerOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [sort, setSort] = useState('hot')

  const basePosts = posts

  const forumPosts = useMemo(() => {
    const filtered = category === 'all' ? basePosts : basePosts.filter((post) => post.category === category)
    return sortPosts(filtered, sort)
  }, [category, sort, basePosts])

  const chips = useMemo(
    () => categories.map((item) => ({ id: item.id, icon: item.icon, label: item.short })),
    [categories],
  )

  const threadParams = matchRoute(rawPath, '/post/:id')
  const profileParams = matchRoute(rawPath, '/u/:handle')
  const isHome = rawPath === '/'
  const isForum = rawPath === '/forum'
  const isFeed = isHome || isForum

  const selectCategory = (id) => navigate(id === 'all' ? '/forum' : `/forum?c=${id}`)

  let page
  let routeKey = rawPath

  if (isHome) {
    page = (
      <FeedPage
        title="Home Feed"
        subtitle="Everything you follow, ranked in one place. Threads rise as they earn reactions."
        posts={[]}
        loading={loading}
        sort={sort}
        onSortChange={setSort}
        chips={[]}
        activeFilter="all"
        onFilterChange={() => {}}
        emptyTitle="Your front page is empty"
        emptyBody="Home Feed fills up as you follow rooms, save threads, and react to things. Until then, every thread in the forum lives under Forum."
        emptyAction={
          <button
            type="button"
            onClick={() => navigate('/forum')}
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-white px-4 text-sm font-semibold text-black transition-colors hover:bg-white/80"
          >
            Browse the forum
          </button>
        }
      />
    )
    routeKey = 'home'
  } else if (isForum) {
    const selected = category !== 'all' ? getCategory(category) : null
    page = (
      <FeedPage
        title={selected ? selected.name : 'Forum'}
        subtitle={
          selected
            ? `${categoryThreads(selected.id)} thread${categoryThreads(selected.id) === 1 ? '' : 's'} · ${selected.rules.length} rules · sorted by ${sort}`
            : `${categories.length} rooms · ${basePosts.length} thread${basePosts.length === 1 ? '' : 's'} · sorted by ${sort}`
        }
        posts={forumPosts}
        loading={loading}
        sort={sort}
        onSortChange={setSort}
        chips={chips}
        activeFilter={category}
        onFilterChange={selectCategory}
        emptyTitle={selected ? `No threads in ${selected.short} yet` : 'The forum is quiet'}
        emptyBody={
          selected
            ? 'Be the first to start a thread in this room. It will stay empty until someone does.'
            : 'Nothing matches this view. Switch the sort order or start the first conversation.'
        }
        emptyAction={
          <button
            type="button"
            onClick={() => selectCategory('all')}
            className="inline-flex h-10 items-center rounded-xl bg-white px-4 text-sm font-semibold text-black transition-colors hover:bg-white/80"
          >
            View all threads
          </button>
        }
      />
    )
    routeKey = 'forum'
  } else if (threadParams) {
    page = <ThreadPage post={getPost(threadParams.id)} />
  } else if (profileParams) {
    page = <ProfilePage handle={profileParams.handle} />
  } else if (rawPath === '/explore') {
    page = <ExplorePage />
  } else if (rawPath === '/search') {
    page = <SearchPage query={params.get('q') || ''} />
  } else if (rawPath === '/saved') {
    page = <SavedPage />
  } else if (rawPath === '/notifications') {
    page = <NotificationsPage />
  } else if (rawPath === '/rank') {
    page = <RankPage />
  } else if (rawPath === '/videos') {
    page = (
      <SoonPage
        title="Videos"
        subtitle="Clips, talks, and screen recordings posted in the rooms."
        icon={Video}
        heading="No videos yet"
        body="Video posts open up with the next upload. Start a thread in the forum for now and the clip will land here when it ships."
      />
    )
  } else if (rawPath === '/chat') {
    page = (
      <SoonPage
        title="Chat"
        subtitle="Live rooms for the conversations that do not need a thread."
        icon={Chat}
        heading="Chat is quiet"
        body="Rooms open and close with demand. Until the first one goes live, every conversation worth keeping belongs in the forum."
      />
    )
  } else {
    page = (
      <div className="py-16">
        <EmptyState
          title="Page not found"
          body="That link doesn’t lead anywhere on .phf. It may have been moved, or the thread was removed."
          action={
            <button
              type="button"
              onClick={() => navigate('/forum')}
              className="inline-flex h-10 items-center rounded-xl bg-white px-4 text-sm font-semibold text-black"
            >
              Back to the forum
            </button>
          }
        />
      </div>
    )
  }

  return (
    <div className="min-h-dvh bg-void">
      <Navbar onMenuClick={() => setDrawerOpen(true)} onCreate={() => setCreateOpen(true)} />

      <div className="mx-auto flex w-full max-w-[1520px] items-start">
        <Sidebar
          path={rawPath}
          collapsed={collapsed}
          onToggleCollapse={() => setCollapsed((value) => !value)}
        />

        <main className="min-w-0 flex-1 pb-24 md:pb-8">
          <div className="mx-auto flex w-full max-w-[1240px] gap-6 px-3 sm:px-5 lg:gap-8">
            <div className="min-w-0 flex-1">
              <motion.div
                key={routeKey}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.34, ease: [0.16, 1, 0.3, 1] }}
              >
                {page}
              </motion.div>
            </div>

            {isFeed || threadParams ? (
              <RightRail activeCategory={isForum && category !== 'all' ? category : null} />
            ) : null}
          </div>
        </main>
      </div>

      <SidebarDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} path={rawPath} />

      <BottomTabBar onCreate={() => setCreateOpen(true)} path={rawPath} />

      <CreatePostModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}

function Gate() {
  const { session, loading: authLoading } = useAuth()
  if (authLoading) return <BootScreen />
  if (!session) return <LandingPage />
  return <Shell />
}

export default function App() {
  return (
    <AuthProvider>
      <StoreProvider>
        <RouterProvider>
          <Gate />
        </RouterProvider>
      </StoreProvider>
    </AuthProvider>
  )
}
